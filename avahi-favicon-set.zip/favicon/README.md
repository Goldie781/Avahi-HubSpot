# Avahi favicon

Site-wide favicon for every HubSpot page on portal 8985787 (website pages, landing pages, blog).

| File | Use |
|---|---|
| `favicon-192.png` | **Upload this one** in HubSpot → Settings → Content → Brand → Favicon (or Website → Pages → Branding → Favicon) |
| `favicon.ico` | 16/32/48/64 multi-size ICO (fallback / non-HubSpot use) |
| `favicon-16.png`, `favicon-32.png`, `favicon-48.png` | Small tab sizes |
| `apple-touch-icon.png` | 180×180, white background (iOS home screen) |
| `favicon-512.png` | Large / PWA |
| `avahi-favicon-source.png` | Original 512×512 transparent source |

How it reaches every page: all Avahi templates (`avahi-landing-page.html`, `avahi-ls-webinar.html`)
output `{{ standard_header_includes }}`, which prints the favicon set in HubSpot settings.
So the settings change covers all pages — do not hard-code `<link rel="icon">` in templates
(that would create duplicate/conflicting icons).

Browsers cache favicons hard: check in a private window or after a hard refresh.
