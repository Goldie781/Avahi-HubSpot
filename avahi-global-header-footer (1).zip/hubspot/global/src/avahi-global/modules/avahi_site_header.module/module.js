/* Avahi Site Header (global module) - mega menus, mobile sheet, scroll progress.
   No globals except window.AvahiSiteHeader; safe to load on any page. */
(function () {
  'use strict';
  var DESK = window.matchMedia('(min-width: 1025px)');
  var HOVER = window.matchMedia('(hover: hover) and (pointer: fine)');

  function track(label, href, where) {
    try {
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({ event: 'avh_nav_click', avh_nav_label: label, avh_nav_url: href, avh_nav_where: where });
    } catch (e) { /* ignore */ }
  }

  function init(root) {
    if (!root || root.__avhInit) return;
    root.__avhInit = true;
    if (root.classList.contains('avh-sh--editor')) return;

    var items = Array.prototype.slice.call(root.querySelectorAll('.avh-sh__item'));
    var burger = root.querySelector('.avh-sh__burger');
    var openItem = null, closeT = null, openT = null;

    function btnOf(item) { return item.querySelector(':scope > button.avh-sh__top'); }
    function setOpen(item) {
      if (openItem === item) return;
      if (openItem) {
        openItem.classList.remove('is-open');
        var ob = btnOf(openItem); if (ob) ob.setAttribute('aria-expanded', 'false');
      }
      openItem = item || null;
      if (openItem) {
        openItem.classList.add('is-open');
        var b = btnOf(openItem); if (b) b.setAttribute('aria-expanded', 'true');
      }
    }
    function closeAll() { clearTimeout(openT); clearTimeout(closeT); setOpen(null); }

    items.forEach(function (item) {
      var btn = btnOf(item);
      if (!btn) return;
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        clearTimeout(closeT); clearTimeout(openT);
        setOpen(openItem === item ? null : item);
      });
      item.addEventListener('mouseenter', function () {
        if (!DESK.matches || !HOVER.matches) return;
        clearTimeout(closeT); clearTimeout(openT);
        openT = setTimeout(function () { setOpen(item); }, openItem ? 0 : 70);
      });
      item.addEventListener('mouseleave', function () {
        if (!DESK.matches || !HOVER.matches) return;
        clearTimeout(openT);
        closeT = setTimeout(function () { if (openItem === item) setOpen(null); }, 180);
      });
      item.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowDown' && document.activeElement === btn) {
          e.preventDefault(); setOpen(item);
          var first = item.querySelector('.avh-sh__panel a'); if (first) first.focus();
        }
      });
    });

    root.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      if (root.classList.contains('is-menu-open')) { toggleMenu(false); if (burger) burger.focus(); }
      else if (openItem) { var b = btnOf(openItem); setOpen(null); if (b) b.focus(); }
    });
    root.addEventListener('focusout', function (e) {
      if (DESK.matches && openItem && !openItem.contains(e.relatedTarget)) setOpen(null);
    });
    document.addEventListener('click', function (e) {
      if (!root.contains(e.target)) { closeAll(); if (root.classList.contains('is-menu-open')) toggleMenu(false); }
    });

    function toggleMenu(force) {
      if (!burger) return;
      var open = typeof force === 'boolean' ? force : !root.classList.contains('is-menu-open');
      root.classList.toggle('is-menu-open', open);
      document.documentElement.classList.toggle('avh-sh-lock', open);
      burger.setAttribute('aria-expanded', String(open));
      burger.setAttribute('aria-label', open ? (burger.getAttribute('data-close-label') || 'Close menu') : (burger.getAttribute('data-open-label') || 'Open menu'));
      if (!open) closeAll();
    }
    if (burger) burger.addEventListener('click', function (e) { e.stopPropagation(); toggleMenu(); });

    function onBp() { closeAll(); toggleMenu(false); }
    if (DESK.addEventListener) DESK.addEventListener('change', onBp); else if (DESK.addListener) DESK.addListener(onBp);

    root.addEventListener('click', function (e) {
      var a = e.target.closest ? e.target.closest('a[data-avh-nav]') : null;
      if (!a) return;
      var label = (a.querySelector('.avh-sh__lt, .avh-sh__card-t, span') || a).textContent.trim();
      track(label, a.href, a.getAttribute('data-avh-nav'));
      if (!DESK.matches) toggleMenu(false);
    });

    Array.prototype.forEach.call(root.querySelectorAll('.avh-sh__media img'), function (img) {
      var hide = function () { img.parentNode.classList.add('is-broken'); };
      if (img.complete && img.naturalWidth === 0 && img.getAttribute('src')) hide(); else img.addEventListener('error', hide);
    });

    var bar = root.querySelector('.avh-sh__progress span');
    if (bar) {
      var ticking = false;
      var upd = function () {
        ticking = false;
        var h = document.documentElement.scrollHeight - window.innerHeight;
        bar.style.setProperty('--avh-p', h > 0 ? Math.min(1, Math.max(0, window.scrollY / h)).toFixed(4) : 0);
      };
      window.addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(upd); } }, { passive: true });
      window.addEventListener('resize', upd, { passive: true });
      upd();
    }
  }

  function boot() { Array.prototype.forEach.call(document.querySelectorAll('[data-avh-sh]'), init); }
  window.AvahiSiteHeader = { init: init, boot: boot };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
