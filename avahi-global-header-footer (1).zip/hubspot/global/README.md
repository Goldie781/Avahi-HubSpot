# Avahi global header + footer (HubSpot)

One header and one footer for every Avahi HubSpot page, matching https://avahi.ai/ (captured 2026-10-30).
They use HubSpot's native **global content**: each one is a **global partial** that holds one module. Content is
edited once in the **Global Content Editor**, and every page that includes the partial updates when it is published.
Rick's landing pages arrive without header/footer; the team builds them on the template below (header and footer
are included automatically), or adds the two `global_partial` tags to an existing template.

**Status (2026-10-30): installed in portal 8985787 and live** on AI Proof of Value, AWS Seller Propensity to
Migrate, Series A AI Growth Kit (header + footer) and the Life Sciences webinar (footer; it keeps its own webinar
header).

| What | Path in HubSpot (Design Manager) | Source here |
|---|---|---|
| Header global partial (edit in Global Content Editor) | `avahi-global/partials/avahi-header.html` | `src/avahi-global/partials/` |
| Footer global partial | `avahi-global/partials/avahi-footer.html` | `src/avahi-global/partials/` |
| Header module (design + fields) | `avahi-global/modules/avahi_site_header.module` | `src/avahi-global/modules/avahi_site_header.module/` |
| Footer module | `avahi-global/modules/avahi_site_footer.module` | `src/avahi-global/modules/avahi_site_footer.module/` |
| Base template for new landing pages | `avahi-global/templates/avahi-landing-page.html` ("Avahi Landing Page (global header + footer)") | `src/avahi-global/templates/` |
| Template migration helper | – | `migrate_templates.py` |
| Rollback copies of the 2 migrated templates | `custom/content-mcp/_backup-2026-10-30/` (not offered for new pages) | – |

HubSpot ids: header global content `225971790694`, footer global content `225996482816`.
Draft test page "TEST - Avahi global header (draft, do not publish)" `225987722593` (safe to delete).

## What the header and footer include

**Header** (floating pill, same size/position as avahi.ai): logo (built-in SVG or upload), top-level menu (add,
remove, reorder, up to 8; each item can be desktop+mobile, desktop only or mobile only - Partners is mobile only,
as on the live site), mega menus with up to 4 link columns and up to 3 cards (4 card styles: image + text,
large image, text + link, gradient button), **44 navigation icons from avahi.ai** selectable per link (or upload
a custom icon), "New"-style badges, language switcher (globe, hidden below 1367px like the live site), gradient
CTA, scroll-progress line, hover + click + keyboard (Enter/Space/ArrowDown/Escape), accessible mobile menu
(burger, accordions, scroll lock, language + CTA at the bottom) at 1024px and below.

Menu fields are two levels deep (menu item > links) so every value shows correctly in HubSpot's editor sidebar.
Each dropdown link has a **Column** setting (1-4); column headings are set on the menu item.

**Footer**: statement + Get Started band (can be switched off), logo, about text, social pills, newsletter link,
up to 5 link columns, award badges (image + optional link), copyright (`{year}` = current year), language
switcher, legal links. Responsive at 1180 / 1024 / 640 / 380px.
Link columns can come from the module fields (default) or from a **HubSpot navigation menu**
(Footer > "Link columns source" = Navigation menu, then pick a menu: top-level items become column headings,
their children the links). Manage that menu in Settings > Content > Navigation menus.

Space below the header: on pages with the Avahi LP hero (`.hero--page > .hero__inner`) the header CSS sets the hero
top padding to clamp(170px, 12vw, 190px) on desktop, 156px at 1024px and below and 148px at 640px and below, so the
hero text clears the floating header. Not applied in the editor or in "push the page down" mode. The LS webinar (own
header) gets the same treatment from a small `<style id="avh-hero-offset">` in its template.
Mobile menu: at 767px and below dropdown links are one column and each label stays on one line.

Isolation: all CSS is scoped to `#avh-site-header` / `#avh-site-footer`, forces Manrope over the site-wide
Poppins `!important` rule, uses no Font Awesome class names (`fa*`), and the JS only defines
`window.AvahiSiteHeader`. Navigation clicks push `avh_nav_click` to `dataLayer` (label, URL, menu).
Existing forms and tracking are untouched.

## Editing (admins) - native Global Content Editor

1. Open any page that uses the header/footer in the page editor (Content > Landing Pages > page > Edit).
2. Click the header (or footer). HubSpot shows **"Edit global content?"** - choose **Open in global content editor**.
3. In the left panel click **Avahi Site Header** (or **Avahi Site Footer**) to open its fields.
4. Edit what you need:
   * Header: logo, menu items (drag to reorder, + Add, duplicate, delete), per item the label, link, desktop/mobile
     visibility, column headings, dropdown links (text, URL, icon, column, tag) and cards; CTA; languages.
   * Footer: statement + button, about text, social links, link columns and their links, badges, legal links,
     copyright.
5. Use **View on** to preview the change on any connected page.
6. Click **Publish to N assets** (N = every page using it) > **Publish**. All connected pages update.

Design, spacing and behaviour are fixed in `module.css` / `module.js` and are not editable from the sidebar.

## New landing pages

* Create the page from **Avahi Landing Page (global header + footer)** and build the sections in the
  drag-and-drop area. The header and footer are already there, or
* In any custom template add, at the top of `<body>` and before `{{ standard_footer_includes }}`:

```hubl
{% global_partial path="/avahi-global/partials/avahi-header.html" %}
<main id="main"> ... page content ... </main>
{% global_partial path="/avahi-global/partials/avahi-footer.html" %}
```

Do not copy header or footer HTML into a page, and do not place the two modules directly on a page (that creates
a local copy). The header floats over the top of the page like on avahi.ai, so the first section needs about
110px top padding (or set Header > Position to "push the page down").

## Install / update the source (HubSpot CLI)

```bash
cd hubspot/global
python3 build.py                                   # regenerates module.html / fields.json / meta.json
hs upload src/avahi-global avahi-global            # modules, partials, template
```

Use a Personal Access Key for portal 8985787 (`hs auth`); never commit the key or `hubspot.config.yml`.
Uploading changes the design/fields only. Copy lives in global content in HubSpot and is not overwritten.

## Migrating existing templates

Done on 2026-10-30 for `custom/content-mcp/pages/avahi-landing-page.html` (both tags) and
`avahi-ls-webinar.html` (footer tag only; its `badges=[...]` parameter now comes from global content).
For any other template that still uses the old `avahi_global_header` / `avahi_global_footer` modules:

```bash
hs fetch custom/content-mcp/pages ./_fetched --overwrite
python3 migrate_templates.py ./_fetched            # dry run - prints every line it will change
python3 migrate_templates.py ./_fetched --write    # originals are kept in ./_fetched_backup
hs upload ./_fetched custom/content-mcp/pages
```

Rollback: upload the copies from `custom/content-mcp/_backup-2026-10-30/` (or `./_fetched_backup`) over the
originals, or use the file's revision history in Design Manager. The old modules are left in place so rollback
works. Published pages pick up template changes on their next render (CDN cache can delay this a few minutes).
Add `--replace-page-headers` to give the LS webinar the site header as well.

Not migrated (by design):
* `avahi-lp-skeleton-validation.html` - test template, no pages.
* **Fusion Avahi-LP theme pages (60)** - see below.

## Fusion Avahi-LP theme (compatibility check, not migrated)

The Fusion pages get their header/footer from the theme's own global partials (`../partials/header.html`,
`../partials/footer.html`) in `templates/layouts/landing-page-base.html`, which 56 pages share
(`landing-blank-page.html` 50, `landing-blank-v3 copy.html` 3, others). The theme loads Font Awesome; the Avahi
modules use no `fa*` classes and scoped CSS, so they are technically compatible. Switching means replacing those
two `global_partial` lines in the layout, which changes every Fusion page at once (and the theme header's spacing),
so it needs its own test page and sign-off. `lp-scheduling.html` uses a no-navigation header on purpose.

## Develop / test

```bash
python3 build.py
python3 preview.py --fonts <dir with manrope-latin-*-normal.woff2>   # preview/*.html (Jinja2 stands in for HubL)
python3 test/shoot.py                                                # Playwright: 75 checks + screenshots in test/shots/
```

Defaults live in `data/content.py` (copy), `data/icons.json` (44 icons taken from avahi.ai) and `data/logo.svg`.
They only seed new installs; after install, global content in HubSpot is the source of truth for copy.

## Known gaps

* 2 of the 10 footer badges (AWS Partner, CRN AI Innovators 2026) and the mega-menu card images are hot-linked
  from avahi.ai media. Upload them to File Manager and swap them in global content to remove that dependency.
* Badge alt texts were written from the badge artwork; check them.
* The live site's Spanish link (`?lang=es`) is kept as is.
* Editor quirk: if a new repeater item's detail panel ever shows default values instead of saved ones, make any
  edit to the module (or drag an item and back) so HubSpot stores the full content, then publish.
