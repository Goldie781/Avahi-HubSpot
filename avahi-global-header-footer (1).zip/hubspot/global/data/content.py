"""Default content for the Avahi global header and footer.

Captured from the live site https://avahi.ai/ on 2026-10-30 (desktop mega menus, mobile-only items,
footer). These become the module field defaults, so a fresh install already matches the live site.
Edit content in HubSpot (global content), not here; this file only seeds the defaults.
"""

WP = "https://avahi.ai/wp-content/uploads"
HUBFS = "https://8985787.fs1.hubspotusercontent-na1.net/hubfs/8985787"


def L(label, href, icon="none", tag=""):
    return {"label_text": label, "url": href, "icon": icon, "tag": tag}


def card(style, title="", text="", href="", image="", kicker="", link_label="", w=0, h=0):
    return {"style": style, "kicker": kicker, "title": title, "text": text, "href": href,
            "image": image, "image_w": w, "image_h": h, "link_label": link_label}


HEADER = {
    "logo_label": "Avahi home",
    "logo_link": "https://avahi.ai/",
    "cta_label": "Discuss Your Project",
    "cta_link": "https://avahi.ai/contact/",
    "languages": [
        {"label_text": "en", "code": "en", "link": "https://avahi.ai/", "current": True},
        {"label_text": "es", "code": "es", "link": "https://avahi.ai/?lang=es", "current": False},
    ],
    "menu": [
        {
            "label_text": "AI Solutions", "href": "", "show_on": "all", "cards_width": "wide",
            "columns": [
                {"heading": "AI Capabilities", "hide_desktop": False, "links": [
                    L("Chatbots", "https://avahi.ai/solutions/chatbots/", "chatbot"),
                    L("Summarization", "https://avahi.ai/solutions/summarization/", "summarize"),
                    L("Structured Data Extraction", "https://avahi.ai/solutions/structured-data-extraction/", "extract"),
                    L("Medical Scribing", "https://avahi.ai/solutions/medical-scribing/", "medical"),
                    L("AI Voice Agents", "https://avahi.ai/solutions/ai-voice-agent/", "voice"),
                    L("AI Content Generation", "https://avahi.ai/solutions/ai-content-generation/", "content"),
                ]},
                {"heading": "Analytics & Intelligence", "hide_desktop": False, "links": [
                    L("Language Translation", "https://avahi.ai/solutions/language-translation/", "translate"),
                    L("Predictive Analytics", "https://avahi.ai/solutions/predictive-analytics/", "predictive"),
                    L("Image & Video Analysis", "https://avahi.ai/solutions/image-video-analysis/", "image_video"),
                    L("Recommendation Engines", "https://avahi.ai/solutions/recommendation-engines/", "recommend"),
                    L("Sentiment Analysis", "https://avahi.ai/solutions/sentiment-analysis/", "sentiment"),
                ]},
            ],
            "cards": [
                card("media", "See the full catalog of AI capabilities", "Explore all solutions",
                     "https://avahi.ai/aws-proof-of-concept/", f"{WP}/2026/06/AI_Poc_Development_previewer-1024x536.png", w=1024, h=536),
                card("media", "AI Voice Agent", "Always on AI voice agent that turns calls into outcomes.",
                     "https://avahi.ai/solutions/ai-voice-agent/", f"{WP}/2026/10/avahi-menu-voice.png", w=360, h=190),
            ],
        },
        {
            "label_text": "Services", "href": "", "show_on": "all", "cards_width": "narrow",
            "columns": [
                {"heading": "Cloud & Migration", "hide_desktop": False, "links": [
                    L("AWS Cloud Migration", "https://avahi.ai/services/cloud-migration/", "aws"),
                    L("Azure to AWS Migration", "https://avahi.ai/services/cloud-migration/azure-aws-migration/", "aws_wordmark"),
                    L("Heroku to AWS Migration", "https://avahi.ai/services/cloud-migration/heroku-to-aws-migration/", "aws_wordmark"),
                    L("OpenAI to Bedrock", "https://avahi.ai/services/cloud-migration/open-ai-to-bedrock-migration-service/", "bedrock"),
                    L("Gemini to Bedrock", "https://avahi.ai/services/gemini-to-amazon-bedrock-migration/", "bedrock"),
                ]},
                {"heading": "Build & Optimize", "hide_desktop": False, "links": [
                    L("Application Modernization", "https://avahi.ai/services/application-modernization/", "modernize"),
                    L("AWS Consulting & AI Strategy", "https://avahi.ai/services/ai-strategy-consulting/", "strategy"),
                    L("AWS DevOps", "https://avahi.ai/services/aws-devops/", "devops"),
                    L("Cost Optimization", "https://avahi.ai/services/aws-cost-optimization/", "cost"),
                    L("Cloud Consulting", "https://avahi.ai/services/cloud-consulting/", "cloud"),
                ]},
                {"heading": "Manage & Scale", "hide_desktop": False, "links": [
                    L("AWS Managed Service", "https://avahi.ai/services/managed-aws-ai-services/", "managed"),
                    L("Cloud Staffing", "https://avahi.ai/services/cloud-staffing/", "team"),
                    L("Data & Analytics", "https://avahi.ai/services/data-analytics-services/", "analytics"),
                    L("AWS Security & Compliance", "https://avahi.ai/services/aws-security-compliance/", "security"),
                    L("AWS Proof of Concept", "https://avahi.ai/aws-proof-of-concept/", "sparkle"),
                ]},
            ],
            "cards": [
                card("media", "AI Proof of Value", "", "https://avahi.ai/aws-proof-of-concept/",
                     f"{WP}/2026/06/AI_Poc_Development_previewer-768x402.png", kicker="What's New", w=768, h=402),
                card("media", "Customer Stories", "", "https://avahi.ai/customer-story-listing/",
                     f"{WP}/2026/10/avahi-customer-stories-featured-v2-1200x630-1-768x403.webp", w=768, h=403),
                card("button", "Explore Our Services", "", "https://avahi.ai/services/"),
            ],
        },
        {
            "label_text": "Industries", "href": "", "show_on": "all", "cards_width": "medium",
            "columns": [
                {"heading": "For Industries", "hide_desktop": False, "links": [
                    L("Healthcare", "https://avahi.ai/industries/healthcare/", "healthcare"),
                    L("Insurance", "https://avahi.ai/industries/insurance/", "insurance"),
                    L("Media & Entertainment", "https://avahi.ai/industries/media-entertainment/", "media"),
                    L("Manufacturing & Supply Chain", "https://avahi.ai/industries/manufacturing-supply-chain/", "manufacturing"),
                ]},
                {"heading": "", "hide_desktop": False, "links": [
                    L("Financial Services", "https://avahi.ai/industries/financial-services/", "finance"),
                    L("Legal", "https://avahi.ai/industries/legal/", "legal"),
                    L("Retail & E-Commerce", "https://avahi.ai/industries/retail-ecommerce/", "retail"),
                    L("Education", "https://avahi.ai/industries/education/", "education"),
                ]},
            ],
            "cards": [
                card("media", "Start an AI Proof of Value",
                     "Validate the value of AI with your data. Measure business impact, performance, and cost before committing to production.",
                     "https://avahi.ai/aws-proof-of-concept/", f"{WP}/2026/06/AI_Poc_Development_previewer-768x402.png", w=768, h=402),
                card("media", "Retail and E-Commerce", "Serve spot-on recommendations, predict demand with precision",
                     "https://avahi.ai/industries/retail-ecommerce/",
                     f"{WP}/2026/10/avahi-retail-ecommerce-featured-1200x630-1-768x403.webp", w=768, h=403),
            ],
        },
        {
            "label_text": "Resources", "href": "", "show_on": "all", "cards_width": "narrow",
            "columns": [
                {"heading": "Learn", "hide_desktop": False, "links": [
                    L("Blog", "https://avahi.ai/blog/", "blog"),
                    L("Glossary", "https://avahi.ai/glossary/", "glossary"),
                    L("Events", "https://avahi.ai/events", "events"),
                    L("Customer Stories", "https://avahi.ai/customer-story-listing/", "stories"),
                ]},
                {"heading": "Tools", "hide_desktop": True, "links": [
                    L("AI Platform", "https://avahi.ai/ai-platform", "summarize"),
                    L("AI Comparison Tool", "https://avahi.ai/bedrock-conversion-tool", "sparkle"),
                ]},
                {"heading": "Case Studies", "hide_desktop": False, "links": [
                    L("NorthBay Healthcare", "https://avahi.ai/case-study/healthcare-northbay-telehealth-solution/", "sparkle"),
                    L("Groopview & AWS Nova", "https://avahi.ai/case-study/groopview-accelerates-real-time-social-insights-with-avahi-aws-nova/", "sparkle"),
                    L("Extract AI chatbots", "https://avahi.ai/case-study/extract-launches-ai-driven-chatbot-on-aws/", "sparkle"),
                    L("View All", "https://avahi.ai/case-study/", "none"),
                ]},
            ],
            "cards": [
                card("feature", "How N-Smart Is Predicting Wildfire and Storm Risk on Utility Poles with GenAI on AWS", "",
                     "https://avahi.ai/case-study/how-n-smart-is-predicting-wildfire-and-storm-risk-on-utility-poles-with-genai-on-aws/",
                     f"{WP}/2026/10/1.-CS-Featured-Images-11-768x384.png", link_label="Read case study", w=768, h=384),
            ],
        },
        {
            "label_text": "Partners", "href": "https://avahi.ai/company/partners/", "show_on": "mobile",
            "cards_width": "medium", "columns": [], "cards": [],
        },
        {
            "label_text": "Company", "href": "", "show_on": "all", "cards_width": "medium",
            "columns": [
                {"heading": "Company", "hide_desktop": False, "links": [
                    L("About Us", "https://avahi.ai/company/about-us/", "about"),
                    L("Our Approach", "https://avahi.ai/company/our-approach/", "approach"),
                    L("AWS Certification", "https://avahi.ai/company/certifications/", "certification"),
                    L("Partners", "https://avahi.ai/company/partners/", "partners"),
                    L("Our Team", "https://avahi.ai/our-team/", "team"),
                ]},
                {"heading": "", "hide_desktop": False, "links": [
                    L("Sustainability", "https://avahi.ai/sustainability-mission/", "sustainability"),
                    L("Careers", "https://avahi.ai/company/careers/", "careers"),
                    L("Press", "https://avahi.ai/company/press/", "summarize"),
                    L("Contact", "https://avahi.ai/contact/", "contact"),
                ]},
            ],
            "cards": [
                card("simple", "Discuss Your Project", "", "https://avahi.ai/contact/", link_label="Contact"),
            ],
        },
    ],
}

FOOTER = {
    "statement": "AI engineered for measurable business results.",
    "cta_label": "Get Started",
    "cta_link": "https://avahi.ai/contact/",
    "logo_link": "https://avahi.ai/",
    "logo_label": "Avahi home",
    "about": "Avahi is an AI systems integrator connecting models, data, and applications to deliver practical business solutions.",
    "social_title": "Follow Us",
    "social": [
        ("LinkedIn", "https://www.linkedin.com/company/avahiai/"),
        ("YouTube", "https://www.youtube.com/@AvahiAi"),
        ("X", "https://x.com/AvahiTech"),
    ],
    "newsletter_title": "Newsletter",
    "newsletter_label": "Subscribe on LinkedIn",
    "newsletter_link": "https://www.linkedin.com/build-relation/newsletter-follow?entityUrn=7480905581482905601",
    "columns": [
        ("Services", [
            ("AWS Cloud Migration", "https://avahi.ai/services/cloud-migration/"),
            ("Application Modernization", "https://avahi.ai/services/application-modernization/"),
            ("AWS Consulting & AI Strategy", "https://avahi.ai/services/ai-strategy-consulting/"),
            ("AWS DevOps", "https://avahi.ai/services/aws-devops/"),
            ("Cloud Consulting", "https://avahi.ai/services/cloud-consulting/"),
            ("Cost Optimization", "https://avahi.ai/services/aws-cost-optimization/"),
            ("AWS Managed Services", "https://avahi.ai/services/managed-aws-ai-services/"),
            ("Data & Analytics", "https://avahi.ai/services/data-analytics-services/"),
            ("AWS Security & Compliance", "https://avahi.ai/services/aws-security-compliance/"),
            ("Cloud Staffing", "https://avahi.ai/services/cloud-staffing/"),
        ]),
        ("Solutions", [
            ("Intelligent Chatbots", "https://avahi.ai/solutions/chatbots/"),
            ("Summarization", "https://avahi.ai/solutions/summarization/"),
            ("Data Extraction", "https://avahi.ai/solutions/structured-data-extraction/"),
            ("Medical Scribing", "https://avahi.ai/solutions/medical-scribing/"),
            ("AI Voice Agents", "https://avahi.ai/solutions/ai-voice-agent/"),
            ("AI Content Generation", "https://avahi.ai/solutions/ai-content-generation/"),
            ("Predictive Analytics", "https://avahi.ai/solutions/predictive-analytics/"),
            ("Recommendation Engines", "https://avahi.ai/solutions/recommendation-engines/"),
            ("Sentiment Analysis", "https://avahi.ai/solutions/sentiment-analysis/"),
            ("Image & Video Analysis", "https://avahi.ai/solutions/image-video-analysis/"),
            ("Language Translation", "https://avahi.ai/solutions/language-translation/"),
        ]),
        ("Migration Paths", [
            ("Azure to AWS", "https://avahi.ai/services/cloud-migration/azure-aws-migration/"),
            ("Heroku to AWS", "https://avahi.ai/services/cloud-migration/heroku-to-aws-migration/"),
            ("Open AI to Bedrock", "https://avahi.ai/services/cloud-migration/open-ai-to-bedrock-migration-service/"),
            ("Gemini to Bedrock", "https://avahi.ai/services/gemini-to-amazon-bedrock-migration/"),
        ]),
        ("Resources", [
            ("Blog", "https://avahi.ai/blog/"),
            ("Glossary", "https://avahi.ai/glossary/"),
            ("Case Studies", "https://avahi.ai/case-study/"),
            ("Events", "https://avahi.ai/events"),
            ("Contact", "https://avahi.ai/contact/"),
            ("Trust", "https://trust.avahi.ai/"),
        ]),
    ],
    "badges_title": "Recognized Among the Best in Business",
    # (src, alt, width, height, link) - 8 are already in HubSpot File Manager; 2 are hot-linked from avahi.ai
    "badges": [
        (f"{WP}/2026/10/Home-page-new-test-1907-1754.png", "AWS Partner, Premier Tier Services", 400, 400, ""),
        (f"{HUBFS}/image-2626-2-1.png", "The American Business Awards, Stevie Awards", 254, 378, ""),
        (f"{HUBFS}/image-2512-2-1.png", "Inc. Best in Business 2025, Best AI Implementation", 351, 378, ""),
        (f"{HUBFS}/image-2513-2-1.png", "Best of Small Business Awards 2025 Winner, SB100", 449, 449, ""),
        (f"{HUBFS}/image-2515-2-1.png", "Artificial Intelligence Excellence Award 2026", 312, 312, ""),
        (f"{HUBFS}/Avahi_Tech_US_English_2026_Certification_Badge-1-2-1.png", "Great Place To Work Certified, June 2026 to June 2027, USA", 312, 442, ""),
        (f"{HUBFS}/image-2664-2-1%20(1).webp", "CRN Fast Growth 150, 2026", 232, 448, "https://trust.avahi.ai/"),
        (f"{HUBFS}/home-v3-3733a3eb-2-1.webp", "2026 Globee Awards Gold Winner, Leadership", 150, 150, "https://trust.avahi.ai/"),
        (f"{HUBFS}/a12c625b-ffbe-4785-993c-86ce17c06790.png", "2026 Globee Awards, Leadership", 400, 400, "https://trust.avahi.ai/"),
        (f"{WP}/2026/06/CRN26-AI-Innovators-Logo-549x1024.png", "CRN AI Innovators 2026", 549, 1024, "https://trust.avahi.ai/"),
    ],
    "copyright": "© {year} Avahi. All rights reserved.",
    "legal": [
        ("Privacy Policy", "https://avahi.ai/privacy-policy/"),
        ("Terms of Service", "https://avahi.ai/terms-of-service/"),
        ("Security", "https://avahi.ai/services/aws-security-compliance/"),
    ],
}

ICON_LABELS = {
    "chatbot": "Chatbot", "summarize": "Document / summary", "extract": "Data extraction",
    "medical": "Medical", "voice": "Voice wave", "content": "Content generation", "translate": "Translation",
    "predictive": "Predictive chart", "image_video": "Image & video", "recommend": "Recommendation",
    "sentiment": "Sentiment", "aws": "AWS logo (small)", "aws_wordmark": "AWS logo (wordmark)",
    "bedrock": "Amazon Bedrock", "modernize": "Modernization", "strategy": "Strategy network",
    "devops": "DevOps", "cost": "Cost", "cloud": "Cloud", "managed": "Managed service", "team": "Team",
    "analytics": "Analytics bars", "security": "Security shield", "sparkle": "Sparkle",
    "healthcare": "Healthcare cross", "insurance": "Insurance", "media": "Media / video",
    "manufacturing": "Manufacturing", "finance": "Finance", "legal": "Legal", "retail": "Retail store",
    "education": "Education", "blog": "Blog", "glossary": "Glossary", "events": "Events calendar",
    "stories": "Customer stories", "about": "About", "approach": "Approach sliders",
    "certification": "Certification", "partners": "Partners handshake", "sustainability": "Sustainability",
    "careers": "Careers", "contact": "Contact mail",
}
