# Life Sciences Webinar 3 — Turn Paper Batch Records into Searchable Data

CMC Intelligence Series, Session 03. Reference HTML: `avahi-life-sciences-paper-batch-records-webinar-vsl.html` (repo root).
Design reference: Webinar 2 (`/life-sciences-webinar-2-batch-record-review`, content id 228075035449).

## HubSpot page

| Item | Value |
|---|---|
| Page | "Avahi \| Life Sciences Webinar 3 – Paper Batch Records to Searchable Data", content id **228093785624** (DRAFT, cloned from Webinar 2 on 2026-11-20) |
| URL (after publish) | https://www2.avahi.ai/life-sciences-webinar-3-paper-batch-records |
| Template | `avahi-global/templates/avahi-landing-page.html` — global header + footer partials (not copied, not changed) |
| Title / OG title | Paper Batch Records to Searchable Data Webinar \| Avahi |
| Meta / OG description | Watch AWS-based extraction turn executed paper batch records into one searchable repository, with every value linked back to its source page. Book a call with Avahi. |
| Canonical | automatic (page URL); indexable (no robots tag) |
| Featured / OG image | File Manager `/avahi-ls-webinar-3/avahi-ls-webinar-3-turn-paper-into-searchable-data.jpg` (1536×864), alt set; head HTML adds og:type, og:site_name, og:image:alt, twitter:image:alt |
| Meetings | `https://meetings.hubspot.com/baljit-singh2/life-sciences?embed=true&uuid=6babea09-8ec4-468d-9579-a6c83c6e8911` |
| Video | **Not connected.** DLD-250 (video edit) was "In Progress" on 2026-11-20. Poster = thumbnail; with no video, a click on the player scrolls to the booking section. |

## Modules (same as Webinar 2, content set as page values)

`avahi_lsv_layer` (locked CSS/JS), `avahi_lsv_hero`, `avahi_lsv_results`, `avahi_lsv_booking`, `avahi_lsv_timeline`,
`avahi_lsv_compare`, `avahi_lsv_dark_panel`, `avahi_lsv_presenters`, `avahi_lsv_series`, `avahi_awards_rail`,
`avahi_lsv_cta` (+ floating "Talk to an AI Expert"), `avahi_faq`. All values: `page-values.json`.

Page-specific choices:
* Hero video: poster = thumbnail, overlay text off (as on Webinar 2), **phone shape 16:9** (4:3 cropped the faces in
  the thumbnail), play button **Centre** (exact 50%/50% on desktop, tablet and phone).
* Series: Session 02 card links to the live Webinar 2 page (the reference had no link because it was not live yet).

## Module additions (2026-11-20, backwards compatible)

Webinar 3 uses icons and a dark-panel scene that the Webinar 2 modules did not have. Added (nothing removed or renamed;
Webinar 2 output verified unchanged):

* `avahi_lsv_results`, `avahi_lsv_timeline`: icon choices `trend`, `flask`, `clock`, `signature`, `search`, `database`
  (`snippets/icon-branches.hubl.html`, `snippets/icon-choices.json`).
* `avahi_lsv_dark_panel`: scene choice `trace` ("Paper record to searchable data scene (Session 03)",
  `snippets/dark-panel-trace-scene.svg.html`) + a scoped `.lsv .ill .lp-pulse` animation (reduced-motion safe),
  printed only when that scene is chosen.
* Applied with `tools/module-additions.js` in a logged-in app.hubspot.com tab (CMS Source Code API PUT); read back and
  compared after upload.
* Rollback copies of the 3 modules before the change: Design Manager
  `custom/content-mcp/_backup-2026-11-20/<module>.module/` (hidden from new content).

* `avahi_lsv_hero` (2026-11-20, later): on phones (<=640px) the shared CSS forced the play button to 76% for 16:9 photo
  posters even when "Centre" was chosen. The module now prints a scoped rule (`snippets/hero-center-play-phone.hubl.html`)
  only when the play position is not "Lower". Webinar 2 (Lower) is unaffected. Backup in `_backup-2026-11-20/`.

## Video playback test (2026-11-20)

Done on a temporary clone of this page with the Webinar 2 MP4 (deleted after the test; the Webinar 3 page's video
fields were not touched and are still empty):
* Play button centred at 1536 / 768 / 390 px; real mouse click and a real tap at 390px start the MP4 with sound,
  native controls, poster kept, play button hidden while playing.
* Keyboard: Tab to the player + Enter starts it; Space on the focused video pauses/resumes.
* dataLayer `lp_webinar` events: video_play (click), video_progress 25/50/90, video_complete; a broken file shows
  "The video could not be loaded here" + link and fires video_error.
* Without a video (current state): click scrolls to the calendar and fires video_missing.
* All buttons/anchors land on their sections (#book, #watch); series links 01/02 return 200; Meetings iframe 660px;
  floating "Talk to an AI Expert" shows mid-page and hides over the calendar, CTA panel and footer; no console errors.

## Assets (File Manager `/avahi-ls-webinar-3/`)

Thumbnail (JPG from the supplied PNG), AWS partner logo, Baljit Singh and Nipun Sibal photos — extracted from the
reference HTML (`assets/`). The hero AWS logo and the 7 award images are the same files Webinar 2 uses.

## QA (draft preview, 2026-11-20)

* Widths 1536, 1280, 1024, 768, 430/390, 360: no horizontal overflow, nothing left unrevealed, calendar card fits
  (355px at 390), video 16:9 on phones.
* 1 H1, H2 per section; Manrope; 48 images load; global header (1) + footer (1); new icons and scene render.
* Meetings iframe loads with the Baljit Singh link; FAQ accordion (6) opens/closes; `#book`, `#watch` anchors exist;
  series links 01 and 02 work; no console errors.
* Title, single description, canonical, og:title, og:image (thumbnail), twitter card present; no robots tag.
* Webinar 2 live page re-checked after the module change: same heading, 12 icons, original scene.

## To do

1. When DLD-250 is approved: upload the MP4 to File Manager, then hero module → Video → Video source "Uploaded
   video file" → pick it (or paste a YouTube/Vimeo link with source "Video link"). Optionally switch the overlay text on.
2. Publish the page in HubSpot.
3. Optional: on Webinar 2, link the Session 03 card to this page once it is live.
