#!/usr/bin/env python3
"""Local preview of the global header + footer (Jinja2 stands in for HubL).

Writes preview/*.html:
  standalone.html        header + sample page + footer (compare with avahi.ai)
  pov.html               AI Proof of Value reference page with its own nav/footer swapped for the global modules
  ls.html                LS webinar reference page with its footer swapped for the global footer
  editor.html            standalone page as the HubSpot editor renders it (no JS, header in flow)
Fonts: pass --fonts DIR (folder with manrope-latin-{400,500,600,700}-normal.woff2) to embed Manrope offline.
"""
import base64, json, os, re, sys
import jinja2

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
MOD = os.path.join(HERE, 'src', 'avahi-global', 'modules')
OUT = os.path.join(HERE, 'preview'); os.makedirs(OUT, exist_ok=True)

env = jinja2.Environment(autoescape=False, undefined=jinja2.ChainableUndefined, extensions=['jinja2.ext.loopcontrols'])
env.filters['escape'] = lambda s: jinja2.utils.markupsafe.escape(s if s is not None else '')
env.filters['format_date'] = lambda d, f='yyyy': '2026'


def defaults(fields):
    return {f['name']: f.get('default') for f in fields}


def render(slug, editor=False, overrides=None):
    d = os.path.join(MOD, slug + '.module')
    src = open(os.path.join(d, 'module.html')).read()
    src = re.sub(r'\{%-?\s*require_head\s*-?%\}.*?\{%-?\s*end_require_head\s*-?%\}', '', src, flags=re.S)
    vals = defaults(json.load(open(os.path.join(d, 'fields.json'))))
    vals.update(overrides or {})
    html = env.from_string(src).render(module=vals, is_in_page_editor=editor, local_dt=None)
    # HubSpot wraps every module in a div
    return f'<div id="hs_cos_wrapper_{slug}" class="hs_cos_wrapper hs_cos_wrapper_widget hs_cos_wrapper_type_module" data-hs-cos-general-type="widget" data-hs-cos-type="module">{html}</div>'


def assets(slug):
    d = os.path.join(MOD, slug + '.module')
    css = open(os.path.join(d, 'module.css')).read()
    js_p = os.path.join(d, 'module.js')
    return css, (open(js_p).read() if os.path.exists(js_p) else '')


def font_css(fdir):
    if not fdir: return ''
    out = []
    for w in (400, 500, 600, 700):
        p = os.path.join(fdir, f'manrope-latin-{w}-normal.woff2')
        b = base64.b64encode(open(p, 'rb').read()).decode()
        out.append(f"@font-face{{font-family:'Manrope';font-style:normal;font-weight:{w};font-display:block;src:url(data:font/woff2;base64,{b}) format('woff2')}}")
    return '\n'.join(out)


def page(fonts, editor=False):
    hcss, hjs = assets('avahi_site_header'); fcss, _ = assets('avahi_site_footer')
    head = render('avahi_site_header', editor); foot = render('avahi_site_footer', editor)
    sections = ''.join(f'<section class="demo demo--{i % 2}"><div><h2>Landing page section {i + 1}</h2><p>Page-specific content from Rick\'s landing page goes here. The global header and footer stay identical on every page.</p></div></section>' for i in range(5))
    return f'''<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Avahi global header + footer preview</title><style>{font_css(fonts)}</style>
<style>/* stand-in for the site wrapper rule that forces Poppins on www2.avahi.ai */
h1,h2,h3,h4,h5,h6,p,span,div,a{{font-family:Poppins,Arial,sans-serif!important}}
body{{margin:0;background:#fff;font-family:Arial}} .hero{{min-height:620px;background:radial-gradient(1200px 500px at 50% 30%,#13203f,#05070d);color:#fff;display:flex;align-items:center;justify-content:center;text-align:center}}
.hero h1{{font-size:64px;margin:0}} .demo{{padding:120px 5vw}} .demo--1{{background:#f4f6fb}} .demo h2{{font-size:40px;margin:0 0 12px}}</style>
<style>{hcss}</style><style>{fcss}</style></head><body>
{head}<main id="main"><section class="hero"><div><h1>Landing page hero</h1><p>Rick's page content starts here</p></div></section>{sections}</main>{foot}
{'' if editor else '<script>' + hjs + '</script>'}</body></html>'''


def swap_into(ref_file, fonts, swap_header=True):
    s = open(os.path.join(ROOT, ref_file), encoding='utf-8').read()
    hcss, hjs = assets('avahi_site_header'); fcss, _ = assets('avahi_site_footer')
    if swap_header:
        s, n = re.subn(r'<header class="nav" id="nav">.*?</header>', lambda m: render('avahi_site_header'), s, count=1, flags=re.S)
        assert n == 1, 'header not found in ' + ref_file
    s, n = re.subn(r'<footer\b.*?</footer>', lambda m: render('avahi_site_footer'), s, count=1, flags=re.S)
    assert n == 1, 'footer not found in ' + ref_file
    inject = f'<style>{font_css(fonts)}</style><style>{hcss}</style><style>{fcss}</style>'
    s = s.replace('</head>', inject + '</head>', 1)
    s = s.replace('</body>', f'<script>{hjs}</script></body>', 1)
    return s


if __name__ == '__main__':
    fonts = sys.argv[sys.argv.index('--fonts') + 1] if '--fonts' in sys.argv else None
    open(os.path.join(OUT, 'standalone.html'), 'w').write(page(fonts))
    open(os.path.join(OUT, 'editor.html'), 'w').write(page(fonts, editor=True))
    open(os.path.join(OUT, 'pov.html'), 'w').write(swap_into('avahi-ai-proof-of-value (3).html', fonts))
    open(os.path.join(OUT, 'ls.html'), 'w').write(swap_into('avahi-life-sciences-report-authoring-webinar-vsl.html', fonts, swap_header=False))
    print('preview written:', ', '.join(sorted(os.listdir(OUT))))
