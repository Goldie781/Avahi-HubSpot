# Avahi global header + footer (HubSpot)

One header and one footer for every Avahi HubSpot page, matching https://avahi.ai/ (captured 2026-10-30).
Both are **HubSpot global modules** (`"global": true`): content is edited once and every page that includes
them updates when the change is published. Rick's landing pages arrive without header/footer; the team builds
them on the template below, or adds the two module tags to any existing template.

| What | Path in HubSpot (after upload) | Source here |
|---|---|---|
| Global header | `/avahi-global/modules/avahi_site_header.module` | `src/avahi-global/modules/avahi_site_header.module/` |
| Global footer | `/avahi-global/modules/avahi_site_footer.module` | `src/avahi-global/modules/avahi_site_footer.module/` |
| Base template for new landing pages | `/avahi-global/templates/avahi-landing-page.html` | `src/avahi-global/templates/` |
| Template migration helper | – | `migrate_templates.py` |

## What the header and footer include

**Header** (floating pill, same size/position as avahi.ai): logo (built-in SVG or upload), top-level menu (add,
remove, reorder, up to 8; each item can be desktop+mobile, desktop only or mobile only - Partners is mobile only,
as on the live site), mega menus with up to 4 link columns and up to 3 cards (4 card styles: image + text,
large image, text + link, gradient button), **44 navigation icons from avahi.ai** selectable per link (or upload
a custom icon), "New"-style badges, language switcher (globe, hidden below 1367px like the live site), gradient
CTA, scroll-progress line, hover + click + keyboard (Enter/Space/ArrowDown/Escape), accessible mobile menu
(burger, accordions, scroll lock, language + CTA at the bottom) at 1024px and below.

**Footer**: statement + Get Started band (can be switched off), logo, about text, social pills, newsletter link,
up to 5 link columns, award badges (image + optional link), copyright (`{year}` = current year), language
switcher, legal links. Responsive at 1180 / 1024 / 640 / 380px.

Isolation: all CSS is scoped to `#avh-site-header` / `#avh-site-footer`, forces Manrope over the site-wide
Poppins `!important` rule, uses no Font Awesome class names (`fa*`), and the JS only defines
`window.AvahiSiteHeader`. Tested inside the AI Proof of Value and LS webinar designs with no CSS or JS conflicts.
Navigation clicks push `avh_nav_click` to `dataLayer` (label, URL, menu). Existing forms and tracking are untouched.

## One-time setup (HubSpot CLI)

The HubSpot connector cannot create global modules, so the first upload is done with the HubSpot CLI
(`npm i -g @hubspot/cli`, then `hs init` / `hs auth` with a Personal Access Key for portal 8985787; never commit
the key or `hubspot.config.yml`).

```bash
cd hubspot/global
python3 build.py                                   # regenerates module.html / fields.json / meta.json
hs upload src/avahi-global avahi-global            # creates the 2 global modules + the base template
```

Check in Design Manager that both modules show **Global module**. Then open any page using the new template:
the header and footer content comes from global content with the live-site defaults.

## Apply to existing pages

Pages built on `avahi-landing-page.html` (AI Proof of Value, AWS Seller list, Series A Growth Kit) and the LS
webinar (footer only - it keeps its own webinar header) are switched by swapping two module tags in their
templates. Nothing else in the templates changes.

```bash
hs fetch custom/content-mcp/pages ./_fetched --overwrite
python3 migrate_templates.py ./_fetched            # dry run - prints every line it will change
python3 migrate_templates.py ./_fetched --write    # originals are kept in ./_fetched_backup
hs upload ./_fetched custom/content-mcp/pages
```

Rollback at any time: `hs upload ./_fetched_backup custom/content-mcp/pages`.
The old modules `avahi_global_header` / `avahi_global_footer` are left in place (not deleted) so rollback works.
Template changes apply to published pages on their next render; preview each page before telling the team.

To give the LS webinar the site header as well, run step 3 with `--replace-page-headers`.

## New landing pages

* Create the page from **Avahi Landing Page (global header + footer)** and build the sections in the drag-and-drop
  area, or
* In any custom template add, at the top of `<body>` and before `{{ standard_footer_includes }}`:

```hubl
{% module "avahi_site_header" path="/avahi-global/modules/avahi_site_header" label="Avahi Site Header (global)" %}
<main id="main"> ... page content ... </main>
{% module "avahi_site_footer" path="/avahi-global/modules/avahi_site_footer" label="Avahi Site Footer (global)" %}
```

Do not copy header or footer HTML into a page. The header floats over the top of the page like on avahi.ai, so
the first section needs about 110px top padding (or set Header > Position to "push the page down").

## Editing (admins)

Open any page that uses them, click the header or footer and choose **Edit global module**. Change logo, menu labels, URLs, icons, dropdown columns and cards, CTA,
footer text, columns, social links, badges and copyright, then **Publish to all pages**. Everything on all
connected pages updates. Design, spacing and behaviour are fixed in `module.css` / `module.js`.

## Develop / test

```bash
python3 build.py
python3 preview.py --fonts <dir with manrope-latin-*-normal.woff2>   # preview/*.html (Jinja2 stands in for HubL)
python3 test/shoot.py                                                # Playwright: 75 checks + screenshots in test/shots/
```

Defaults live in `data/content.py` (copy), `data/icons.json` (44 icons taken from avahi.ai) and `data/logo.svg`.
They only seed new installs; after upload, global content in HubSpot is the source of truth for copy.

## Known gaps

* 2 of the 10 footer badges (AWS Partner, CRN AI Innovators 2026) and the mega-menu card images are hot-linked
  from avahi.ai media. Upload them to File Manager and swap them in global content to remove that dependency.
* Badge alt texts were written from the badge artwork; check them.
* The live site's Spanish link (`?lang=es`) is kept as is.
