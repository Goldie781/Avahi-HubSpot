#!/usr/bin/env python3
"""Build the Avahi global header + footer modules for HubSpot.

Writes src/avahi-global/modules/avahi_site_{header,footer}.module/{module.html,fields.json,meta.json}
from templates/*.module.html, data/icons.json, data/logo.svg and data/content.py (live-site defaults).
module.css / module.js are hand-written and live directly in the .module folders.

Upload with the HubSpot CLI (see README.md):  hs upload src/avahi-global avahi-global
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, 'data'))
import content as C  # noqa: E402

SRC = os.path.join(HERE, 'src', 'avahi-global', 'modules')
ICONS = json.load(open(os.path.join(HERE, 'data', 'icons.json')))
LOGO = open(os.path.join(HERE, 'data', 'logo.svg')).read().strip()


# ---------- field helpers ----------
def text(name, label, default='', help_text=None, multi=False):
    f = {"name": name, "label": label, "type": "text", "required": False, "locked": False,
         "allow_new_line": multi, "show_emoji_picker": False, "default": default}
    if help_text: f["help_text"] = help_text
    return f

def url(name, label, href='', help_text=None):
    f = {"name": name, "label": label, "type": "url", "required": False, "locked": False,
         "supported_types": ["EXTERNAL", "CONTENT", "FILE", "EMAIL_ADDRESS", "BLOG"],
         "default": {"href": href, "type": "EXTERNAL", "content_id": None}}
    if help_text: f["help_text"] = help_text
    return f

def boolean(name, label, default=False, help_text=None):
    f = {"name": name, "label": label, "type": "boolean", "display": "toggle", "required": False, "locked": False, "default": default}
    if help_text: f["help_text"] = help_text
    return f

def number(name, label, default, lo, hi, suffix='px', help_text=None):
    f = {"name": name, "label": label, "type": "number", "display": "text", "min": lo, "max": hi, "step": 1,
         "suffix": suffix, "required": False, "locked": False, "default": default}
    if help_text: f["help_text"] = help_text
    return f

def choice(name, label, choices, default, help_text=None):
    f = {"name": name, "label": label, "type": "choice", "display": "select", "choices": choices, "multiple": False,
         "reordering_enabled": False, "required": False, "locked": False, "default": default}
    if help_text: f["help_text"] = help_text
    return f

def image(name, label, src='', alt='', w=None, h=None, help_text=None):
    d = {"src": src, "alt": alt, "loading": "lazy", "size_type": "auto"}
    if w: d.update({"width": w, "height": h})
    f = {"name": name, "label": label, "type": "image", "required": False, "locked": False, "responsive": True,
         "resizable": True, "show_loading": False, "default": d}
    if help_text: f["help_text"] = help_text
    return f

def group(name, label, children, default=None, repeat=None, sort=None, expanded=False, help_text=None):
    f = {"name": name, "label": label, "type": "group", "required": False, "locked": False, "expanded": expanded,
         "children": children, "tab": "CONTENT"}
    if repeat:
        lo, hi, n = repeat
        f["occurrence"] = {"min": lo, "max": hi, "default": n}
        if sort: f["occurrence"]["sorting_label_field"] = sort
    if default is not None: f["default"] = default
    if help_text: f["help_text"] = help_text
    return f

def U(href):
    return {"href": href, "type": "EXTERNAL", "content_id": None}

def IMG(src, alt='', w=None, h=None):
    d = {"src": src, "alt": alt, "loading": "lazy", "size_type": "auto"}
    if w: d.update({"width": w, "height": h})
    return d


# ---------- header ----------
ICON_CHOICES = [["none", "No icon"], ["custom", "Custom image (upload in 'Custom icon')"]] + \
    [[k, C.ICON_LABELS.get(k, k)] for k in ICONS]

def header_fields():
    H = C.HEADER
    link_children = [
        text("label_text", "Link text", "Link"),
        url("url", "Link URL", "https://avahi.ai/"),
        choice("icon", "Icon", ICON_CHOICES, "sparkle", "Icons from avahi.ai. Pick 'Custom image' to upload your own (20 x 20, SVG or PNG)."),
        image("icon_image", "Custom icon", help_text="Used only when Icon is 'Custom image'."),
        text("tag", "Badge (optional)", "", "Small label after the link, e.g. New."),
        boolean("new_tab", "Open in a new tab"),
    ]
    col_children = [
        text("heading", "Column heading", "", "Leave empty to continue the column before it (no heading)."),
        boolean("hide_desktop", "Hide on desktop (show in mobile menu only)"),
        group("links", "Links", link_children, repeat=(0, 12, 0), sort="menu.columns.links.label_text"),
    ]
    card_children = [
        choice("style", "Card style", [["media", "Image + text (row)"], ["feature", "Large image on top"],
                                       ["simple", "Text + link"], ["button", "Gradient button"]], "media"),
        text("kicker", "Small label above title", ""),
        text("title", "Title (button text for the Gradient button style)", ""),
        text("text", "Description", "", multi=True),
        image("image", "Image", help_text="Shown by the 'Image + text' and 'Large image' styles."),
        url("link", "Card link", ""),
        text("link_label", "Link text (with arrow)", ""),
        boolean("new_tab", "Open in a new tab"),
    ]
    item_children = [
        text("label_text", "Menu label", "Menu"),
        url("link", "Link (used when the item has no dropdown)", ""),
        boolean("new_tab", "Open in a new tab (no-dropdown items)"),
        choice("show_on", "Show on", [["all", "Desktop and mobile"], ["desktop", "Desktop only"], ["mobile", "Mobile menu only"]], "all"),
        choice("cards_width", "Dropdown: width of the card area", [["wide", "Wide (about half)"], ["medium", "Medium (about a third)"], ["narrow", "Narrow (about a quarter)"]], "medium"),
        group("columns", "Dropdown link columns", col_children, repeat=(0, 4, 0), sort="menu.columns.heading"),
        group("cards", "Dropdown cards (right side)", card_children, repeat=(0, 3, 0), sort="menu.cards.title"),
    ]

    def link_default(l):
        return {"label_text": l["label_text"], "url": U(l["url"]), "icon": l["icon"],
                "icon_image": IMG(''), "tag": l["tag"], "new_tab": False}

    def card_default(c):
        return {"style": c["style"], "kicker": c["kicker"], "title": c["title"], "text": c["text"],
                "image": IMG(c["image"], "", c["image_w"] or None, c["image_h"] or None) if c["image"] else IMG(''),
                "link": U(c["href"]), "link_label": c["link_label"], "new_tab": False}

    menu_default = [{
        "label_text": m["label_text"], "link": U(m["href"]), "new_tab": False, "show_on": m["show_on"],
        "cards_width": m["cards_width"],
        "columns": [{"heading": c["heading"], "hide_desktop": c["hide_desktop"], "links": [link_default(l) for l in c["links"]]} for c in m["columns"]],
        "cards": [card_default(c) for c in m["cards"]],
    } for m in H["menu"]]

    lang_children = [text("label_text", "Label", "en"), text("code", "Language code (hreflang)", "en"),
                     url("link", "Link", "https://avahi.ai/"), boolean("current", "Current language")]
    lang_default = [{"label_text": l["label_text"], "code": l["code"], "link": U(l["link"]), "current": l["current"]} for l in H["languages"]]

    return [
        image("logo_image", "Logo image (optional)", help_text="Leave empty to use the built-in Avahi logo (sharp SVG). Upload an image to replace it."),
        number("logo_height", "Uploaded logo height", 40, 16, 80),
        url("logo_link", "Logo link", H["logo_link"]),
        text("logo_label", "Logo accessible label", H["logo_label"]),
        group("menu", "Menu items", item_children, default=menu_default, repeat=(0, 8, len(menu_default)), sort="menu.label_text",
              help_text="Add, remove and reorder top-level items. An item with dropdown columns or cards opens a mega menu."),
        text("cta_label", "Button label", H["cta_label"]),
        url("cta_link", "Button link", H["cta_link"]),
        boolean("cta_new_tab", "Button opens in a new tab"),
        boolean("show_language", "Show language switcher", True),
        group("languages", "Languages", lang_children, default=lang_default, repeat=(0, 6, len(lang_default)), sort="languages.label_text"),
        choice("position", "Position", [["overlay", "Float over the top of the page (like avahi.ai)"],
                                        ["push", "Float, and push the page down by the header height"]], "overlay"),
        boolean("show_progress", "Show the scroll progress line at the top", True),
        text("skip_label", "Skip link text (screen readers)", "Skip to content"),
        text("skip_target", "Skip link target", "#main", "The id of the main content, e.g. #main."),
        text("nav_label", "Navigation name (screen readers)", "Primary"),
        text("language_label", "Language switcher name (screen readers)", "Language"),
        text("menu_open_label", "Mobile menu button: open", "Open menu"),
        text("menu_close_label", "Mobile menu button: close", "Close menu"),
    ]


def footer_fields():
    F = C.FOOTER
    lk = [text("label_text", "Text", "Link"), url("link", "URL", "https://avahi.ai/"), boolean("new_tab", "Open in a new tab")]
    return [
        boolean("show_statement", "Show the statement + button band", True),
        text("statement", "Statement", F["statement"], multi=True),
        text("cta_label", "Button label", F["cta_label"]),
        url("cta_link", "Button link", F["cta_link"]),
        boolean("cta_new_tab", "Button opens in a new tab"),
        image("logo_image", "Logo image (optional)", help_text="Leave empty to use the built-in Avahi logo (white SVG)."),
        number("logo_height", "Uploaded logo height", 44, 16, 90),
        url("logo_link", "Logo link", F["logo_link"]),
        text("logo_label", "Logo accessible label", F["logo_label"]),
        text("about", "About text", F["about"], multi=True),
        text("social_title", "Social heading", F["social_title"]),
        group("social", "Social links", [text("label_text", "Name", "LinkedIn"), url("link", "URL", "https://")],
              default=[{"label_text": a, "link": U(b)} for a, b in F["social"]], repeat=(0, 8, len(F["social"])), sort="social.label_text"),
        text("newsletter_title", "Newsletter heading", F["newsletter_title"]),
        text("newsletter_label", "Newsletter link text", F["newsletter_label"]),
        url("newsletter_link", "Newsletter link", F["newsletter_link"]),
        group("columns", "Link columns", [text("heading", "Heading", "Links"),
                                          group("links", "Links", lk, repeat=(0, 16, 0), sort="columns.links.label_text")],
              default=[{"heading": h, "links": [{"label_text": a, "link": U(b), "new_tab": False} for a, b in ls]} for h, ls in F["columns"]],
              repeat=(0, 5, len(F["columns"])), sort="columns.heading"),
        text("badges_title", "Awards heading", F["badges_title"]),
        group("badges", "Award badges", [image("image", "Badge image"), url("link", "Link (optional)", "")],
              default=[{"image": IMG(s, a, w, h), "link": U(l)} for s, a, w, h, l in F["badges"]],
              repeat=(0, 14, len(F["badges"])), sort="badges.image.alt"),
        text("copyright", "Copyright", F["copyright"], "{year} is replaced by the current year."),
        boolean("show_language", "Show language switcher", True),
        group("languages", "Languages", [text("label_text", "Label", "en"), text("code", "Language code", "en"),
                                         url("link", "Link", "https://avahi.ai/"), boolean("current", "Current language")],
              default=[{"label_text": l["label_text"], "code": l["code"], "link": U(l["link"]), "current": l["current"]} for l in C.HEADER["languages"]],
              repeat=(0, 6, 2), sort="languages.label_text"),
        text("language_label", "Language switcher name (screen readers)", "Language"),
        group("legal", "Legal links", lk, default=[{"label_text": a, "link": U(b), "new_tab": False} for a, b in F["legal"]],
              repeat=(0, 6, len(F["legal"])), sort="legal.label_text"),
    ]


def meta(label, desc):
    return {"label": label, "description": desc, "global": True, "host_template_types": ["PAGE", "BLOG_POST", "BLOG_LISTING"],
            "is_available_for_new_content": False, "smart_type": "NOT_SMART", "categories": ["design"],
            "css_assets": [], "external_js": [], "js_assets": [], "other_assets": [], "tags": []}


def hubl_dict(d):
    parts = []
    for k, v in d.items():
        assert "'" not in v, k
        parts.append(f"'{k}': '{v}'")
    return '{' + ', '.join(parts) + '}'


def check_names(fields, path=''):
    bad = {"label", "name", "type", "id", "path", "order", "deleted", "body", "items", "keys", "values"}
    for f in fields:
        assert f["name"] not in bad, path + f["name"]
        if f["type"] == "group": check_names(f["children"], path + f["name"] + '.')


def write(slug, tpl, fields, label, desc):
    d = os.path.join(SRC, slug + '.module'); os.makedirs(d, exist_ok=True)
    check_names(fields)
    html = open(os.path.join(HERE, 'templates', tpl)).read()
    html = html.replace('__ICONS__', hubl_dict(ICONS)).replace('__LOGO__', LOGO)
    open(os.path.join(d, 'module.html'), 'w').write(html)
    json.dump(fields, open(os.path.join(d, 'fields.json'), 'w'), indent=2, ensure_ascii=False)
    json.dump(meta(label, desc), open(os.path.join(d, 'meta.json'), 'w'), indent=2)
    print(f'{slug}: module.html {len(html):,} B, fields.json {os.path.getsize(os.path.join(d, "fields.json")):,} B')


if __name__ == '__main__':
    write('avahi_site_header', 'header.module.html', header_fields(), 'Avahi Site Header (global)',
          'Global Avahi header: logo, mega menus with icons, language switch, CTA, mobile menu. Edit once, updates every page.')
    write('avahi_site_footer', 'footer.module.html', footer_fields(), 'Avahi Site Footer (global)',
          'Global Avahi footer: statement + CTA, link columns, social, newsletter, award badges, legal. Edit once, updates every page.')
