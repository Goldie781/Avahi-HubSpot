#!/usr/bin/env python3
"""Screenshots + interaction checks for the global header/footer previews (Playwright, headless Chromium).
Usage: python3 test/shoot.py  -> test/shots/*.png and a JSON report on stdout (non-zero exit on failure)."""
import json, os, sys
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
PREV = os.path.join(os.path.dirname(HERE), 'preview')
SHOTS = os.path.join(HERE, 'shots'); os.makedirs(SHOTS, exist_ok=True)
WIDTHS = [1521, 1366, 1280, 1024, 768, 390, 360, 320]
report = {'errors': [], 'checks': []}


def check(name, ok, info=''):
    report['checks'].append({'check': name, 'ok': bool(ok), 'info': info})


def url(f): return 'file://' + os.path.join(PREV, f)


with sync_playwright() as p:
    b = p.chromium.launch()
    for f in ('standalone.html', 'pov.html', 'ls.html', 'editor.html'):
        pg = b.new_page(viewport={'width': 1521, 'height': 695})
        errs = []
        pg.on('pageerror', lambda e, errs=errs: errs.append(str(e)))
        pg.on('console', lambda m, errs=errs: errs.append(m.text) if m.type == 'error' and 'ERR_' not in m.text and 'Failed to load resource' not in m.text else None)
        pg.goto(url(f)); pg.wait_for_timeout(600)
        tag = f.replace('.html', '')
        if f != 'ls.html':
            # header geometry + fonts
            g = pg.evaluate('''() => { const b=document.querySelector('#avh-site-header .avh-sh__bar').getBoundingClientRect();
              const t=document.querySelector('#avh-site-header .avh-sh__top'); const cs=getComputedStyle(t);
              return {x:Math.round(b.x), y:Math.round(b.y), w:Math.round(b.width), h:Math.round(b.height), font:cs.fontFamily, size:cs.fontSize, weight:cs.fontWeight}}''')
            check(f'{tag}: header font is Manrope (beats the Poppins !important rule)', g['font'].startswith('"Manrope"') or g['font'].startswith('Manrope'), g)
            if f != 'editor.html':
                check(f'{tag}: header pill geometry at 1521px matches live (77,14,1367x68)', abs(g['x'] - 77) <= 2 and abs(g['y'] - 14) <= 1 and abs(g['w'] - 1367) <= 3 and g['h'] == 68, g)
                pg.screenshot(path=os.path.join(SHOTS, f'{tag}-1521-top.png'))
                for i, label in enumerate(['AI Solutions', 'Services', 'Industries', 'Resources', 'Company']):
                    btn = pg.locator('#avh-site-header button.avh-sh__top', has_text=label)
                    btn.hover(); pg.wait_for_timeout(350)
                    vis = pg.evaluate('''(l) => { const li=[...document.querySelectorAll('#avh-site-header .avh-sh__item')].find(x=>x.querySelector('.avh-sh__top').textContent.trim()===l);
                       const p=li.querySelector('.avh-sh__panel'); const r=p.getBoundingClientRect(); return {open:li.classList.contains('is-open'), op:getComputedStyle(p).opacity, x:Math.round(r.x), y:Math.round(r.y), w:Math.round(r.width), h:Math.round(r.height), exp:li.querySelector('button').getAttribute('aria-expanded'), icons:p.querySelectorAll('.avh-sh__ic svg, .avh-sh__ic img').length}}''', label)
                    check(f'{tag}: hover opens {label} mega menu', vis['open'] and vis['exp'] == 'true' and vis['op'] == '1', vis)
                    pg.screenshot(path=os.path.join(SHOTS, f'{tag}-1521-mega-{i + 1}.png'))
                pg.mouse.move(40, 600); pg.wait_for_timeout(400)
                closed = pg.evaluate("() => !document.querySelector('#avh-site-header .avh-sh__item.is-open')")
                check(f'{tag}: mega menu closes on mouse leave', closed)
                # keyboard: focus button, Enter opens, Escape closes and returns focus
                pg.locator('#avh-site-header button.avh-sh__top', has_text='Services').focus(); pg.keyboard.press('Enter'); pg.wait_for_timeout(250)
                k1 = pg.evaluate("() => document.querySelector('#avh-site-header .avh-sh__item.is-open .avh-sh__top')?.textContent.trim()")
                pg.keyboard.press('Escape'); pg.wait_for_timeout(250)
                k2 = pg.evaluate("() => [!document.querySelector('#avh-site-header .avh-sh__item.is-open'), document.activeElement.textContent.trim()]")
                check(f'{tag}: keyboard Enter opens / Escape closes + refocuses', k1 == 'Services' and k2[0] and k2[1] == 'Services', [k1, k2])
        # footer
        pg.evaluate("document.querySelector('#avh-site-footer').scrollIntoView()"); pg.wait_for_timeout(400)
        fg = pg.evaluate('''() => { const f=document.querySelector('#avh-site-footer'); const i=f.querySelector('.avh-sf__in').getBoundingClientRect();
             const s=getComputedStyle(f.querySelector('.avh-sf__statement')); return {inX:Math.round(i.x), inW:Math.round(i.width), stSize:s.fontSize, stFont:s.fontFamily, bg:getComputedStyle(f).backgroundColor,
             badges:f.querySelectorAll('.avh-sf__badges img').length, cols:f.querySelectorAll('.avh-sf__col').length}}''')
        check(f'{tag}: footer container 1280px at x=120 (live)', abs(fg['inX'] - 120) <= 2 and fg['inW'] == 1280, fg)
        check(f'{tag}: footer has 4 link columns + 10 badges', fg['cols'] == 4 and fg['badges'] == 10, fg)
        pg.screenshot(path=os.path.join(SHOTS, f'{tag}-1521-footer.png'), full_page=False)
        fh = pg.evaluate("document.querySelector('#avh-site-footer').getBoundingClientRect().height")
        pg.set_viewport_size({'width': 1521, 'height': int(fh) + 40})
        pg.evaluate("document.querySelector('#avh-site-footer').scrollIntoView()"); pg.wait_for_timeout(300)
        pg.locator('#avh-site-footer').screenshot(path=os.path.join(SHOTS, f'{tag}-footer-full.png'))
        check(f'{tag}: no JS errors', not errs, errs[:5])
        pg.close()

    # responsive sweep on the standalone page
    for w in WIDTHS:
        pg = b.new_page(viewport={'width': w, 'height': 820})
        errs = []
        pg.on('pageerror', lambda e, errs=errs: errs.append(str(e)))
        pg.goto(url('standalone.html')); pg.wait_for_timeout(400)
        ov = pg.evaluate('() => document.documentElement.scrollWidth - document.documentElement.clientWidth')
        check(f'standalone @{w}: no horizontal overflow', ov <= 0, ov)
        bar = pg.evaluate('''() => { const b=document.querySelector('#avh-site-header .avh-sh__bar').getBoundingClientRect(); const kids=[...document.querySelectorAll('#avh-site-header .avh-sh__bar > *')].filter(e=>getComputedStyle(e).display!=='none'&&e.getBoundingClientRect().width>0);
            return {w:Math.round(b.width), overflow: kids.some(k=>{const r=k.getBoundingClientRect(); return r.right>b.right+1||r.left<b.left-1})}}''')
        check(f'standalone @{w}: header items fit inside the pill', not bar['overflow'], bar)
        pg.screenshot(path=os.path.join(SHOTS, f'standalone-{w}-top.png'))
        if w <= 1024:
            pg.click('#avh-site-header .avh-sh__burger'); pg.wait_for_timeout(300)
            st = pg.evaluate('''() => ({open:document.querySelector('#avh-site-header').classList.contains('is-menu-open'), exp:document.querySelector('.avh-sh__burger').getAttribute('aria-expanded'), lock:document.documentElement.classList.contains('avh-sh-lock'),
                 vis:getComputedStyle(document.querySelector('#avh-site-header .avh-sh__nav')).visibility, partners:[...document.querySelectorAll('#avh-site-header .avh-sh__top')].some(e=>e.textContent.trim()==='Partners'&&e.offsetParent!==null), cta:!!document.querySelector('.avh-sh__cta--sheet').offsetParent})''')
            check(f'standalone @{w}: burger opens mobile menu (Partners + CTA visible, scroll locked)', st['open'] and st['exp'] == 'true' and st['lock'] and st['vis'] == 'visible' and st['partners'] and st['cta'], st)
            pg.screenshot(path=os.path.join(SHOTS, f'standalone-{w}-menu.png'))
            pg.locator('#avh-site-header button.avh-sh__top', has_text='Services').click(); pg.wait_for_timeout(250)
            acc = pg.evaluate("() => { const p=document.querySelector('#avh-site-header .avh-sh__item.is-open .avh-sh__panel'); return p? {h:Math.round(p.getBoundingClientRect().height), links:p.querySelectorAll('a').length} : null }")
            check(f'standalone @{w}: mobile accordion opens Services', acc and acc['h'] > 100 and acc['links'] >= 15, acc)
            pg.screenshot(path=os.path.join(SHOTS, f'standalone-{w}-menu-services.png'))
            sw = pg.evaluate('() => document.querySelector("#avh-site-header .avh-sh__nav").scrollWidth - document.querySelector("#avh-site-header .avh-sh__nav").clientWidth')
            check(f'standalone @{w}: mobile menu has no horizontal overflow', sw <= 0, sw)
            pg.keyboard.press('Escape'); pg.wait_for_timeout(250)
            check(f'standalone @{w}: Escape closes mobile menu', not pg.evaluate("document.querySelector('#avh-site-header').classList.contains('is-menu-open')"))
        pg.evaluate("document.querySelector('#avh-site-footer').scrollIntoView()"); pg.wait_for_timeout(200)
        fh = pg.evaluate("document.querySelector('#avh-site-footer').getBoundingClientRect().height")
        pg.set_viewport_size({'width': w, 'height': int(fh) + 20}); pg.wait_for_timeout(150)
        pg.locator('#avh-site-footer').screenshot(path=os.path.join(SHOTS, f'standalone-{w}-footer.png'))
        check(f'standalone @{w}: no JS errors', not errs, errs[:3])
        pg.close()
    b.close()

fails = [c for c in report['checks'] if not c['ok']]
print(json.dumps({'passed': len(report['checks']) - len(fails), 'failed': len(fails), 'failures': fails}, indent=1))
sys.exit(1 if fails else 0)
