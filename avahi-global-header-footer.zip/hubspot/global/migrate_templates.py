#!/usr/bin/env python3
"""Point existing Avahi templates at the GLOBAL header/footer modules.

Only the module tags change. Everything else in each template (sections, design layers, scripts,
favicon, tracking, forms) stays byte-for-byte the same, and an untouched copy is kept in <folder>_backup/.

  hs fetch custom/content-mcp/pages ./_fetched --overwrite      # 1. pull the live template sources
  python3 migrate_templates.py ./_fetched                       # 2. dry run: shows what would change
  python3 migrate_templates.py ./_fetched --write               # 3. patch (originals saved to ./_fetched_backup)
  hs upload ./_fetched custom/content-mcp/pages                 # 4. push back (takes effect on publish/refresh)

Rollback: hs upload ./_fetched_backup custom/content-mcp/pages

Rules
- avahi_global_header tag  -> avahi_site_header (global). Page-specific headers (e.g. the LS webinar
  header avahi_ls_webinar_header) are left alone unless --replace-page-headers is passed.
- avahi_global_footer tag  -> avahi_site_footer (global). Template params on the old tag (badges=...) are
  dropped because global content now owns them.
"""
import difflib, os, re, shutil, sys

NEW_HEADER = '{% module "avahi_site_header" path="/avahi-global/modules/avahi_site_header" label="Avahi Site Header (global)" %}'
NEW_FOOTER = '{% module "avahi_site_footer" path="/avahi-global/modules/avahi_site_footer" label="Avahi Site Footer (global)" %}'
OLD_HEADER = re.compile(r'\{%-?\s*module\s+"[^"]*"\s+path="/custom/content-mcp/modules/avahi_global_header(?:\.module)?"[\s\S]*?-?%\}')
OLD_FOOTER = re.compile(r'\{%-?\s*module\s+"[^"]*"\s+path="/custom/content-mcp/modules/avahi_global_footer(?:\.module)?"[\s\S]*?-?%\}')
PAGE_HEADERS = re.compile(r'\{%-?\s*module\s+"[^"]*"\s+path="/custom/content-mcp/modules/avahi_ls_webinar_header(?:\.module)?"[\s\S]*?-?%\}')


def patch(src, replace_page_headers=False):
    out, nh = OLD_HEADER.subn(NEW_HEADER, src)
    out, nf = OLD_FOOTER.subn(NEW_FOOTER, out)
    npg = 0
    if replace_page_headers:
        out, npg = PAGE_HEADERS.subn(NEW_HEADER, out)
    return out, nh, nf, npg


def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    if not args:
        print(__doc__); sys.exit(2)
    root, write = args[0], '--write' in sys.argv
    changed = 0
    for dp, _, files in os.walk(root):
        for fn in sorted(files):
            if not fn.endswith('.html'):
                continue
            p = os.path.join(dp, fn)
            src = open(p, encoding='utf-8').read()
            out, nh, nf, npg = patch(src, '--replace-page-headers' in sys.argv)
            if out == src:
                print(f'  unchanged  {p}')
                continue
            changed += 1
            print(f'  PATCH      {p}  (header tags: {nh + npg}, footer tags: {nf})')
            for line in difflib.unified_diff(src.splitlines(), out.splitlines(), lineterm='', n=0):
                if line.startswith(('+', '-')) and not line.startswith(('+++', '---')):
                    print('     ', (line[:220] + ' ...') if len(line) > 220 else line)
            if write:
                bak = os.path.join(root.rstrip('/\\') + '_backup', os.path.relpath(p, root))
                os.makedirs(os.path.dirname(bak), exist_ok=True)
                if not os.path.exists(bak): shutil.copy2(p, bak)
                open(p, 'w', encoding='utf-8').write(out)
    print(f'{changed} template(s) {"patched" if write else "would change (dry run, add --write)"}')


if __name__ == '__main__':
    main()
