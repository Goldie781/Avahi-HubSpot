#!/usr/bin/env python3
"""Render the page locally from module defaults (Jinja2 stands in for HubL) -> preview/index.html.
The reused Design Manager modules (awards rail, FAQ, global footer) are rendered with local stand-ins
that mirror their HubSpot markup, so the preview can be compared against the reference HTML."""
import json, os, re, sys
import jinja2

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
plan = json.load(open(os.path.join(HERE, 'preview', 'page.json')))
env = jinja2.Environment(autoescape=False, undefined=jinja2.ChainableUndefined)
env.filters['escape'] = lambda s: jinja2.utils.markupsafe.escape(s if s is not None else '')

def defaults(fields):
    out = {}
    for f in fields:
        v = f.get('default')
        out[f['name']] = v
    return out

class Obj(dict):
    def __getattr__(self, k):
        v = self.get(k)
        return wrap(v)
def wrap(v):
    if isinstance(v, dict): return Obj(v)
    if isinstance(v, list): return [wrap(x) for x in v]
    return v

def render_module(slug, values=None, n=0):
    d = os.path.join(HERE, 'modules', slug)
    src = open(os.path.join(d, 'module.html')).read()
    vals = defaults(json.load(open(os.path.join(d, 'fields.json'))))
    if values: vals.update(values)
    return env.from_string(src).render(module=wrap(vals), name=f"widget_{n}")

# local stand-ins for the reused modules (same markup as in Design Manager)
REF = open(os.path.join(ROOT, 'avahi-life-sciences-report-authoring-webinar-vsl.html')).read()
FOOTER = re.search(r'<footer class="foot on-dark">.*?</footer>', REF, re.S).group(0)
AWARDS = '''<section class="awards" aria-labelledby="awards-title"><div class="awards__inner">
<h2 class="h2 split awards__title" id="awards-title">{{ module.title_1 }}{% if module.title_2 %}<br><span class="grad-text">{{ module.title_2 }}</span>{% endif %}</h2>
<div class="awards__rail" data-reveal style="--d:150"><div class="awards__track marquee marquee--reverse" data-speed="26">
{% for a in module.awards %}{% if a.image.src %}<img{% if a.square %} class="award-square"{% endif %} src="{{ a.image.src }}" alt="{{ a.image.alt|escape }}"{% if a.image.width %} width="{{ a.image.width }}" height="{{ a.image.height }}"{% endif %}>{% endif %}
{% endfor %}</div></div></div></section>'''
FAQ = '''<section class="faq" id="faq" aria-labelledby="faq-title"><div class="wrap faq__grid"><div class="faq__aside">
{% if module.eyebrow %}<p class="eyebrow" data-reveal>{{ module.eyebrow }}</p>{% endif %}
<h2 class="h2 split" id="faq-title">{{ module.title }}{% if module.link_label %}<br><a href="{{ module.link.href }}">{{ module.link_label }}</a>{% endif %}</h2></div>
<div class="faq__list" data-reveal style="--d:100">{% for q in module.questions %}{% set open = loop.first and module.first_open %}<div class="qa{% if open %} is-open{% endif %}"><h3><button class="qa__btn" type="button" aria-expanded="{% if open %}true{% else %}false{% endif %}" aria-controls="qa-{{ loop.index0 }}" id="qa-{{ loop.index0 }}-b"><span>{{ q.question }}</span><span class="qa__icon" aria-hidden="true"></span></button></h3><div class="qa__panel" id="qa-{{ loop.index0 }}" role="region" aria-labelledby="qa-{{ loop.index0 }}-b"><div>{{ q.answer }}</div></div></div>{% endfor %}</div>
</div></section>'''
STANDINS = {"avahi_awards_rail": AWARDS, "avahi_faq": FAQ}

def build(overrides=None, out='index.html', editor=False):
    overrides = overrides or {}
    css = open(os.path.join(HERE, 'shared', 'styles.css')).read()
    js = open(os.path.join(HERE, 'shared', 'scripts.js')).read()
    parts = []
    for i, (slug, label, vals) in enumerate(plan['page']):
        v = dict(vals or {}); v.update(overrides.get(slug, {}))
        if slug in STANDINS:
            parts.append(f'<div class="hs_cos_wrapper">{env.from_string(STANDINS[slug]).render(module=wrap(v))}</div>')
        else:
            parts.append(f'<div class="hs_cos_wrapper">{render_module(slug, v, i)}</div>')
    header = render_module('avahi_ls_webinar_header', overrides.get('avahi_ls_webinar_header'), 99)
    html = f'''<!DOCTYPE html><html lang="en"{' class="hs-editor"' if editor else ''}><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><title>Preview</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Manrope:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
{'' if editor else '<script>' + plan['head_js'] + '</script>'}
<style>{css}</style></head>
<body class="avh-ls" data-lp-page="preview"><a class="skip" href="#main">Skip to content</a><div class="progress" aria-hidden="true"><span></span></div>
<div class="avh-global">{header}</div>
<main id="main" class="avh-dnd">{plan['defs']}{''.join(parts)}</main>
<div class="avh-global">{FOOTER}</div>
{'' if editor else '<script>' + js + '</script>'}
</body></html>'''
    open(os.path.join(HERE, 'preview', out), 'w').write(html)
    return html

if __name__ == '__main__':
    build()
    print('preview/index.html written')
