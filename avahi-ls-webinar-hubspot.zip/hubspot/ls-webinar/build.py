#!/usr/bin/env python3
"""Build the HubSpot source for the Avahi Life Sciences webinar (VSL) landing page.

Writes:
  modules/<slug>/module.html, fields.json, meta.json   one folder per Design Manager module
  templates/avahi-ls-webinar.html                       page template (header + DnD sections + footer)
  shared/styles.css, shared/scripts.js                  locked design layer (also wrapped as modules)
  preview/page.json                                     the page plan used by preview.py

Content defaults are the approved copy from avahi-life-sciences-report-authoring-webinar-vsl.html.
Run: python3 build.py   (then: node purge.mjs && python3 preview.py)
"""
import json, os, re

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, 'src')
SN = json.load(open(os.path.join(SRC, 'snippets.json')))
# Images are hot-linked from Avahi's own media library (avahi.ai WordPress uploads + the partner-logo CDN used on avahi.ai).
# Copies of the reference artwork live in assets/ls-webinar/ for reference. Editors can swap any image from File Manager.
WP = 'https://avahi.ai/wp-content/uploads/2026/10/'
HOSTED = {  # key: (url, natural width, natural height)
    'award-stevie': (WP + 'image-2626-2-1.png', 254, 378),
    'award-inc-2025': (WP + 'image-2512-2-1.png', 351, 378),
    'award-sb100-2025': (WP + 'image-2513-2-1.png', 449, 449),
    'award-ai-excellence-2026': (WP + 'image-2515-2-1.png', 312, 312),
    'award-great-place-to-work': (WP + 'Avahi_Tech_US_English_2026_Certification_Badge-1-2-1.png', 312, 442),
    'award-crn-fg150': (WP + 'image-2664-2-1.webp', 232, 448),
    'award-globee-gold-2026': (WP + 'home-v3-3733a3eb-2-1.webp', 150, 150),
    'aws-logo': ('https://dmmcy0pwk6bqi.cloudfront.net/2c05b4a177fa28e6565ea22ca55b538326c19218', 159, 96),
}
IMG = {k: v[0] for k, v in HOSTED.items()}
IMG['aws-logo-light'] = IMG['aws-logo']
MOD_DIR = '/custom/content-mcp/modules'          # Design Manager folder used by every Avahi page

def prefix_ids(svg, old, new):
    return svg.replace(old, new)

ARROW = SN['ARROW']
AVAHI_LOGO_DARK = SN['HOSTLOGO']                  # gradient mark + black wordmark (white in the hero via CSS)
VIDEO_URL = 'https://8985787.fs1.hubspotusercontent-na1.net/hubfs/8985787/Webinar%20Recording%20Edition%20(LS%20Series%201)%20Final__-1.mp4'

# ------------------------------------------------------------------ field helpers
def T(name, label, default='', help=None, multiline=False):
    f = {"name": name, "label": label, "type": "text", "default": default}
    if multiline: f["allow_new_line"] = True
    if help: f["help_text"] = help
    return f
def TL(name, label, default, help=None, mx=20):      # repeatable single-line text
    f = {"name": name, "label": label, "type": "text", "default": default,
         "occurrence": {"min": 0, "max": mx, "default": len(default)}}
    if help: f["help_text"] = help
    return f
def RT(name, label, default=''):
    return {"name": name, "label": label, "type": "richtext", "default": default}
def URLT(name, label, default, help="A full URL, or #section-id to jump to a section on this page."):
    return {"name": name, "label": label, "type": "text", "default": default, "help_text": help}
def BOOL(name, label, default=True):
    return {"name": name, "label": label, "type": "boolean", "display": "toggle", "default": default}
def NUM(name, label, default, mn, mx, suffix=None):
    f = {"name": name, "label": label, "type": "number", "display": "text", "min": mn, "max": mx, "step": 1, "default": default}
    if suffix: f["suffix"] = suffix
    return f
def CH(name, label, choices, default, help=None):
    f = {"name": name, "label": label, "type": "choice", "display": "select", "choices": choices, "default": default}
    if help: f["help_text"] = help
    return f
def IM(name, label, src='', alt='', w=None, h=None, help=None):
    d = {"src": src, "alt": alt, "loading": "lazy", "size_type": "auto"}
    if w: d["width"], d["height"] = w, h
    f = {"name": name, "label": label, "type": "image", "responsive": True, "resizable": True, "show_loading": False, "default": d}
    if help: f["help_text"] = help
    return f
def FILE(name, label, help=None):
    f = {"name": name, "label": label, "type": "file", "picker": "file", "default": None}
    if help: f["help_text"] = help
    return f
def G(name, label, children, default, repeat=None, expanded=False):
    f = {"name": name, "label": label, "type": "group", "children": children, "expanded": expanded, "default": default}
    if repeat:
        mn, mx, sort = repeat
        f["occurrence"] = {"min": mn, "max": mx, "default": len(default), "sorting_label_field": f"{name}.{sort}" if sort else None}
    return f

BG = lambda d='paper': CH("background", "Section background", [["paper", "Light (white)"], ["cloud", "Light (grey)"]], d)
ANCHOR = lambda d: T("anchor_id", "Section ID (for #links)", d, "Letters, numbers and dashes only. Buttons that link to #" + (d or 'id') + " scroll here.")

ICONS = SN['ICONS']
ICON_CHOICES = [["clock", "Clock / time saved"], ["doc_search", "Document check"], ["person_shield", "Person + shield"],
                ["database", "Data source"], ["chart", "Chart / analysis"], ["document", "Document"], ["warning", "Warning / gap"],
                ["person_check", "Person approves"], ["shield_check", "Shield check"], ["calendar_check", "Calendar"], ["circle_check", "Check circle"]]
def icon_map():
    return "{% set icons = {" + ",".join(f"\"{k}\": '{v}'" for k, v in ICONS.items()) + "} %}"

def heading(tag, cls, id_expr):
    return (f'<{tag} class="{cls}" id="{id_expr}">{{{{ module.title_1 }}}}{{% if module.title_2 %}}<br>'
            f'<span class="grad-text">{{{{ module.title_2 }}}}</span>{{% endif %}}</{tag}>')

SEC_CLASS = '{% if module.background == "cloud" %} sec--cloud{% endif %}'
UID = '{% set uid = (name or "m")|replace(".", "-")|replace("_", "-") %}'

MODULES = []
def module(slug, label, html, fields, note=None):
    MODULES.append({"slug": slug, "label": label, "html": html.strip() + "\n", "fields": fields, "note": note})

# ================================================================== 1. page-specific header
module("avahi_ls_webinar_header", "Avahi LS Webinar Header", '''
{# Header used only on the Life Sciences webinar page: logo, series tag, a few anchor links and one CTA.
   On phones the links move into a menu behind the burger; the CTA stays visible. Also renders the floating CTA. #}
{% set has_links = module.links|length > 0 %}
<header class="nav nav--focus lpnav" id="nav">
  <div class="nav__bar">
    <a class="nav__logo" href="{{ module.logo_link }}" aria-label="{{ module.logo_label|escape }}">{% if module.logo_image.src %}<img src="{{ module.logo_image.src }}" alt="{{ module.logo_image.alt|escape }}" style="height:{{ module.logo_height }}px">{% else %}@@NAVLOGO@@{% endif %}</a>
    <span class="nav__tag">{{ module.series_tag }}</span>
    <div class="nav__actions">
      {% for l in module.links %}<a class="btn btn--{{ l.style }} btn--sm lp-navwatch" href="{{ l.link }}"{% if l.track_id %} data-track="{{ l.track_id }}"{% endif %}>{{ l.label_text }}</a>
      {% endfor %}
      {% if module.cta_label %}<a class="btn btn--primary btn--sm lp-navcta" href="{{ module.cta_link }}"{% if module.cta_track_id %} data-track="{{ module.cta_track_id }}"{% endif %}><span>{{ module.cta_label }}</span><span class="btn__icon">@@ARROW@@</span></a>{% endif %}
      {% if has_links %}<button class="nav__burger" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="lpnav-sheet"><span></span><span></span></button>{% endif %}
    </div>
    {% if has_links %}
    <nav class="lpnav__sheet" id="lpnav-sheet" aria-label="{{ module.menu_label|escape }}">
      {% for l in module.links %}<a class="lpnav__link" href="{{ l.link }}"{% if l.track_id %} data-track="{{ l.track_id }}_mobile"{% endif %}>{{ l.label_text }}</a>
      {% endfor %}
      {% if module.cta_label %}<a class="btn btn--primary" href="{{ module.cta_link }}"{% if module.cta_track_id %} data-track="{{ module.cta_track_id }}_mobile"{% endif %}><span>{{ module.cta_label }}</span><span class="btn__icon">@@ARROW@@</span></a>{% endif %}
    </nav>
    {% endif %}
  </div>
</header>
{% if module.show_fab and module.fab_label %}<a class="lp-fab" id="fab" href="{{ module.fab_link }}" data-track="fab_book"><span class="lp-fab__dot" aria-hidden="true">@@FABCAL@@</span>{{ module.fab_label }}</a>{% endif %}
''', [
    IM("logo_image", "Logo image (optional)", help="Leave empty to use the built-in Avahi logo (SVG). Upload an image to replace it."),
    NUM("logo_height", "Uploaded logo height", 40, 16, 64, "px"),
    T("logo_link", "Logo link", "https://avahi.ai/"),
    T("logo_label", "Logo accessible label", "Avahi home"),
    T("series_tag", "Series tag (next to the logo)", "CMC Intelligence Series", "Hidden on phones. Leave empty to hide."),
    G("links", "Navigation links", [
        T("label_text", "Link label", "Watch"),
        URLT("link", "Link", "#watch"),
        CH("style", "Style", [["outline", "Outline button"], ["text", "Text link"]], "outline"),
        T("track_id", "Tracking id (optional)", "nav_watch", "Sent to the dataLayer when clicked."),
    ], [{"label_text": "Watch", "link": "#watch", "style": "outline", "track_id": "nav_watch"}], repeat=(0, 4, "label_text")),
    T("menu_label", "Mobile menu accessible label", "Page sections"),
    T("cta_label", "Button label", "Book a Call"),
    URLT("cta_link", "Button link", "#book"),
    T("cta_track_id", "Button tracking id", "nav_book"),
    BOOL("show_fab", "Show floating button", True),
    T("fab_label", "Floating button label", "Book a Call"),
    URLT("fab_link", "Floating button link", "#book"),
])

# ================================================================== 2. VSL hero + video
VSL_HOSTS = [
    {"person": "Baljit Singh", "org": "Avahi Life Sciences", "logo_kind": "avahi", "logo_white": True, "logo": {"src": "", "alt": "", "loading": "lazy", "size_type": "auto"}},
    {"person": "Ashwini Ghogare, PhD", "org": "AWS Healthcare and Life Sciences", "logo_kind": "image", "logo_white": True,
     "logo": {"src": IMG['aws-logo'], "alt": "AWS", "loading": "lazy", "size_type": "auto", "width": 40, "height": 24}},
]
RATIOS = {"16:9": ("16/9", "1.778"), "4:3": ("4/3", "1.333"), "1:1": ("1/1", "1"), "21:9": ("21/9", "2.333"), "9:16": ("9/16", ".5625")}
module("avahi_ls_vsl_hero", "Avahi LS VSL Hero", '''
{# Webinar hero: headline, the session video (MP4 incl. HubSpot File Manager, YouTube, Vimeo or any embed URL),
   the main CTA and the presenters strip. The video only starts when the visitor presses play. #}
{% set v = module.video %}
{% set vurl = v.video_file if v.video_file else v.video_url %}
{% set ratios = {"16:9": ["16/9", "1.778"], "4:3": ["4/3", "1.333"], "1:1": ["1/1", "1"], "21:9": ["21/9", "2.333"], "9:16": ["9/16", ".5625"]} %}
{% set r = ratios[v.aspect_ratio] or ratios["16:9"] %}
<section class="hero hero--page lp-vsl" aria-labelledby="hero-title">
  <div class="hero__media" aria-hidden="true"><canvas class="hero__net" data-network></canvas></div>
  <div class="hero__inner">
    {% if module.pre_label %}<p class="lp-vsl__pre" data-load style="--d:150">{% if module.show_live_dot %}<span class="lp-vsl__dot" aria-hidden="true"></span>{% endif %}{{ module.pre_label }}</p>{% endif %}
    <h1 class="hero__title" id="hero-title"><span class="line"><span class="line__i" style="--d:300">{{ module.title_1 }}</span></span>{% if module.title_2 %} <span class="line"><span class="line__i grad-text" style="--d:460">{{ module.title_2 }}</span></span>{% endif %}</h1>
    {% if module.lede %}<p class="hero__lede" data-load style="--d:620">{{ module.lede }}</p>{% endif %}
    <div class="lp-vsl__stage" id="{{ v.anchor_id or 'watch' }}" data-load style="--d:760;--arn:{{ r[1] }}">
      <div class="lp-video lp-video--xl" data-video data-video-url="{{ vurl|escape }}" data-video-title="{{ v.video_title|escape }}"{% if v.poster.src %} data-poster="{{ v.poster.src }}"{% endif %} data-empty-title="{{ v.empty_title|escape }}" data-empty-text="{{ v.empty_text|escape }}" data-error-title="{{ v.error_title|escape }}" data-error-text="{{ v.error_text|escape }}" data-error-link="{{ v.error_link_label|escape }}" style="--ar:{{ r[0] }}">
        <button class="lp-video__poster" type="button" aria-label="{{ v.play_aria|escape }}">
          {% if v.poster.src %}<img class="lp-video__img" src="{{ v.poster.src }}" alt="" loading="eager">{% elif v.show_illustration %}@@VSLILL@@{% endif %}
          <span class="lp-video__shade" aria-hidden="true"></span>
          {% if v.thumb_kicker or v.thumb_title %}<span class="lp-vsl__thumb" aria-hidden="true">{% if v.thumb_kicker %}<span class="lp-vsl__kicker">{{ v.thumb_kicker }}</span>{% endif %}{% if v.thumb_title %}<span class="lp-vsl__ttl">{{ v.thumb_title }}</span>{% endif %}</span>{% endif %}
          <span class="lp-video__play" aria-hidden="true">@@PLAY@@</span>
          {% if v.badge_label %}<span class="lp-video__label">{{ v.badge_label }}</span>{% endif %}
        </button>
        <div class="lp-video__stage" aria-live="polite"></div>
        <div class="lp-video__end" hidden>
          <p class="lp-video__end-title">{{ v.end_title }}</p>
          <div class="lp-video__end-actions">
            {% if v.end_cta_label %}<a class="btn btn--primary" href="{{ v.end_cta_link }}" data-track="endcard_book"><span>{{ v.end_cta_label }}</span><span class="btn__icon">@@ARROW@@</span></a>{% endif %}
            {% if v.replay_label %}<button class="btn btn--ghost lp-video__replay" type="button">{{ v.replay_label }}</button>{% endif %}
          </div>
        </div>
      </div>
      {% if v.caption %}<p class="lp-vsl__caption">{{ v.caption }}</p>{% endif %}
    </div>
    {% if module.cta_label or module.micro_text %}
    <div class="lp-vsl__cta" data-load style="--d:900">
      {% if module.cta_label %}<a class="btn btn--primary btn--lg" href="{{ module.cta_link }}" data-track="hero_book"><span>{{ module.cta_label }}</span><span class="btn__icon">@@ARROW@@</span></a>{% endif %}
      {% if module.micro_text %}<p class="lp-vsl__micro">{{ module.micro_text }}</p>{% endif %}
    </div>
    {% endif %}
    {% if module.hosts|length > 0 %}
    <div class="lp-vsl__hosts" data-load style="--d:1000">
      {% if module.hosts_label %}<span class="lp-vsl__hosts-label">{{ module.hosts_label }}</span>{% endif %}
      {% for h in module.hosts %}{% if not loop.first %}<span class="lp-vsl__sep" aria-hidden="true"></span>{% endif %}<span class="lp-vsl__host"><b>{{ h.person }}</b> {{ h.org }}{% if h.logo_kind == "avahi" %}@@HEROLOGO@@{% elif h.logo_kind == "image" and h.logo.src %}<img src="{{ h.logo.src }}" alt="{{ h.logo.alt|escape }}"{% if h.logo_white is not defined or h.logo_white %} class="is-white"{% endif %}{% if h.logo.width %} width="{{ h.logo.width }}" height="{{ h.logo.height }}"{% endif %}>{% endif %}</span>{% endfor %}
    </div>
    {% endif %}
  </div>
</section>
''', [
    T("pre_label", "Label above the headline", "Your session is ready. Press play."),
    BOOL("show_live_dot", "Show pulsing dot in the label", True),
    T("title_1", "Headline line 1", "Give Your Scientists"),
    T("title_2", "Headline line 2 (gradient)", "Their Time Back"),
    T("lede", "Supporting text", "Watch an AI agent turn raw lab data into a reviewer-ready technical report in minutes, with a scientist approving every output."),
    G("video", "Video", [
        T("video_url", "Video URL", VIDEO_URL, "Direct MP4/WebM link (HubSpot File Manager works), a YouTube or Vimeo link, or any embed URL (HubSpot video, Wistia, Loom). Leave empty to show a 'coming soon' message."),
        FILE("video_file", "Or pick a video from File Manager (overrides the URL)"),
        T("video_title", "Video title (accessibility)", "AI-powered technical report authoring session"),
        IM("poster", "Poster / thumbnail image (optional)", help="Shown before play and used as the video poster. Leave empty to use the animated illustration."),
        BOOL("show_illustration", "Show animated illustration when no poster image", True),
        T("thumb_kicker", "Thumbnail kicker", "Session 01 | CMC Intelligence Series"),
        T("thumb_title", "Thumbnail title", "AI-Powered Technical Report Authoring"),
        T("badge_label", "Label on the video", "Watch the full session"),
        T("play_aria", "Play button accessible label", "Play the session: AI-powered technical report authoring"),
        CH("aspect_ratio", "Aspect ratio", [["16:9", "16:9 (default)"], ["4:3", "4:3"], ["1:1", "1:1"], ["21:9", "21:9"], ["9:16", "9:16 (vertical)"]], "16:9"),
        T("caption", "Caption under the video (optional)", ""),
        T("anchor_id", "Video section ID (for #links)", "watch"),
        T("end_title", "End screen heading", "Ready to see it run on your reports?"),
        T("end_cta_label", "End screen button label", "Book a Call"),
        URLT("end_cta_link", "End screen button link", "#book"),
        T("replay_label", "Replay button label", "Replay"),
        T("empty_title", "Message when no video is set: heading", "Video coming soon"),
        T("empty_text", "Message when no video is set: text", "The session recording will appear here."),
        T("error_title", "Message when the video fails: heading", "This video could not be loaded"),
        T("error_text", "Message when the video fails: text", "Please try again, or open it directly."),
        T("error_link_label", "Message when the video fails: link label", "Open the video in a new tab"),
    ], {"video_url": VIDEO_URL, "video_file": None, "video_title": "AI-powered technical report authoring session",
        "poster": {"src": "", "alt": "", "loading": "lazy", "size_type": "auto"}, "show_illustration": True,
        "thumb_kicker": "Session 01 | CMC Intelligence Series", "thumb_title": "AI-Powered Technical Report Authoring",
        "badge_label": "Watch the full session", "play_aria": "Play the session: AI-powered technical report authoring",
        "aspect_ratio": "16:9", "caption": "", "anchor_id": "watch", "end_title": "Ready to see it run on your reports?",
        "end_cta_label": "Book a Call", "end_cta_link": "#book", "replay_label": "Replay",
        "empty_title": "Video coming soon", "empty_text": "The session recording will appear here.",
        "error_title": "This video could not be loaded", "error_text": "Please try again, or open it directly.",
        "error_link_label": "Open the video in a new tab"}, expanded=True),
    T("cta_label", "Button label", "Book a Call After You Watch"),
    URLT("cta_link", "Button link", "#book"),
    T("micro_text", "Text under the button", "Pick a time on the calendar below. You meet Avahi's life sciences team."),
    T("hosts_label", "Presenters label", "Presented by"),
    G("hosts", "Presenters", [
        T("person", "Name", ""), T("org", "Organisation", ""),
        CH("logo_kind", "Logo", [["avahi", "Avahi logo (built in)"], ["image", "Uploaded image"], ["none", "No logo"]], "image"),
        IM("logo", "Logo image", help="Used when Logo is 'Uploaded image'."),
        BOOL("logo_white", "Show the uploaded logo in white (for the dark hero)", True),
    ], VSL_HOSTS, repeat=(0, 4, "person")),
])

# ================================================================== 3. feature cards
CARDS = [
    ("clock", "Cut Report Drafting Time by 40 to 60%", "Watch a live demo of the system turning raw instrument data and lab notebooks into a complete method qualification report, the same drafting work that normally pulls scientists out of the lab for weeks."),
    ("doc_search", "Catch Costly Gaps Before They Reach the FDA", "The system flags missing data against the regulatory guidance it is built on, catching the kind of gap that leads to a Refuse-to-File and months of clinical delay, before it ever leaves your team."),
    ("person_shield", "GxP-Eligible, Human-in-the-Loop by Design", "Built on AWS infrastructure for regulated industries, with full traceability on every action. The system handles drafting. Your scientists review and approve every draft."),
]
module("avahi_ls_feature_cards", "Avahi LS Feature Cards", UID + icon_map() + '''
{# Section head (eyebrow, two-line heading, supporting text) and a grid of icon cards. #}
<section class="sec''' + SEC_CLASS + '''"{% if module.anchor_id %} id="{{ module.anchor_id }}"{% endif %} aria-labelledby="{{ uid }}-title">
  <div class="wrap">
    <div class="sec__head">
      {% if module.eyebrow %}<p class="eyebrow" data-reveal>{{ module.eyebrow }}</p>{% endif %}
      ''' + heading('h2', 'h2 split', '{{ uid }}-title') + '''
      {% if module.lede %}<div class="sec__side" data-reveal style="--d:120"><p class="lede">{{ module.lede }}</p></div>{% endif %}
    </div>
    <div class="card-grid" style="--cols:{{ module.columns }}">
      {% for c in module.cards %}<div class="card card--lift" data-spot data-reveal style="--d:{{ loop.index0 * 90 }}"><svg class="icon-mono draw card__icon" viewBox="0 0 48 48" aria-hidden="true">{{ icons[c.icon] }}</svg><h3 class="card__title">{{ c.title }}</h3><p class="card__text">{{ c.text }}</p></div>
      {% endfor %}
    </div>
  </div>
</section>
''', [
    T("eyebrow", "Eyebrow", "Inside the Session"),
    T("title_1", "Heading line 1", "What You Will See"),
    T("title_2", "Heading line 2 (gradient)", "in the Demo"),
    T("lede", "Supporting text", "Scientists spend 40 to 60% of their time drafting reports instead of doing lab work. A single error in a regulatory submission can trigger a Refuse-to-File, cascading into months of delay and millions in lost revenue."),
    CH("columns", "Cards per row (desktop)", [["2", "2"], ["3", "3"], ["4", "4"]], "3"),
    G("cards", "Cards", [CH("icon", "Icon", ICON_CHOICES, "clock"), T("title", "Title", ""), T("text", "Text", "")],
      [{"icon": i, "title": t, "text": x} for i, t, x in CARDS], repeat=(1, 8, "title")),
    BG("paper"), ANCHOR(""),
])

# ================================================================== 4. booking calendar
module("avahi_ls_booking", "Avahi LS Booking", UID + '''
{# Booking section: copy and checklist on the left, the HubSpot meetings calendar on the right.
   The calendar loads lazily; if it cannot load, a button opens the booking link in a new tab. #}
<section class="sec''' + SEC_CLASS + ''' lp-booksec" id="{{ module.anchor_id or 'book' }}" aria-labelledby="{{ uid }}-title">
  <div class="wrap lp-book">
    <div class="lp-book__copy">
      {% if module.eyebrow %}<p class="eyebrow" data-reveal>{{ module.eyebrow }}</p>{% endif %}
      ''' + heading('h2', 'h2 split', '{{ uid }}-title') + '''
      {% if module.lede %}<p class="lede" data-reveal style="--d:100">{{ module.lede }}</p>{% endif %}
      {% if module.list_label %}<p class="lp-book__label" data-reveal style="--d:160">{{ module.list_label }}</p>{% endif %}
      {% if module.checklist|length > 0 %}<ul class="checklist lp-book__list" data-reveal style="--d:200">{% for it in module.checklist %}<li>{{ it }}</li>{% endfor %}</ul>{% endif %}
      {% if module.note %}<div class="lp-book__note" data-reveal style="--d:260"><svg class="icon-mono draw" viewBox="0 0 48 48" aria-hidden="true">@@ICON_shield_check@@</svg><p>{{ module.note }}</p></div>{% endif %}
    </div>
    <div class="lp-cal" data-reveal style="--d:120"{% if module.linkedin_conversion_id %} data-linkedin-conversion="{{ module.linkedin_conversion_id|escape }}"{% endif %}>
      <div class="lp-cal__head"><span class="lp-cal__icon" aria-hidden="true">@@CALHEAD@@</span><div><p class="lp-cal__title">{{ module.card_title }}</p><p class="lp-cal__sub">{{ module.card_sub }}</p></div></div>
      <div class="lp-cal__body">
        <div class="meetings-iframe-container" id="lp-meetings" data-meeting-url="{{ module.meeting_url|escape }}"></div>
        <div class="lp-cal__skeleton" aria-hidden="true">
          <div class="lp-sk__bar"></div>
          <div class="lp-sk__grid">{% for k in range(35) %}<i style="--k:{{ k }}"{% if k in [9, 11, 16, 18, 23, 25, 30] %} class="on"{% endif %}></i>{% endfor %}</div>
          <p class="lp-sk__text">{{ module.loading_text }}</p>
        </div>
        <div class="lp-cal__fallback" hidden>
          <svg class="icon-mono draw" viewBox="0 0 48 48" aria-hidden="true">@@ICON_calendar_check@@</svg>
          <p class="lp-cal__fb-title">{{ module.fallback_title }}</p>
          <p class="lp-cal__fb-text">{{ module.fallback_text }}</p>
          <a class="btn btn--primary" href="{{ module.meeting_url|escape }}" target="_blank" rel="noopener" data-track="fallback_book"><span>{{ module.fallback_button }}</span><span class="btn__icon">@@ARROW@@</span></a>
        </div>
        <div class="lp-cal__done" hidden>
          <svg class="icon-mono" viewBox="0 0 48 48" aria-hidden="true">@@ICON_circle_check@@</svg>
          <p class="lp-cal__fb-title">{{ module.done_title }}</p>
          <p class="lp-cal__fb-text">{{ module.done_text }}</p>
        </div>
      </div>
    </div>
  </div>
</section>
''', [
    T("eyebrow", "Eyebrow", "Book a Call"),
    T("title_1", "Heading line 1", "See It Run on"),
    T("title_2", "Heading line 2 (gradient)", "Your Reports"),
    T("lede", "Supporting text", "Bring one report type your team writes every month. We will walk through how the agent would draft it from your data, and what a Proof of Value would take."),
    T("list_label", "Checklist label", "What we cover on the call"),
    TL("checklist", "Checklist items", [
        "Where drafting time goes in your current report workflow",
        "Which report type to pilot first, from method qualification to batch records",
        "GxP, validation, and audit trail questions from your QA team",
        "Scope for a Proof of Value, plus partner funding that can offset its cost"]),
    T("note", "Note box text (leave empty to hide)", "You meet Avahi's life sciences team. Come with one report workflow in mind. No data or files needed."),
    T("card_title", "Calendar card heading", "Pick a time that works"),
    T("card_sub", "Calendar card subheading", "Times show in your local time zone"),
    T("meeting_url", "HubSpot meetings link", "https://meetings.hubspot.com/varun-kapoor2", "Your HubSpot scheduling page link (Sales > Meetings). UTM parameters on the page URL are passed through."),
    T("loading_text", "Loading text", "Loading the calendar"),
    T("fallback_title", "Fallback heading (if the calendar cannot load)", "Open the booking calendar"),
    T("fallback_text", "Fallback text", "The calendar opens in a new tab. Pick a slot and the invite lands in your inbox."),
    T("fallback_button", "Fallback button label", "Choose a Time"),
    T("done_title", "Booked heading", "You are booked"),
    T("done_text", "Booked text", "The calendar invite is on its way. Come with one report type in mind and we will use it as the starting point."),
    T("linkedin_conversion_id", "LinkedIn conversion id (optional)", "", "Fires a LinkedIn Insight conversion when a meeting is booked."),
    BG("cloud"), ANCHOR("book"),
])

# ================================================================== 5. process timeline
STEPS = [
    ("database", "Source files", "Ingest", "Raw instrument output and lab notebook entries go in as your team captured them."),
    ("chart", "Analysis", "Analyze", "Results are calculated and checked against the regulatory guidance the system is built on."),
    ("document", "Minutes", "Draft", "The agent writes a complete, reviewer-ready technical report in your format."),
    ("warning", "Before review", "Flag Gaps", "Missing data is called out, the kind of gap that leads to a Refuse-to-File."),
    ("person_check", "Sign-off", "Approve", "A scientist reviews, edits, and approves. Every action is traceable."),
]
module("avahi_ls_process_timeline", "Avahi LS Process Timeline", UID + icon_map() + '''
{# Process timeline: the rail fills as the visitor scrolls and each step lights up. Vertical on tablets and phones. #}
<section class="sec''' + SEC_CLASS + '''"{% if module.anchor_id %} id="{{ module.anchor_id }}"{% endif %} aria-labelledby="{{ uid }}-title">
  <div class="wrap">
    <div class="sec__head">
      {% if module.eyebrow %}<p class="eyebrow" data-reveal>{{ module.eyebrow }}</p>{% endif %}
      ''' + heading('h2', 'h2 split', '{{ uid }}-title') + '''
      {% if module.lede %}<div class="sec__side" data-reveal style="--d:120"><p class="lede">{{ module.lede }}</p></div>{% endif %}
    </div>
    <div class="timeline" style="--n:{{ module.steps|length }}"><div class="timeline__rail"><span class="timeline__fill"></span></div><ol class="timeline__steps">
      {% for s in module.steps %}<li class="timeline__step"><span class="timeline__node"><svg class="icon-mono draw" viewBox="0 0 48 48" aria-hidden="true">{{ icons[s.icon] }}</svg></span>{% if s.when %}<p class="timeline__when">{{ s.when }}</p>{% endif %}<h3 class="timeline__title">{{ s.title }}</h3><p class="timeline__text">{{ s.text }}</p></li>
      {% endfor %}
    </ol></div>
  </div>
</section>
''', [
    T("eyebrow", "Eyebrow", "How It Works"),
    T("title_1", "Heading line 1", "From Raw Data to"),
    T("title_2", "Heading line 2 (gradient)", "an Approved Draft"),
    T("lede", "Supporting text", "Five steps run in sequence. Nothing leaves your team until a scientist signs off."),
    G("steps", "Steps", [CH("icon", "Icon", ICON_CHOICES, "document"), T("when", "Small label", ""), T("title", "Title", ""), T("text", "Text", "")],
      [{"icon": i, "when": w, "title": t, "text": x} for i, w, t, x in STEPS], repeat=(2, 6, "title")),
    BG("paper"), ANCHOR(""),
])

# ================================================================== 6. before / after compare
module("avahi_ls_compare", "Avahi LS Compare", UID + '''
{# Two-column comparison: the old way strikes through, the Avahi way checks in. #}
<section class="sec''' + SEC_CLASS + '''"{% if module.anchor_id %} id="{{ module.anchor_id }}"{% endif %} aria-labelledby="{{ uid }}-title">
  <div class="wrap">
    <div class="sec__head">
      {% if module.eyebrow %}<p class="eyebrow" data-reveal>{{ module.eyebrow }}</p>{% endif %}
      ''' + heading('h2', 'h2 split', '{{ uid }}-title') + '''
      {% if module.lede %}<div class="sec__side" data-reveal style="--d:120"><p class="lede">{{ module.lede }}</p></div>{% endif %}
    </div>
    <div class="compare" data-observe>
      <div class="compare__col compare__col--before"><p class="compare__label">{{ module.before_label }}</p><ul class="compare__list">{% for it in module.before_items %}<li style="--i:{{ loop.index0 }}"><span><span class="compare__strike">{{ it }}</span></span></li>{% endfor %}</ul></div>
      <div class="compare__col compare__col--after" data-spot><p class="compare__label">{{ module.after_label }}</p><ul class="compare__list">{% for it in module.after_items %}<li style="--i:{{ loop.index0 }}">{{ it }}</li>{% endfor %}</ul></div>
    </div>
  </div>
</section>
''', [
    T("eyebrow", "Eyebrow (optional)", ""),
    T("title_1", "Heading line 1", "Manual Drafting vs."),
    T("title_2", "Heading line 2 (gradient)", "Agent-Drafted Reports"),
    T("lede", "Supporting text", "Same reviewers and the same regulatory bar. The difference is who writes the first draft."),
    T("before_label", "Left column label", "Manual drafting"),
    TL("before_items", "Left column items", [
        "Scientists pulled out of the lab for weeks per report", "Results copied by hand from instruments and notebooks",
        "Gaps surface late, sometimes at the agency", "Review cycles spent on formatting and consistency",
        "Edits and approvals scattered across email threads"], mx=10),
    T("after_label", "Right column label", "With Avahi's report agent"),
    TL("after_items", "Right column items", [
        "A complete draft from raw data in minutes", "Data read directly from the source files",
        "Gaps flagged against regulatory guidance before review", "Reviewers spend their time on the science",
        "Full traceability on every action"], mx=10),
    BG("cloud"), ANCHOR(""),
])

# ================================================================== 7. dark feature panel
module("avahi_ls_dark_panel", "Avahi LS Dark Panel", UID + '''
{# Dark rounded panel: animated illustration (or an uploaded image) beside a heading, text, checklist and button. #}
<section class="rapid on-dark lp-gxp"{% if module.anchor_id %} id="{{ module.anchor_id }}"{% endif %} aria-labelledby="{{ uid }}-title">
  <div class="wrap rapid__grid">
    <div class="rapid__media">
      <div class="rapid__frame" id="rapid-frame">
        {% if module.media == "image" and module.image.src %}<img src="{{ module.image.src }}" alt="{{ module.image.alt|escape }}" loading="lazy">{% else %}@@GXPILL@@{% endif %}
      </div>
    </div>
    <div class="rapid__copy">
      {% if module.eyebrow %}<p class="eyebrow" data-reveal>{{ module.eyebrow }}</p>{% endif %}
      ''' + heading('h2', 'h2 split', '{{ uid }}-title') + '''
      {% if module.lede %}<p class="lede" data-reveal style="--d:120">{{ module.lede }}</p>{% endif %}
      {% if module.checklist|length > 0 %}<ul class="checklist" data-reveal style="--d:180">{% for it in module.checklist %}<li>{{ it }}</li>{% endfor %}</ul>{% endif %}
      {% if module.button_label %}<div data-reveal style="--d:240"><a class="btn btn--primary btn--lg" href="{{ module.button_link }}" data-track="gxp_book"><span>{{ module.button_label }}</span><span class="btn__icon">@@ARROW@@</span></a></div>{% endif %}
    </div>
  </div>
</section>
''', [
    T("eyebrow", "Eyebrow", "Built for Regulated Work"),
    T("title_1", "Heading line 1", "Scientists Approve"),
    T("title_2", "Heading line 2 (gradient)", "Every Draft"),
    T("lede", "Supporting text", "The agent prepares the draft. Your scientists make every call, and every step leaves a record your QA team can audit."),
    TL("checklist", "Checklist items", ["GxP-eligible AWS infrastructure for regulated industries", "Full traceability on every action",
        "Drafts stay inside your team until a scientist signs off", "Operational efficiency only; no automated regulatory decisions"], mx=8),
    T("button_label", "Button label", "Book a Call"),
    URLT("button_link", "Button link", "#book"),
    CH("media", "Visual", [["illustration", "Animated illustration (review & approval)"], ["image", "Uploaded image"]], "illustration"),
    IM("image", "Image (when Visual is 'Uploaded image')", help="Displayed in the 16:10 rounded frame."),
    ANCHOR(""),
])

# ================================================================== 8. presenters + series
SERIES = [("01", "AI-Powered Technical Report Authoring", True, "This session"), ("02", "AI-Powered Batch Record Review", False, ""),
          ("03", "AI-Powered Method Qualification and Analytical Data Review", False, ""), ("04", "AI-Powered IND/IMPD Authoring", False, "")]
module("avahi_ls_presenters", "Avahi LS Presenters", UID + '''
{# Presenter cards (photo optional, organisation logo) and the webinar series list. #}
<section class="sec''' + SEC_CLASS + '''"{% if module.anchor_id %} id="{{ module.anchor_id }}"{% endif %} aria-labelledby="{{ uid }}-title">
  <div class="wrap">
    <div class="sec__head">
      {% if module.eyebrow %}<p class="eyebrow" data-reveal>{{ module.eyebrow }}</p>{% endif %}
      ''' + heading('h2', 'h2 split', '{{ uid }}-title') + '''
      {% if module.lede %}<div class="sec__side" data-reveal style="--d:120"><p class="lede">{{ module.lede }}</p></div>{% endif %}
    </div>
    {% if module.hosts|length > 0 %}
    <div class="lp-hostgrid">
      {% for h in module.hosts %}<div class="card card--lift lp-host" data-spot data-reveal style="--d:{{ loop.index0 * 90 }}">
        {% if h.photo.src %}<span class="lp-face lp-face--photo"><img src="{{ h.photo.src }}" alt="{{ h.photo.alt|escape }}" loading="lazy"></span>{% else %}<span class="lp-face" aria-hidden="true">@@FACE@@</span>{% endif %}
        <div><h3 class="card__title">{{ h.person }}</h3><p class="card__text">{{ h.role }}</p></div>
        {% if h.logo_kind == "avahi" %}<span class="lp-host__org">@@CARDLOGO@@</span>{% elif h.logo_kind == "image" and h.logo.src %}<span class="lp-host__org"><img src="{{ h.logo.src }}" alt="{{ h.logo.alt|escape }}"{% if h.logo.width %} width="{{ h.logo.width }}" height="{{ h.logo.height }}"{% endif %}></span>{% endif %}
      </div>
      {% endfor %}
    </div>
    {% endif %}
    {% if module.show_series and module.series|length > 0 %}
    <div class="lp-series" data-reveal style="--d:120">
      {% if module.series_label %}<p class="lp-series__label">{{ module.series_label }}</p>{% endif %}
      <ol class="lp-series__list">
        {% for s in module.series %}<li{% if s.current %} class="is-current"{% endif %} data-spot><span class="lp-series__num">{{ s.num }}</span><span class="lp-series__name">{{ s.session_name }}</span>{% if s.tag %}<span class="lp-series__tag">{{ s.tag }}</span>{% endif %}</li>
        {% endfor %}
      </ol>
      {% if module.series_note %}<p class="lp-series__note">{{ module.series_note }}</p>{% endif %}
    </div>
    {% endif %}
  </div>
</section>
''', [
    T("eyebrow", "Eyebrow", "Presented By"),
    T("title_1", "Heading line 1", "Avahi and"),
    T("title_2", "Heading line 2 (gradient)", "AWS Life Sciences"),
    T("lede", "Supporting text", "Avahi is an AWS Premier Tier Partner helping life sciences and biotech organizations build secure, GxP-eligible AI solutions that accelerate drug development timelines, from early CMC workflows through regulatory submission."),
    G("hosts", "Presenters", [
        T("person", "Name", ""), T("role", "Role / organisation", ""),
        IM("photo", "Photo (optional)", help="Square headshot. Leave empty to show the icon."),
        CH("logo_kind", "Organisation logo", [["avahi", "Avahi logo (built in)"], ["image", "Uploaded image"], ["none", "No logo"]], "image"),
        IM("logo", "Logo image"),
    ], [
        {"person": "Baljit Singh", "role": "Avahi Life Sciences Practice", "photo": {"src": "", "alt": "", "loading": "lazy", "size_type": "auto"},
         "logo_kind": "avahi", "logo": {"src": "", "alt": "", "loading": "lazy", "size_type": "auto"}},
        {"person": "Ashwini Ghogare, PhD", "role": "AWS Healthcare and Life Sciences", "photo": {"src": "", "alt": "", "loading": "lazy", "size_type": "auto"},
         "logo_kind": "image", "logo": {"src": IMG['aws-logo'], "alt": "AWS", "loading": "lazy", "size_type": "auto", "width": 46, "height": 28}},
    ], repeat=(0, 6, "person")),
    BOOL("show_series", "Show the series list", True),
    T("series_label", "Series label", "The CMC Intelligence Series"),
    G("series", "Series sessions", [T("num", "Number", ""), T("session_name", "Session title", ""), BOOL("current", "Highlight (this session)", False), T("tag", "Tag (optional)", "")],
      [{"num": n, "session_name": t, "current": c, "tag": g} for n, t, c, g in SERIES], repeat=(0, 8, "session_name")),
    T("series_note", "Series note", "One call covers any of the four. Tell us which workflow costs your team the most time."),
    BG("paper"), ANCHOR(""),
])

# ================================================================== 9. CTA panel
module("avahi_ls_cta_panel", "Avahi LS CTA Panel", '''
{# Gradient CTA panel with flowing signal lines, a cursor spotlight and up to two buttons. #}
<section class="cta"{% if module.anchor_id %} id="{{ module.anchor_id }}"{% endif %} aria-labelledby="cta-title">
  <div class="wrap">
    <div class="cta__panel" id="cta-panel" data-reveal>
      <svg class="cta__lines" id="cta-lines" viewBox="0 0 1200 600" preserveAspectRatio="none" aria-hidden="true"></svg>
      <div class="cta__spot" aria-hidden="true"></div>
      <h2 class="cta__title split" id="cta-title">{{ module.title }}</h2>
      {% if module.text %}<p class="cta__text">{{ module.text }}</p>{% endif %}
      {% if module.primary_label or module.secondary_label %}
      <div class="cta__actions">
        {% if module.primary_label %}<a class="btn btn--white btn--lg magnetic" href="{{ module.primary_link }}" data-track="cta_book"><span>{{ module.primary_label }}</span><span class="btn__icon">@@ARROW@@</span></a>{% endif %}
        {% if module.secondary_label %}<a class="btn btn--ghost btn--lg magnetic" href="{{ module.secondary_link }}" data-track="cta_rewatch">{{ module.secondary_label }}</a>{% endif %}
      </div>
      {% endif %}
    </div>
  </div>
</section>
''', [
    T("title", "Heading", "Put the agent on your next technical report."),
    T("text", "Text", "Book a call with Avahi's life sciences team. We will map the workflow to one report your scientists write today and scope a Proof of Value."),
    T("primary_label", "Primary button label", "Book a Call"),
    URLT("primary_link", "Primary button link", "#book"),
    T("secondary_label", "Secondary button label (optional)", "Rewatch the Session"),
    URLT("secondary_link", "Secondary button link", "#watch"),
    ANCHOR(""),
])

# ================================================================== locked design layer
# The CSS is split in two modules at a top-level rule boundary (see split_css) to keep each module source small.
LOCK = "Locked. Do not edit here."
module("avahi_ls_webinar_styles", "Avahi LS Webinar Styles", "{% raw %}<style id=\"avahi-ls-webinar-css-a\">@@CSS_A@@</style>{% endraw %}",
       [T("note", "Locked design layer (part 1 of 2) - edit in GitHub: hubspot/ls-webinar/src, rebuild with purge.mjs", LOCK)])
module("avahi_ls_webinar_styles_b", "Avahi LS Webinar Styles B", "{% raw %}<style id=\"avahi-ls-webinar-css-b\">@@CSS_B@@</style>{% endraw %}",
       [T("note", "Locked design layer (part 2 of 2) - edit in GitHub: hubspot/ls-webinar/src, rebuild with purge.mjs", LOCK)])
module("avahi_ls_webinar_scripts", "Avahi LS Webinar Scripts", "{% raw %}<script id=\"avahi-ls-webinar-js\">@@JS@@</script>{% endraw %}",
       [T("note", "Locked behaviour layer - edit in GitHub: hubspot/ls-webinar/src, rebuild with purge.mjs", LOCK)])

def split_css(css):
    """Split at a fixed rule (start of the section-component styles) so each half stays stable between builds;
    falls back to the first top-level rule end past the midpoint."""
    i = css.find('.card-grid{')
    if i > 0: return css[:i], css[i:]
    depth, mid = 0, len(css) // 2
    for i, ch in enumerate(css):
        if ch == '{': depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0 and i > mid: return css[:i + 1], css[i + 1:]
    return css, ''

# ------------------------------------------------------------------ reused, existing modules + page values
FAQ = [
    ("Who should book this call?", "Heads of CMC, analytical development, process development, quality, and regulatory teams at biotech, pharma, and CDMO organizations that write technical reports on a regular schedule."),
    ("What happens on the call?", "We review your current report workflow and pick the first report type to pilot. Then we answer your GxP and validation questions. If there is a fit, we scope a Proof of Value."),
    ("Does the AI make regulatory decisions?", "No. The system drafts the report and flags missing data. Scientists review, edit, and approve every output, and every action is traceable."),
    ("Which reports can the agent draft?", "The demo builds a method qualification report from raw instrument data and lab notebooks. On the call we map the report types your team writes most and choose where to start."),
    ("Is funding available for a pilot?", "Partner programs, including AWS funding, can offset the cost of a Proof of Value or a production buildout. Eligibility depends on the project, and we confirm it on the call."),
]
def img(key, alt, w=None, h=None):
    u, nw, nh = HOSTED[key.replace('footer-award-', 'award-')]
    return {"src": u, "alt": alt, "loading": "lazy", "size_type": "auto", "width": nw, "height": nh}
AW = [("stevie", "The American Business Awards, Stevie Awards", 180, 256), ("ai-excellence-2026", "Artificial Intelligence Excellence Award 2026", 204, 205),
      ("inc-2025", "Inc. Best in Business 2025, Best AI Implementation", 207, 221), ("sb100-2025", "Best of Small Business Awards 2025 Winner, SB100", 229, 216),
      ("great-place-to-work", "Great Place To Work Certified, June 2026 to June 2027, USA", 138, 225), ("crn-fg150", "CRN Fast Growth 150, 2026", 120, 221)]
AWARDS_VALUES = {"title_1": "Recognized Among", "title_2": "the Best in Business",
    "awards": [{"image": img("award-" + k, a, w, h), "square": False} for k, a, w, h in AW] +
              [{"image": img("award-globee-gold-2026", "2026 Globee Awards Gold Winner, Leadership", 320, 320), "square": True}]}
FAQ_VALUES = {"eyebrow": "FAQ", "title": "Questions Before", "link_label": "You Book?", "link": {"href": "#book", "type": "EXTERNAL", "content_id": None},
              "first_open": True, "questions": [{"question": q, "answer": f"<p>{a}</p>"} for q, a in FAQ]}
FOOTER_VALUES = {"badges": [{"image": img("award-" + k, a), "square": False} for k, a, w, h in AW] +
                 [{"image": img("award-globee-gold-2026", "2026 Globee Awards Gold Winner, Leadership", 320, 320), "square": True}]}

# order of the page (DnD sections); None = module defaults
PAGE = [
    ("avahi_ls_vsl_hero", "Hero + session video", None),
    ("avahi_ls_feature_cards", "What you will see", None),
    ("avahi_ls_booking", "Book a call (calendar)", None),
    ("avahi_ls_process_timeline", "How it works", None),
    ("avahi_ls_compare", "Manual vs agent comparison", None),
    ("avahi_ls_dark_panel", "Built for regulated work", None),
    ("avahi_ls_presenters", "Presenters + series", None),
    ("avahi_awards_rail", "Awards", AWARDS_VALUES),
    ("avahi_ls_cta_panel", "Closing CTA", None),
    ("avahi_faq", "FAQ", FAQ_VALUES),
]

# ------------------------------------------------------------------ write
def fill(html):
    rep = {"@@ARROW@@": ARROW, "@@NAVLOGO@@": SN['NAVLOGO'], "@@VSLILL@@": SN['VSLILL'], "@@GXPILL@@": SN['GXPILL'],
           "@@PLAY@@": SN['PLAY'], "@@FABCAL@@": SN['FABCAL'], "@@CALHEAD@@": SN['CALHEAD'], "@@FACE@@": SN['FACE'],
           "@@HEROLOGO@@": prefix_ids(AVAHI_LOGO_DARK, 'hm-', 'hh-'), "@@CARDLOGO@@": prefix_ids(AVAHI_LOGO_DARK, 'hm-', 'hp-')}
    for k, v in ICONS.items(): rep[f"@@ICON_{k}@@"] = v
    for k, v in rep.items(): html = html.replace(k, v)
    return html

def hubl_value(v):
    """Python value -> HubL literal (JSON is valid HubL; None -> null)."""
    return json.dumps(v, ensure_ascii=False)

def main():
    css = open(os.path.join(HERE, 'shared', 'styles.css')).read() if os.path.exists(os.path.join(HERE, 'shared', 'styles.css')) else ''
    js = open(os.path.join(HERE, 'shared', 'scripts.js')).read() if os.path.exists(os.path.join(HERE, 'shared', 'scripts.js')) else ''
    for m in MODULES:
        d = os.path.join(HERE, 'modules', m['slug']); os.makedirs(d, exist_ok=True)
        css_a, css_b = split_css(css)
        html = fill(m['html']).replace('@@CSS_A@@', css_a).replace('@@CSS_B@@', css_b).replace('@@JS@@', js)
        assert not re.findall(r'@@[A-Z_]+@@', html), (m['slug'], re.findall(r'@@[A-Z_]+@@', html))
        open(os.path.join(d, 'module.html'), 'w').write(html)
        json.dump(m['fields'], open(os.path.join(d, 'fields.json'), 'w'), indent=1, ensure_ascii=False)
        json.dump({"label": m['label'], "path": f"{MOD_DIR}/{m['slug']}", "host_template_types": ["PAGE"], "is_available_for_new_content": True},
                  open(os.path.join(d, 'meta.json'), 'w'), indent=1)
    # template
    sec = []
    for slug, label, vals in PAGE:
        params = "".join(f" {k}={hubl_value(v)}" for k, v in (vals or {}).items())
        sec.append(f'    {{% dnd_section full_width=true %}}\n      {{% dnd_module path="{MOD_DIR}/{slug}" label="{label}"{params} %}}\n      {{% end_dnd_module %}}\n    {{% end_dnd_section %}}')
    footer_params = "".join(f" {k}={hubl_value(v)}" for k, v in FOOTER_VALUES.items())
    head_js = open(os.path.join(SRC, 'head.js')).read().strip()
    tpl = f'''<!--
  templateType: page
  isAvailableForNewContent: true
  label: Avahi LS Webinar (VSL) Page
-->
{{# Avahi Life Sciences webinar landing page (video sales letter + booking).
   Locked: page header position, footer position, design layer (CSS) and behaviour layer (JS).
   Editable: every section in "Page sections" (add, remove, reorder, edit), the header fields and the footer fields. #}}
{{% set avh_editor = is_in_page_editor or is_in_editor %}}
<!DOCTYPE html>
<html lang="{{{{ html_lang if html_lang else 'en' }}}}"{{% if avh_editor %}} class="hs-editor"{{% endif %}}>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{{{{ page_meta.html_title }}}}</title>
<meta name="theme-color" content="#000000">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@200;300;400;500;600;700;800&display=swap" rel="stylesheet">
{{% if not avh_editor %}}<script>{{% raw %}}{head_js}{{% endraw %}}</script>{{% endif %}}
{{% module "ls_styles" path="{MOD_DIR}/avahi_ls_webinar_styles" label="Design layer (locked)" no_wrapper=True %}}
{{% module "ls_styles_b" path="{MOD_DIR}/avahi_ls_webinar_styles_b" label="Design layer part 2 (locked)" no_wrapper=True %}}
{{{{ standard_header_includes }}}}
</head>
<body class="avh-ls" data-lp-page="{{{{ content.slug or 'ls-webinar' }}}}">
<a class="skip" href="#main">Skip to content</a>
<div class="progress" aria-hidden="true"><span></span></div>
<div class="avh-global">{{% module "ls_header" path="{MOD_DIR}/avahi_ls_webinar_header" label="Page header (this page only)" %}}</div>
<main id="main" class="avh-dnd">
{SN['DEFS']}
  {{% dnd_area "main_content" label="Page sections" %}}
{chr(10).join(sec)}
  {{% end_dnd_area %}}
</main>
<div class="avh-global">{{% module "avahi_footer" path="{MOD_DIR}/avahi_global_footer" label="Avahi Global Footer"{footer_params} %}}</div>
{{% if not avh_editor %}}{{% module "ls_scripts" path="{MOD_DIR}/avahi_ls_webinar_scripts" label="Behaviour layer (locked)" no_wrapper=True %}}{{% endif %}}
{{{{ standard_footer_includes }}}}
</body>
</html>
'''
    os.makedirs(os.path.join(HERE, 'templates'), exist_ok=True)
    open(os.path.join(HERE, 'templates', 'avahi-ls-webinar.html'), 'w').write(tpl)
    os.makedirs(os.path.join(HERE, 'preview'), exist_ok=True)
    json.dump({"page": [[s, l, v] for s, l, v in PAGE], "footer": FOOTER_VALUES, "defs": SN['DEFS'], "head_js": head_js},
              open(os.path.join(HERE, 'preview', 'page.json'), 'w'))
    print('modules:', len(MODULES), ' template bytes:', len(tpl.encode()))
    for m in MODULES:
        p = os.path.join(HERE, 'modules', m['slug'])
        print(f"  {m['slug']:28s} html {os.path.getsize(p + '/module.html'):>7}  fields {os.path.getsize(p + '/fields.json'):>7}")

if __name__ == '__main__':
    main()
