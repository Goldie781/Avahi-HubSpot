#!/usr/bin/env python3
"""Screenshot the reference HTML and the local preview at several widths, report section geometry
differences, horizontal overflow and console errors.  Usage: python3 test/shoot.py 1440,1280,1024,768,390,375"""
import os, sys, json, asyncio
from playwright.async_api import async_playwright

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.dirname(os.path.dirname(HERE))
REF = 'file://' + os.path.join(ROOT, 'avahi-life-sciences-report-authoring-webinar-vsl.html')
PRE = 'file://' + os.path.join(HERE, 'preview', sys.argv[2] if len(sys.argv) > 2 else 'index.html')
OUT = os.path.join(HERE, 'test', 'shots'); os.makedirs(OUT, exist_ok=True)
WIDTHS = [int(w) for w in (sys.argv[1] if len(sys.argv) > 1 else '1440,390').split(',')]

GEOM = '''() => {
  const pick = s => [...document.querySelectorAll(s)].map(e => { const r = e.getBoundingClientRect(); return [Math.round(r.top + scrollY), Math.round(r.height), Math.round(r.left), Math.round(r.width)] });
  const sel = ['header .nav__bar','.lp-vsl','.hero__title','.lp-video','.lp-vsl__cta','.lp-vsl__hosts','main section','.card','.lp-cal','.timeline__step','.compare__col','.rapid__frame','.lp-host','.lp-series__list li','.awards','.cta__panel','.qa','footer.foot','.foot__badges img'];
  const o = {}; sel.forEach(s => o[s] = pick(s));
  o.overflow = document.documentElement.scrollWidth - innerWidth;
  o.height = document.documentElement.scrollHeight;
  return o; }'''

async def snap(page, url, tag, w):
    errs = []
    page.on('pageerror', lambda e: errs.append(str(e)))
    page.on('console', lambda m: errs.append(m.text) if m.type == 'error' else None)
    await page.set_viewport_size({"width": w, "height": 900})
    await page.goto(url, wait_until='load')
    # scroll through so reveal/observer animations settle
    h = await page.evaluate('document.documentElement.scrollHeight')
    y = 0
    while y < h:
        await page.evaluate(f'window.scrollTo(0,{y})'); await page.wait_for_timeout(60); y += 500
        h = await page.evaluate('document.documentElement.scrollHeight')
    await page.evaluate('window.scrollTo(0,0)'); await page.wait_for_timeout(2600)
    await page.add_style_tag(content='*,*::before,*::after{animation-play-state:paused!important;transition:none!important} .nav{transform:none!important}')
    g = await page.evaluate(GEOM)
    await page.screenshot(path=os.path.join(OUT, f'{tag}-{w}.png'), full_page=True)
    return g, errs

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        report = {}
        for w in WIDTHS:
            ctx = await b.new_context(device_scale_factor=1)
            r, re_ = await snap(await ctx.new_page(), REF, 'ref', w)
            ctx2 = await b.new_context(device_scale_factor=1)
            q, qe = await snap(await ctx2.new_page(), PRE, 'pre', w)
            diffs = []
            for k in r:
                if k in ('overflow', 'height'): continue
                a, c = r[k], q.get(k, [])
                if len(a) != len(c): diffs.append(f'{k}: count {len(a)} vs {len(c)}'); continue
                for i, (x, y) in enumerate(zip(a, c)):
                    if any(abs(m - n) > 2 for m, n in zip(x, y)): diffs.append(f'{k}[{i}]: ref {x} pre {y}'); break
            print(f'== {w}px  height ref {r["height"]} pre {q["height"]}  overflow ref {r["overflow"]} pre {q["overflow"]}')
            for d in diffs[:25]: print('   ', d)
            errs = [e for e in qe if 'fonts.g' not in e and 'net::' not in e]
            if errs: print('    preview errors:', errs[:5])
            await ctx.close(); await ctx2.close()
        await b.close()

asyncio.run(main())
