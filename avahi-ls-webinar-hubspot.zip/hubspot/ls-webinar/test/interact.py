#!/usr/bin/env python3
"""Interaction checks on the local preview (or any URL passed as argv[1]):
mobile menu, anchor CTAs, FAQ accordion, video start / fallbacks, calendar fallback, console errors."""
import os, sys, asyncio
from playwright.async_api import async_playwright
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
URL = sys.argv[1] if len(sys.argv) > 1 else 'file://' + os.path.join(HERE, 'preview', 'index.html')
ok = lambda c, m: print(('PASS ' if c else 'FAIL ') + m)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        # ---- mobile
        pg = await (await b.new_context(viewport={"width": 390, "height": 844})).new_page()
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(URL); await pg.wait_for_timeout(1500)
        burger = pg.locator('#nav .nav__burger')
        ok(await burger.is_visible(), 'mobile: burger visible')
        ok(not await pg.locator('#nav .nav__tag').is_visible(), 'mobile: series tag hidden')
        ok(await pg.locator('#nav .lp-navcta').is_visible(), 'mobile: header CTA visible')
        await burger.click(); await pg.wait_for_timeout(300)
        ok(await pg.locator('.lpnav__sheet').is_visible() and await burger.get_attribute('aria-expanded') == 'true', 'mobile: menu opens, aria-expanded=true')
        await pg.keyboard.press('Escape'); await pg.wait_for_timeout(200)
        ok(not await pg.locator('.lpnav__sheet').is_visible(), 'mobile: Escape closes the menu')
        await burger.click(); await pg.locator('.lpnav__sheet .lpnav__link').first.click(); await pg.wait_for_timeout(900)
        ok(not await pg.locator('.lpnav__sheet').is_visible(), 'mobile: choosing a link closes the menu')
        top = await pg.evaluate("document.getElementById('watch').getBoundingClientRect().top")
        ok(abs(top) < 140, f'mobile: Watch link scrolls to the video (top={top:.0f})')
        ow = await pg.evaluate('document.documentElement.scrollWidth - innerWidth')
        ok(ow <= 0, f'mobile: no horizontal overflow ({ow})')
        ok(not errs, f'mobile: no JS errors {errs[:3]}')
        # ---- desktop
        pg = await (await b.new_context(viewport={"width": 1440, "height": 900})).new_page()
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto(URL); await pg.wait_for_timeout(1500)
        ok(not await pg.locator('#nav .nav__burger').is_visible(), 'desktop: burger hidden')
        await pg.locator('#nav .lp-navcta').click(); await pg.wait_for_timeout(1200)
        top = await pg.evaluate("document.getElementById('book').getBoundingClientRect().top")
        ok(abs(top) < 140, f'desktop: Book a Call scrolls to the booking section (top={top:.0f})')
        qa = pg.locator('.qa')
        await qa.nth(2).locator('.qa__btn').click(); await pg.wait_for_timeout(300)
        cls0 = await qa.nth(0).get_attribute('class'); cls2 = await qa.nth(2).get_attribute('class')
        ok('is-open' in cls2 and 'is-open' not in cls0, 'FAQ: one question open at a time')
        await pg.evaluate("document.getElementById('watch').scrollIntoView()")
        await pg.locator('.lp-video__poster').click(); await pg.wait_for_timeout(2500)
        state = await pg.evaluate("(()=>{const s=document.querySelector('.lp-video__stage');return {playing:document.querySelector('.lp-video').classList.contains('is-playing'),video:!!s.querySelector('video'),src:(s.querySelector('video')||{}).src||'',msg:(s.querySelector('.lp-video__msg')||{}).textContent||''}})()")
        ok(state['playing'] and (state['video'] or state['msg']), f'video: starts on click ({state})')
        dl = await pg.evaluate("(window.dataLayer||[]).map(e=>e.lp_action+':'+(e.lp_cta||''))")
        ok(any(x.startswith('video_play') for x in dl) and any('nav_book' in x for x in dl), f'tracking: dataLayer events {dl[:6]}')
        ok(not errs, f'desktop: no JS errors {errs[:3]}')
        await b.close()
asyncio.run(main())
