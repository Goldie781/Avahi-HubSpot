// Strip CSS rules no module on this page can produce, then minify CSS + JS into shared/.
// Run from this folder after build.py:  NODE_PATH=<tools>/node_modules node purge.mjs
import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';
const require = createRequire(process.env.NODE_PATH ? path.join(process.env.NODE_PATH, 'x.js') : import.meta.url);
const { PurgeCSS } = require('purgecss');
const csso = require('csso');
const { minify } = require('terser');

const here = path.dirname(new URL(import.meta.url).pathname);
const read = p => fs.readFileSync(path.join(here, p), 'utf8');
const css = read('src/reference.css') + '\n' + read('src/extra.css');
const js = read('src/core.js') + '\n' + read('src/lp.js');
const jsExtra = read('src/lp-fab.js');   // minified on its own so the main bundle stays byte-stable
const ref = fs.readFileSync(path.join(here, '..', '..', 'avahi-life-sciences-report-authoring-webinar-vsl.html'), 'utf8');
const footer = (ref.match(/<footer class="foot on-dark">[\s\S]*?<\/footer>/) || [''])[0];

const content = [
  ...fs.readdirSync(path.join(here, 'modules')).filter(d => !/styles|scripts/.test(d))
     .map(d => ({ raw: read(`modules/${d}/module.html`), extension: 'html' })),
  { raw: read('templates/avahi-ls-webinar.html'), extension: 'html' },
  { raw: read('preview.py'), extension: 'html' },          // awards + FAQ stand-in markup
  { raw: footer, extension: 'html' },
  { raw: js, extension: 'js' },
  { raw: jsExtra, extension: 'js' },
];
const [res] = await new PurgeCSS().purge({
  content, css: [{ raw: css }], keyframes: false, variables: false, fontFace: false,
  safelist: { standard: [/^dnd-/, /^row-fluid/, /^span/, /^hs_cos/, /^hs-editor$/, /^js$/, /^in$/, /^done$/], greedy: [/^is-/, /^has-/, /^use-/] },
});
const outCss = csso.minify(res.css, { restructure: false }).css;
const mini = async src => (await minify(src, { compress: { passes: 2 }, mangle: true, format: { comments: /^!/ } })).code;
const outJs = (await mini(js)) + '\n' + (await mini(jsExtra));
fs.mkdirSync(path.join(here, 'shared'), { recursive: true });
fs.writeFileSync(path.join(here, 'shared/styles.css'), '/*! Avahi LS webinar design layer. Source: hubspot/ls-webinar/src (reference.css + extra.css), built by purge.mjs */\n' + outCss);
fs.writeFileSync(path.join(here, 'shared/scripts.js'), '/*! Avahi LS webinar behaviour layer. Source: hubspot/ls-webinar/src (core.js + lp.js), built by purge.mjs */\n' + outJs);
console.log('css', css.length, '->', outCss.length, ' js', js.length, '->', outJs.length);
