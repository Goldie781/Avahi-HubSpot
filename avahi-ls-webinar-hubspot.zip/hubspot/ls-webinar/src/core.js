
(() => {
  'use strict';

  /* ---------------------------------------------------------------
     FOUNDER PHOTOS: paste a headshot URL for each person.
     Until a URL is set, the card shows their initials.
     --------------------------------------------------------------- */
  const FOUNDER_PHOTOS = {};   // optional fallback map; prefer data-photo on each .avatar

  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const RM = matchMedia('(prefers-reduced-motion: reduce)');
  const MQ_PIN = matchMedia('(min-width:1024px) and (min-height:620px)');
  const MQ_DESK_NAV = matchMedia('(min-width:1101px)');
  let vw = innerWidth, vh = innerHeight;

  /* ---------------------------------------------------------------
     Split headings into masked words
     --------------------------------------------------------------- */
  function splitWords(el) {
    const walk = node => {
      [...node.childNodes].forEach(n => {
        if (n.nodeType === 3) {
          const parts = n.textContent.split(/(\s+)/);
          const frag = document.createDocumentFragment();
          parts.forEach(p => {
            if (!p) return;
            if (/^\s+$/.test(p)) { frag.appendChild(document.createTextNode(' ')); return; }
            const w = document.createElement('span'); w.className = 'w';
            const i = document.createElement('span'); i.className = 'w__i'; i.textContent = p;
            w.appendChild(i); frag.appendChild(w);
          });
          n.replaceWith(frag);
        } else if (n.nodeType === 1 && n.tagName !== 'BR') {
          if (n.classList.contains('grad-text')) {
            const w = document.createElement('span'); w.className = 'w';
            n.replaceWith(w); n.classList.add('w__i'); w.appendChild(n);
          } else walk(n);
        }
      });
    };
    walk(el);
    $$('.w__i', el).forEach((s, i) => s.style.setProperty('--wi', i));
  }
  $$('.split').forEach(splitWords);

  document.querySelectorAll('.avatar[data-person]').forEach(el => {
    const name = el.dataset.person;
    el.textContent = name.split(/\s+/).map(p => p[0]).join('').slice(0, 2).toUpperCase();
    const url = el.dataset.photo || FOUNDER_PHOTOS[name];
    if (url) {
      const img = new Image();
      img.alt = '';
      img.onload = () => el.classList.add('has-photo');
      img.onerror = () => img.remove();
      img.src = url;
      el.appendChild(img);
    }
  });

  /* ---------------------------------------------------------------
     Reveal on enter
     --------------------------------------------------------------- */
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('in'); io.unobserve(e.target);
        // once the words have risen into place, stop masking so descenders (g, y, p) are never clipped
        if (e.target.classList.contains('split')) setTimeout(() => e.target.classList.add('done'), 1900);
      }
    });
  }, { rootMargin: '0px 0px -10% 0px', threshold: 0.01 });
  // icons that draw themselves in need a normalized path length
  $$('.icon-mono.draw .s').forEach(p => { if (!p.hasAttribute('pathLength')) p.setAttribute('pathLength', '100'); });
  $$('[data-reveal], .split, [data-observe], .eyebrow').forEach(el => io.observe(el));

  /* ---------------------------------------------------------------
     Page load choreography
     --------------------------------------------------------------- */
  const markLoaded = () => { document.body.classList.add('is-loaded'); setTimeout(() => document.body.classList.add('hero-done'), 2200); };
  if (document.fonts && document.fonts.ready) {
    Promise.race([document.fonts.ready, new Promise(r => setTimeout(r, 700))]).then(() => requestAnimationFrame(markLoaded));
  } else setTimeout(markLoaded, 100);

  /* ---------------------------------------------------------------
     Video helpers
     --------------------------------------------------------------- */
  function readyOn(v) {
    if (!v) return;
    const ok = () => v.classList.add('is-ready');
    if (v.readyState >= 2) ok();
    v.addEventListener('loadeddata', ok, { once: true });
    v.addEventListener('playing', ok, { once: true });
  }
  function load(v) {
    if (v && !v.src && v.dataset.src) { v.src = v.dataset.src; v.preload = 'auto'; readyOn(v); }
  }
  function play(v) { if (!v) return; load(v); const p = v.play(); if (p && p.catch) p.catch(() => {}); }
  function pause(v) { if (v && !v.paused) v.pause(); }

  const heroVideo = $('.hero__video');
  if (heroVideo) {
    const embedded = document.getElementById('hero-video-data');
    const sources = [];
    if (heroVideo.getAttribute('src')) sources.push(heroVideo.getAttribute('src'));
    if (embedded) {
      const b64 = embedded.textContent.trim();
      try {
        const bin = atob(b64), bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        sources.push(URL.createObjectURL(new Blob([bytes], { type: 'video/mp4' })));
      } catch (err) {}
      sources.push('data:video/mp4;base64,' + b64);
    }
    let si = 0, watchdog = 0;
    const kick = () => { if (!RM.matches && heroVideo.paused) { const pr = heroVideo.play(); if (pr && pr.catch) pr.catch(() => {}); } };
    const tryNext = () => {
      clearTimeout(watchdog);
      if (si >= sources.length) return;
      heroVideo.src = sources[si++];
      heroVideo.load();
      kick();
      // if this source hasn't produced a frame in a few seconds, fall through to the next one
      watchdog = setTimeout(() => { if (heroVideo.readyState < 2) tryNext(); }, 3500);
    };
    heroVideo.addEventListener('error', tryNext);
    heroVideo.addEventListener('canplay', kick);
    heroVideo.addEventListener('loadeddata', () => clearTimeout(watchdog));
    if (RM.matches) heroVideo.removeAttribute('autoplay');
    if (heroVideo.getAttribute('src')) { si = 1; kick(); } else tryNext();
    // some browsers (low-power mode, data saver) hold autoplay until the first interaction
    ['pointerdown', 'touchstart', 'keydown', 'scroll'].forEach(ev => addEventListener(ev, () => { if (scrollY < vh) kick(); }, { once: true, passive: true }));
    document.addEventListener('visibilitychange', () => { if (!document.hidden && scrollY < vh) kick(); });
  }
  readyOn(heroVideo);

  /* ---------------------------------------------------------------
     Marquees (customer logos + awards): fill past the container width,
     duplicate once, then translate -50% so the loop never jumps
     --------------------------------------------------------------- */
  const marquees = $$('.marquee').map(track => ({ track, base: [...track.children] }));
  function buildMarquees() {
    marquees.forEach(({ track, base }) => {
      $$('[data-clone]', track).forEach(c => c.remove());
      const need = (track.parentElement.clientWidth || vw) * 1.1;
      const cloneOf = n => { const c = n.cloneNode(true); c.dataset.clone = '1'; c.setAttribute('aria-hidden', 'true'); if (c.tagName === 'IMG') c.alt = ''; $$('img', c).forEach(i => { i.alt = ''; }); return c; };
      let reps = 1;
      while (track.scrollWidth < need && reps < 12) { base.forEach(n => track.appendChild(cloneOf(n))); reps++; }
      [...track.children].forEach(n => track.appendChild(cloneOf(n)));
      const half = track.scrollWidth / 2;
      track.style.animationDuration = (half / (+track.dataset.speed || 30)).toFixed(1) + 's';
    });
  }
  if (document.readyState === 'complete') buildMarquees(); else addEventListener('load', buildMarquees, { once: true });

  /* ---------------------------------------------------------------
     NAV: hide on scroll down, glider, mega menus, mobile sheet
     --------------------------------------------------------------- */
  const nav = $('#nav');
  const navList = $('.nav__list');
  const glider = $('.nav__glider');
  const items = $$('.nav__item');
  const burger = $('.nav__burger');
  let openItem = null, closeTimer = null, lastY = scrollY;

  function setOpen(item) {
    if (openItem === item) return;
    if (openItem) {
      openItem.classList.remove('is-open');
      const b = $('.nav__link', openItem); if (b) b.setAttribute('aria-expanded', 'false');
    }
    openItem = item;
    if (item) {
      item.classList.add('is-open');
      const b = $('.nav__link', item); if (b) b.setAttribute('aria-expanded', 'true');
    }
  }
  function moveGlider(link) {
    if (!glider || !navList || !MQ_DESK_NAV.matches) return;
    if (!link) { glider.style.opacity = '0'; return; }
    const lr = glider.offsetParent.getBoundingClientRect(), r = link.getBoundingClientRect();
    glider.style.top = (r.top - lr.top) + 'px'; glider.style.height = r.height + 'px';
    glider.style.width = r.width + 'px';
    glider.style.transform = `translateX(${r.left - lr.left}px)`;
    glider.style.opacity = '1';
  }
  items.forEach(item => {
    const link = $('.nav__link', item);
    const hasMega = !!$('.mega', item);
    item.addEventListener('pointerenter', e => {
      if (e.pointerType !== 'mouse' || !MQ_DESK_NAV.matches) return;
      clearTimeout(closeTimer);
      moveGlider(link);
      setOpen(hasMega ? item : null);
    });
    item.addEventListener('pointerleave', e => {
      if (e.pointerType !== 'mouse' || !MQ_DESK_NAV.matches) return;
      closeTimer = setTimeout(() => { setOpen(null); moveGlider(null); }, 160);
    });
    if (hasMega) link.addEventListener('click', () => setOpen(openItem === item ? null : item));
    link.addEventListener('focus', () => moveGlider(link));
  });
  if (navList) navList.addEventListener('pointerleave', () => { if (!openItem) moveGlider(null); });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      if (openItem) { const b = $('.nav__link', openItem); setOpen(null); moveGlider(null); b && b.focus(); }
      if (nav && nav.classList.contains('menu-open')) toggleMenu(false);
    }
  });
  document.addEventListener('click', e => { if (nav && !nav.contains(e.target)) { setOpen(null); moveGlider(null); if (nav.classList.contains('menu-open')) toggleMenu(false); } });
  if (nav) nav.addEventListener('focusout', e => { if (MQ_DESK_NAV.matches && !nav.contains(e.relatedTarget)) { setOpen(null); moveGlider(null); } });

  function toggleMenu(force) {
    const open = typeof force === 'boolean' ? force : !nav.classList.contains('menu-open');
    if (!nav || !burger) return;
    nav.classList.toggle('menu-open', open);
    burger.setAttribute('aria-expanded', String(open));
    burger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    if (!open) setOpen(null);
  }
  if (burger) burger.addEventListener('click', e => { e.stopPropagation(); toggleMenu(); });

  /* ---------------------------------------------------------------
     SERVICES: pinned stage (desktop) / swipe cards (mobile)
     --------------------------------------------------------------- */
  const svc = $('.svc');
  const scroller = $('#svc-scroller');
  const stage = $('#svc-stage');
  const panelsWrap = $('#svc-panels');
  const panels = $$('.svc__panel');
  const svcItems = $$('.svc__item');
  const tiers = $$('.svc__tier');
  const segs = $$('.svc__seg i');
  const wire = $('.svc__wire');
  const N = panels.length;
  const HAS_SVC = !!(svc && scroller && stage && panelsWrap && N);
  let active = -1;

  const glowPos = [['72%', '30%'], ['60%', '55%'], ['70%', '80%']];

  function setActive(i, dir) {
    if (i === active) return;
    const prev = active;
    active = i;
    const inc = panels[i];
    panels.forEach((p, k) => { if (k !== prev && k !== i) p.classList.remove('is-prev', 'is-active'); });
    inc.classList.add('no-tr');
    inc.classList.remove('is-prev', 'is-active');
    inc.dataset.from = dir < 0 ? 'top' : 'bottom';
    void inc.offsetWidth;
    inc.classList.remove('no-tr');
    if (prev >= 0) { panels[prev].classList.remove('is-active'); panels[prev].classList.add('is-prev'); }
    inc.classList.add('is-active');

    svcItems.forEach((b, k) => { b.classList.toggle('is-active', k === i); b.setAttribute('aria-current', k === i ? 'true' : 'false'); });
    const t = +inc.dataset.tier;
    tiers.forEach(el => el.classList.toggle('is-current', +el.dataset.tier === t));
    if (glowPos[t]) { svc.style.setProperty('--gx', glowPos[t][0]); svc.style.setProperty('--gy', glowPos[t][1]); }
    if (net) net.setTier(t);

    // restart this service's illustration so it plays from the top each time it arrives
    const ill = $('.ill', inc);
    if (ill && ill.getAnimations) { try { ill.getAnimations({ subtree: true }).forEach(a => { a.currentTime = 0; }); } catch (e) {} }
    drawWire(true);
  }

  function svcProgress() {
    if (!HAS_SVC || !MQ_PIN.matches) return;
    const r = scroller.getBoundingClientRect();
    const total = r.height - vh;
    const p = clamp(-r.top / total, 0, 1);
    const f = p * N;
    const i = Math.min(N - 1, Math.floor(f));
    const local = clamp(f - i, 0, 1);
    if (i !== active) setActive(i, i > active ? 1 : -1);
    for (let k = 0; k < N; k++) {
      const v = k < i ? 1 : k === i ? local : 0;
      svcItems[k].style.setProperty('--p', v.toFixed(4));
      if (segs[k]) segs[k].style.setProperty('--p', v.toFixed(4));
    }
  }

  function drawWire(animate) {
    if (!HAS_SVC || !wire || !MQ_PIN.matches || active < 0) return;
    const host = wire.parentElement.getBoundingClientRect();
    const name = $('.svc__item-name', svcItems[active]).getBoundingClientRect();
    const st = stage.getBoundingClientRect();
    const x1 = name.right - host.left + 14, y1 = name.top + name.height / 2 - host.top;
    const x2 = st.left - host.left, y2 = st.top + st.height * 0.5 - host.top;
    const dx = Math.max(30, (x2 - x1) * 0.55);
    const d = `M${x1.toFixed(1)},${y1.toFixed(1)} C${(x1 + dx).toFixed(1)},${y1.toFixed(1)} ${(x2 - dx).toFixed(1)},${y2.toFixed(1)} ${x2.toFixed(1)},${y2.toFixed(1)}`;
    const base = $('.base', wire), flow = $('.flow', wire);
    const wg = document.getElementById('wireGrad');
    if (wg) { wg.setAttribute('gradientUnits', 'userSpaceOnUse'); wg.setAttribute('x1', x1); wg.setAttribute('x2', x2); wg.setAttribute('y1', 0); wg.setAttribute('y2', 0); }
    base.setAttribute('d', d); flow.setAttribute('d', d);
    $('.end-a', wire).setAttribute('cx', x1); $('.end-a', wire).setAttribute('cy', y1);
    $('.end-b', wire).setAttribute('cx', x2); $('.end-b', wire).setAttribute('cy', y2);
    $('.halo', wire).setAttribute('cx', x2); $('.halo', wire).setAttribute('cy', y2);
    if (animate && !RM.matches) {
      const len = base.getTotalLength();
      [base, flow].forEach(p => {
        p.getAnimations && p.getAnimations().forEach(a => { if (a.id === 'draw') a.cancel(); });
      });
      const a = base.animate([{ strokeDasharray: `${len} ${len}`, strokeDashoffset: len }, { strokeDasharray: `${len} ${len}`, strokeDashoffset: 0 }], { duration: 650, easing: 'cubic-bezier(.16,1,.3,1)' });
      a.id = 'draw';
      flow.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 500, delay: 350, fill: 'backwards' });
    }
  }

  svcItems.forEach((b, k) => b.addEventListener('click', () => {
    if (!MQ_PIN.matches) return;
    const top = scroller.getBoundingClientRect().top + scrollY;
    const total = scroller.offsetHeight - vh;
    window.scrollTo({ top: top + total * ((k + 0.08) / N), behavior: RM.matches ? 'auto' : 'smooth' });
  }));

  /* mobile: swipe cards */
  const dots = $('.svc__dots');
  if (dots) for (let k = 0; k < N; k++) dots.appendChild(document.createElement('span'));
  const dotEls = dots ? [...dots.children] : [];
  let mobIdx = -1;
  function mobileUpdate() {
    if (!HAS_SVC || MQ_PIN.matches) return;
    const w = panelsWrap.getBoundingClientRect();
    let best = 0, bestD = Infinity;
    const padL = parseFloat(getComputedStyle(panelsWrap).paddingLeft) || 0;
    panels.forEach((p, k) => { const d = Math.abs(p.getBoundingClientRect().left - w.left - padL); if (d < bestD) { bestD = d; best = k; } });
    if (best !== mobIdx) {
      mobIdx = best;
      dotEls.forEach((d, k) => d.classList.toggle('is-on', k === best));
    }
  }
  if (panelsWrap) panelsWrap.addEventListener('scroll', () => requestAnimationFrame(mobileUpdate), { passive: true });
  // on phones, only the service cards actually on screen keep animating
  const cardIO = new IntersectionObserver(es => es.forEach(e => e.target.classList.toggle('is-off', !e.isIntersecting)), { root: null, threshold: .15 });
  panels.forEach(p => cardIO.observe(p));

  // Services panel: chamfered corners; the top-left corner is sliced into two thin parallel cuts
  let lastCut = '';
  function svcEnter() {
    if (!svc) return;
    const W = svc.clientWidth, H = svc.offsetHeight;
    if (!W || !H) return;
    const top = svc.getBoundingClientRect().top;
    const p = RM.matches ? 1 : clamp((vh - top) / (vh * .8), 0, 1);
    const e = 1 - Math.pow(1 - p, 3);
    const m = Math.min(14, Math.max(8, vw * .01));
    const start = Math.max(m, Math.min(vw * .05, 72));
    const X = Math.round(start + (m - start) * e);
    const R = W - X;
    const small = W < 700;
    const c = small ? 20 : 30;          // corner chamfer
    const b = small ? 14 : 22;          // one thick sliver (measured along the edges)
    const g = small ? 5 : 7;            // the cut between sliver and panel
    const k = small ? 16 : 22;          // other corners
    const slide = Math.round((1 - e) * 16);   // sliver settles into place as the panel arrives
    const band = (s0, s1) => `M${X} ${s0} L${X + s0} 0 L${X + s1} 0 L${X} ${s1} Z`;
    const s1 = c + slide, s2 = s1 + b, S = s2 + g;
    let d = `M${X + S} 0 L${R - k} 0 L${R} ${k} L${R} ${H - k} L${R - k} ${H} L${X + k} ${H} L${X} ${H - k} L${X} ${S} Z`;
    d += ' ' + band(s1, s2);
    if (d !== lastCut) { lastCut = d; svc.style.clipPath = `path('${d}')`; }
  }
  function sizeIll() {
    panels.forEach(p => { const c = $('.svc__copy', p); if (c) p.style.setProperty('--copy-h', c.offsetHeight + 'px'); });
  }
  function svcMode() {
    if (!HAS_SVC) return;
    sizeIll();
    if (MQ_PIN.matches) {
      active = -1;
      svcProgress();
      drawWire(false);
      if (net) net.resize();
    } else {
      panels.forEach(p => p.classList.remove('is-active', 'is-prev'));
      active = -1; mobIdx = -1;
      mobileUpdate();
    }
  }

  /* ---------------------------------------------------------------
     Stage backdrop: brand-blue node network (fallback + texture)
     --------------------------------------------------------------- */
  function makeNet(cvs) {
    if (!cvs || !cvs.getContext) return null;
    const ctx = cvs.getContext('2d');
    let w = 0, h = 0, nodes = [], pulses = [], running = false, tier = 0, raf = 0, last = 0;
    const tierCfg = [
      { link: 165, speed: .2, rate: .05, hue: [70, 186, 227] },
      { link: 185, speed: .17, rate: .08, hue: [48, 134, 227] },
      { link: 160, speed: .14, rate: .06, hue: [49, 97, 204] }
    ];
    function resize() {
      const dpr = Math.min(2, devicePixelRatio || 1);
      w = cvs.clientWidth; h = cvs.clientHeight;
      if (!w || !h) return;
      cvs.width = w * dpr; cvs.height = h * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const n = Math.round(clamp(w * h / 27000, 18, 56));
      nodes = Array.from({ length: n }, () => ({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - .5), vy: (Math.random() - .5), r: Math.random() * 1.6 + .7 }));
    }
    function frame(t) {
      if (!running) return;
      const dt = Math.min(50, t - (last || t)); last = t;
      const c = tierCfg[tier];
      ctx.clearRect(0, 0, w, h);
      for (const n of nodes) {
        n.x += n.vx * c.speed * dt * .06; n.y += n.vy * c.speed * dt * .06;
        if (n.x < -10) n.x = w + 10; if (n.x > w + 10) n.x = -10;
        if (n.y < -10) n.y = h + 10; if (n.y > h + 10) n.y = -10;
      }
      const L = c.link, L2 = L * L;
      ctx.lineWidth = 1;
      for (let a = 0; a < nodes.length; a++) {
        const A = nodes[a];
        for (let b = a + 1; b < nodes.length; b++) {
          const B = nodes[b], dx = A.x - B.x, dy = A.y - B.y, d2 = dx * dx + dy * dy;
          if (d2 < L2) {
            const o = (1 - d2 / L2) * .15;
            ctx.strokeStyle = `rgba(${c.hue[0]},${c.hue[1]},${c.hue[2]},${o})`;
            ctx.beginPath(); ctx.moveTo(A.x, A.y); ctx.lineTo(B.x, B.y); ctx.stroke();
            if (Math.random() < c.rate * .002 && pulses.length < 6) pulses.push({ a: A, b: B, t: 0 });
          }
        }
      }
      for (const n of nodes) {
        ctx.fillStyle = 'rgba(120,199,227,.3)';
        ctx.beginPath(); ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2); ctx.fill();
      }
      pulses = pulses.filter(p => (p.t += dt / 900) < 1);
      for (const p of pulses) {
        const x = p.a.x + (p.b.x - p.a.x) * p.t, y = p.a.y + (p.b.y - p.a.y) * p.t;
        const g = ctx.createRadialGradient(x, y, 0, x, y, 10);
        g.addColorStop(0, 'rgba(255,255,255,.5)'); g.addColorStop(.3, 'rgba(120,199,227,.3)'); g.addColorStop(1, 'rgba(120,199,227,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 10, 0, Math.PI * 2); ctx.fill();
      }
      raf = requestAnimationFrame(frame);
    }
    const vis = new IntersectionObserver(es => es.forEach(e => {
      if (e.isIntersecting && !RM.matches) { if (!running) { running = true; last = 0; raf = requestAnimationFrame(frame); } }
      else { running = false; cancelAnimationFrame(raf); }
    }));
    vis.observe(cvs);
    resize();
    if (RM.matches) { running = true; frame(16); running = false; }
    return { resize, setTier(t) { tier = Math.max(0, Math.min(2, t)); } };
  }
  const net = makeNet($('.svc__net'));
  const extraNets = $$('canvas[data-network]').map(makeNet).filter(Boolean);

  /* ---------------------------------------------------------------
     PARTNER ROUTER: inputs -> Avahi -> partner
     --------------------------------------------------------------- */
  const router = (() => {
    const root = $('#router'); if (!root) return null;
    const svg = $('.router__wires', root);
    const gBase = $('.g-base', svg), gLit = $('.g-lit', svg), gPk = $('.g-pk', svg);
    const ins = $$('.router__in', root), hub = $('.router__hub', root), outs = $$('.partner', root);
    const NS = 'http://www.w3.org/2000/svg';
    let inPaths = [], outPaths = [], running = false, raf = 0, k = 0, t0 = 0;
    const mk = (tag, attrs, parent) => { const e = document.createElementNS(NS, tag); for (const a in attrs) e.setAttribute(a, attrs[a]); parent.appendChild(e); return e; };

    function curve(a, b, vertical) {
      if (vertical) { const dy = (b[1] - a[1]) * .55; return `M${a[0]},${a[1]} C${a[0]},${a[1] + dy} ${b[0]},${b[1] - dy} ${b[0]},${b[1]}`; }
      const dx = (b[0] - a[0]) * .55; return `M${a[0]},${a[1]} C${a[0] + dx},${a[1]} ${b[0] - dx},${b[1]} ${b[0]},${b[1]}`;
    }
    function build() {
      const R = root.getBoundingClientRect();
      svg.setAttribute('width', R.width); svg.setAttribute('height', R.height); svg.setAttribute('viewBox', `0 0 ${R.width} ${R.height}`);
      [gBase, gLit, gPk].forEach(g => g.innerHTML = '');
      const H = hub.getBoundingClientRect();
      const vertical = H.top > Math.max(...ins.map(el => el.getBoundingClientRect().bottom)) - 2;
      const rel = (x, y) => [+(x - R.left).toFixed(1), +(y - R.top).toFixed(1)];
      inPaths = ins.map((el, i) => {
        const r = el.getBoundingClientRect();
        const a = vertical ? rel(r.left + r.width / 2, r.bottom) : rel(r.right, r.top + r.height / 2);
        const spread = vertical ? 0 : (i - (ins.length - 1) / 2) * (H.height * .14);
        const b = vertical ? rel(H.left + H.width / 2, H.top) : rel(H.left, H.top + H.height / 2 + spread);
        const d = curve(a, b, vertical);
        mk('path', { d, class: 'base' }, gBase);
        const lit = mk('path', { d, class: 'lit', opacity: 0 }, gLit);
        return { lit, len: lit.getTotalLength(), el };
      });
      outPaths = outs.map((el, i) => {
        const r = el.getBoundingClientRect();
        const spread = vertical ? 0 : (i - (outs.length - 1) / 2) * (H.height * .16);
        const a = vertical ? rel(H.left + H.width / 2, H.bottom) : rel(H.right, H.top + H.height / 2 + spread);
        const b = vertical ? rel(r.left + r.width / 2, r.top) : rel(r.left, r.top + r.height / 2);
        const d = curve(a, b, vertical);
        mk('path', { d, class: 'base' }, gBase);
        const lit = mk('path', { d, class: 'lit', opacity: 0 }, gLit);
        return { lit, len: lit.getTotalLength(), el };
      });
      gPk.innerHTML = '';
      [...inPaths, ...outPaths].forEach(p => {
        p.halo = mk('circle', { r: 9, class: 'pk-halo', opacity: 0 }, gPk);
        p.dot = mk('circle', { r: 3.5, class: 'pk', opacity: 0 }, gPk);
      });
      if (RM.matches) outs[0].classList.add('is-active');
    }
    const ease = t => t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    function place(p, t) {
      if (t <= 0 || t >= 1) {
        p.dot.setAttribute('opacity', 0); p.halo.setAttribute('opacity', 0);
        p.lit.setAttribute('opacity', t >= 1 ? Math.max(0, 1 - (t - 1) * 3) : 0);
        if (t >= 1) { p.lit.style.strokeDasharray = `${p.len} ${p.len}`; p.lit.style.strokeDashoffset = 0; }
        return;
      }
      const e = ease(t);
      const pt = p.lit.getPointAtLength(p.len * e);
      p.dot.setAttribute('cx', pt.x); p.dot.setAttribute('cy', pt.y); p.dot.setAttribute('opacity', 1);
      p.halo.setAttribute('cx', pt.x); p.halo.setAttribute('cy', pt.y); p.halo.setAttribute('opacity', 1);
      p.lit.setAttribute('opacity', 1);
      p.lit.style.strokeDasharray = `${p.len} ${p.len}`;
      p.lit.style.strokeDashoffset = p.len * (1 - e);
    }
    const CYCLE = 3400;
    let lastPhase = -1;
    function frame(now) {
      if (!running) return;
      if (!t0) t0 = now;
      let t = now - t0;
      if (t > CYCLE) { t0 = now; t = 0; k = (k + 1) % outs.length; lastPhase = -1; }
      inPaths.forEach((p, i) => {
        const s = i * 110, local = (t - s) / 850;
        place(p, local < 0 ? 0 : local);
        p.el.classList.toggle('is-firing', local > -0.05 && local < 1.15);
      });
      if (t > 1100 && lastPhase < 1) { lastPhase = 1; hub.classList.remove('is-pulse'); void hub.offsetWidth; hub.classList.add('is-pulse'); }
      outPaths.forEach((p, i) => {
        if (i !== k) { place(p, 0); return; }
        const local = (t - 1250) / 900;
        place(p, local < 0 ? 0 : local);
      });
      if (t > 2150 && lastPhase < 2) { lastPhase = 2; outs.forEach((o, i) => o.classList.toggle('is-active', i === k)); }
      raf = requestAnimationFrame(frame);
    }
    const vis = new IntersectionObserver(es => es.forEach(e => {
      if (e.isIntersecting && !RM.matches) { if (!running) { running = true; t0 = 0; raf = requestAnimationFrame(frame); } }
      else { running = false; cancelAnimationFrame(raf); }
    }), { threshold: .2 });
    build(); vis.observe(root);
    $$('img', root).forEach(img => { if (!img.complete) { img.addEventListener('load', build); img.addEventListener('error', () => setTimeout(build, 30)); } });
    return { build };
  })();

  /* ---------------------------------------------------------------
     Feature quote: words light up as you read down the page
     --------------------------------------------------------------- */
  const quote = $('#feature-quote p');
  let qWords = [];
  if (quote) {
    const words = quote.textContent.trim().split(/\s+/);
    quote.innerHTML = words.map(w => `<span class="qw">${w}</span>`).join(' ');
    qWords = $$('.qw', quote);
  }
  function quoteProgress() {
    if (!qWords.length || RM.matches) return;
    const r = quote.getBoundingClientRect();
    const p = clamp((vh * .92 - r.top) / (vh * .55), 0, 1);
    const n = qWords.length;
    qWords.forEach((w, i) => w.style.setProperty('--o', (0.16 + 0.84 * clamp(p * n * 1.15 - i, 0, 1)).toFixed(3)));
  }

  /* ---------------------------------------------------------------
     Rapid deployment frame settles flat as it reaches center
     --------------------------------------------------------------- */
  const warp = (() => {
    const cvs = $('#warp'); if (!cvs || !cvs.getContext) return null;
    const ctx = cvs.getContext('2d');
    const cols = ['120,199,227', '70,186,227', '255,255,255'];
    let w = 0, h = 0, lines = [], running = false, raf = 0, last = 0;
    // three depth layers: far lines are thin, faint, slow; near lines are longer and quicker
    const layers = [
      { n: .45, speed: [1.1, 1.6], len: [40, 90], width: .8, alpha: .2 },
      { n: .35, speed: [2.2, 3.0], len: [80, 150], width: 1.1, alpha: .34 },
      { n: .20, speed: [3.8, 5.0], len: [130, 220], width: 1.5, alpha: .5 }
    ];
    const rnd = (a, b) => a + Math.random() * (b - a);
    function spawn(l, L, init) {
      l.L = L; l.y = rnd(8, h - 8); l.v = rnd(L.speed[0], L.speed[1]); l.len = rnd(L.len[0], L.len[1]);
      l.c = cols[(Math.random() * cols.length) | 0];
      l.x = init ? rnd(-l.len, w + l.len) : w + rnd(0, w * .5);
      return l;
    }
    function resize() {
      const dpr = Math.min(2, devicePixelRatio || 1);
      w = cvs.clientWidth; h = cvs.clientHeight; if (!w || !h) return;
      cvs.width = w * dpr; cvs.height = h * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const total = Math.round(clamp(w * h / 5200, 34, 90));
      lines = [];
      layers.forEach(L => { for (let k = 0; k < Math.round(total * L.n); k++) lines.push(spawn({}, L, true)); });
    }
    function boostAt() { return 1; }
    function draw(dt, boost) {
      ctx.clearRect(0, 0, w, h);
      ctx.lineCap = 'butt';
      for (const l of lines) {
        l.x -= l.v * boost * dt * .06 * 3.6;
        if (l.x + l.len < 0) { spawn(l, l.L, false); continue; }
        const g = ctx.createLinearGradient(l.x, 0, l.x + l.len, 0);
        g.addColorStop(0, `rgba(${l.c},${l.L.alpha})`);
        g.addColorStop(1, `rgba(${l.c},0)`);
        ctx.strokeStyle = g; ctx.lineWidth = l.L.width;
        ctx.beginPath(); ctx.moveTo(l.x, l.y); ctx.lineTo(l.x + l.len, l.y); ctx.stroke();
      }
    }
    function frame(t) {
      if (!running) return;
      const dt = Math.min(40, t - (last || t)); last = t;
      draw(dt, boostAt());
      raf = requestAnimationFrame(frame);
    }
    const vis = new IntersectionObserver(es => es.forEach(e => {
      if (e.isIntersecting && !RM.matches) { if (!running) { running = true; last = 0; raf = requestAnimationFrame(frame); } }
      else { running = false; cancelAnimationFrame(raf); }
    }));
    resize(); vis.observe(cvs);
    if (RM.matches) draw(16, 1);
    return { resize };
  })();
  // Progress bar: races from 0 to 100% in about a second, holds, then runs again
  (() => {
    const fill = $('.spd-fill'), pct = $('.spd-pct'), chevs = $$('.spd-chev');
    if (!fill || !pct) return;
    // each arrow lights as the bar passes its quarter, so the arrows move at the bar's pace
    const setChevs = (p, fade) => chevs.forEach((c, i) => {
      const f = clamp((p - i * .25) / .25, 0, 1);
      c.style.opacity = ((.14 + .86 * f) * fade).toFixed(3);
      c.style.transform = `translateX(${(-10 * (1 - f)).toFixed(2)}px)`;
    });
    if (RM.matches) { fill.style.transform = 'scaleX(1)'; pct.textContent = '100%'; setChevs(1, 1); return; }
    const RUN = 1100, HOLD = 1100, RESET = 250, CYCLE = RUN + HOLD + RESET;
    let running = false, raf = 0, t0 = 0, done = false;
    const ease = t => 1 - Math.pow(1 - t, 3);
    function frame(now) {
      if (!running) return;
      if (!t0) t0 = now;
      const t = (now - t0) % CYCLE;
      let p;
      if (t < RUN) { p = ease(t / RUN); if (done) { done = false; fill.classList.remove('is-done'); } }
      else if (t < RUN + HOLD) { p = 1; if (!done) { done = true; void fill.getBBox(); fill.classList.add('is-done'); } }
      else p = 1;
      // full bar and label fade out together, then the next run starts clean from 0%
      const fade = t >= RUN + HOLD ? (1 - (t - RUN - HOLD) / RESET).toFixed(3) : '1';
      fill.style.transform = `scaleX(${p.toFixed(4)})`;
      fill.style.opacity = fade; pct.style.opacity = fade;
      setChevs(p, t >= RUN + HOLD ? Math.max(+fade, .16) : 1);
      pct.textContent = Math.round(p * 100) + '%';
      raf = requestAnimationFrame(frame);
    }
    const io = new IntersectionObserver(es => es.forEach(e => {
      if (e.isIntersecting) { if (!running) { running = true; t0 = 0; raf = requestAnimationFrame(frame); } }
      else { running = false; cancelAnimationFrame(raf); }
    }));
    io.observe(fill.closest('svg'));
  })();

  const rapidFrame = $('#rapid-frame');
  function rapidProgress() {
    if (!rapidFrame) return;
    const r = rapidFrame.getBoundingClientRect();
    if (!RM.matches) {
      const t = clamp((r.top + r.height / 2 - vh / 2) / (vh * .7), 0, 1);
      rapidFrame.style.setProperty('--t', t.toFixed(3));
    }
  }

  /* ---------------------------------------------------------------
     Tile videos play only while visible
     --------------------------------------------------------------- */
  const tileIO = new IntersectionObserver(es => es.forEach(e => {
    const v = $('video', e.target);
    if (e.isIntersecting) play(v); else pause(v);
  }), { rootMargin: '120px 0px' });
  $$('.tile__media').forEach(m => tileIO.observe(m));

  /* ---------------------------------------------------------------
     Count-up stats
     --------------------------------------------------------------- */
  const countIO = new IntersectionObserver(es => es.forEach(e => {
    if (!e.isIntersecting) return;
    countIO.unobserve(e.target);
    const el = e.target, end = +el.dataset.count, suf = el.dataset.suffix || '';
    if (RM.matches) { el.textContent = end + suf; return; }
    const dur = 1700, s = performance.now();
    const step = now => {
      const t = clamp((now - s) / dur, 0, 1), eased = 1 - Math.pow(1 - t, 4);
      el.textContent = Math.round(end * eased) + (t === 1 ? suf : '');
      if (t < 1) requestAnimationFrame(step);
    };
    el.textContent = '0';
    requestAnimationFrame(step);
  }), { threshold: .6 });
  $$('.stat__num[data-count]').forEach(el => countIO.observe(el));

  /* ---------------------------------------------------------------
     CTA: flowing signal lines, pointer spotlight, magnetic buttons
     --------------------------------------------------------------- */
  const ctaLines = $('#cta-lines');
  if (ctaLines) {
    const NS = 'http://www.w3.org/2000/svg';
    const count = 11;
    for (let i = 0; i < count; i++) {
      const y = 40 + i * (520 / (count - 1));
      const amp = 40 + (i % 4) * 22, ph = i * .9;
      let d = `M-20,${y}`;
      for (let x = -20; x <= 1220; x += 40) {
        const yy = y + Math.sin(x / 210 + ph) * amp * .5 + Math.sin(x / 90 + ph * 1.7) * amp * .12;
        d += ` L${x},${yy.toFixed(1)}`;
      }
      const b = document.createElementNS(NS, 'path'); b.setAttribute('d', d); b.setAttribute('class', 'bl'); ctaLines.appendChild(b);
      const f = document.createElementNS(NS, 'path'); f.setAttribute('d', d); f.setAttribute('class', 'fl');
      f.style.setProperty('--dur', (6 + (i % 5) * 1.4) + 's'); f.style.setProperty('--del', (-i * 1.3) + 's');
      ctaLines.appendChild(f);
    }
  }
  const ctaPanel = $('#cta-panel');
  if (ctaPanel && !RM.matches) {
    ctaPanel.addEventListener('pointermove', e => {
      const r = ctaPanel.getBoundingClientRect();
      ctaPanel.style.setProperty('--mx', (e.clientX - r.left) + 'px');
      ctaPanel.style.setProperty('--my', (e.clientY - r.top) + 'px');
    });
    $$('.magnetic', ctaPanel).forEach(btn => {
      btn.addEventListener('pointermove', e => {
        if (e.pointerType !== 'mouse') return;
        const r = btn.getBoundingClientRect();
        const dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
        btn.style.transform = `translate(${dx * .18}px, ${dy * .3}px)`;
      });
      btn.addEventListener('pointerleave', () => { btn.style.transform = ''; });
    });
  }

  /* ---------------------------------------------------------------
     FAQ accordion (one open at a time)
     --------------------------------------------------------------- */
  const qas = $$('.qa');
  qas.forEach(qa => {
    const btn = $('.qa__btn', qa);
    btn.addEventListener('click', () => {
      const willOpen = !qa.classList.contains('is-open');
      qas.forEach(o => { o.classList.remove('is-open'); $('.qa__btn', o).setAttribute('aria-expanded', 'false'); });
      if (willOpen) { qa.classList.add('is-open'); btn.setAttribute('aria-expanded', 'true'); }
    });
  });

  /* ---------------------------------------------------------------
     Motion components (inner pages)
     --------------------------------------------------------------- */
  // cursor spotlight
  $$('[data-spot]').forEach(el => el.addEventListener('pointermove', e => {
    const r = el.getBoundingClientRect();
    el.style.setProperty('--mx', (e.clientX - r.left) + 'px'); el.style.setProperty('--my', (e.clientY - r.top) + 'px');
  }));

  // process timeline: the rail fills as the section scrolls up; steps light as the fill passes them
  const timelines = $$('.timeline').map(el => ({ el, steps: $$('.timeline__step', el) }));
  function timelineProgress() {
    timelines.forEach(({ el, steps }) => {
      const r = el.getBoundingClientRect();
      const p = RM.matches ? 1 : clamp((vh * .82 - r.top) / (vh * .5), 0, 1);
      el.style.setProperty('--p', p.toFixed(3));
      const n = steps.length;
      steps.forEach((s, i) => s.classList.toggle('is-on', p >= (n > 1 ? i / (n - 1) : 0) - .02 && p > 0));
    });
  }

  // auto-advancing tabs with a progress bar per tab; pause on hover, run only on screen
  $$('.tabs').forEach(root => {
    const tabs = $$('.tabs__tab', root), panels = $$('.tabs__panel', root);
    if (!tabs.length) return;
    const DUR = +root.dataset.interval || 6500;
    let cur = 0, start = 0, raf = 0, visible = false, hover = false, elapsed = 0;
    const restartScenes = p => { try { p.getAnimations({ subtree: true }).forEach(a => { a.currentTime = 0; }); } catch (e) {} };
    function select(i, user) {
      cur = (i + tabs.length) % tabs.length; elapsed = 0; start = performance.now();
      tabs.forEach((t, k) => { t.classList.toggle('is-active', k === cur); t.setAttribute('aria-selected', k === cur); t.style.setProperty('--t', 0); });
      panels.forEach((p, k) => p.classList.toggle('is-active', k === cur));
      restartScenes(panels[cur]);
      if (user && tabs[cur].scrollIntoView && innerWidth < 960) tabs[cur].scrollIntoView({ block: 'nearest', inline: 'center', behavior: 'smooth' });
    }
    function tick(now) {
      if (!visible) return;
      if (!hover && !RM.matches) {
        elapsed += now - start; start = now;
        const t = clamp(elapsed / DUR, 0, 1);
        tabs[cur].style.setProperty('--t', t.toFixed(3));
        if (t >= 1) select(cur + 1);
      } else start = now;
      raf = requestAnimationFrame(tick);
    }
    tabs.forEach((t, i) => t.addEventListener('click', () => select(i, true)));
    root.addEventListener('pointerenter', () => { hover = true; });
    root.addEventListener('pointerleave', () => { hover = false; });
    new IntersectionObserver(es => es.forEach(e => {
      visible = e.isIntersecting;
      if (visible) { start = performance.now(); cancelAnimationFrame(raf); raf = requestAnimationFrame(tick); }
    }), { threshold: .3 }).observe(root);
    select(0);
  });

  /* ---------------------------------------------------------------
     Global scroll loop
     --------------------------------------------------------------- */
  const bar = $('.progress span');
  const heroInner = $('.hero__inner');
  const fab = $('#fab');
  const foot = $('.foot');
  const cta = $('.cta');
  let ticking = false;

  function onScroll() {
    ticking = false;
    const y = scrollY;
    const max = document.documentElement.scrollHeight - vh;
    if (bar) bar.style.transform = `scaleX(${max > 0 ? (y / max).toFixed(4) : 0})`;

    // nav auto-hide
    if (nav && !openItem && !nav.classList.contains('menu-open')) {
      if (y > lastY + 6 && y > 240) nav.classList.add('is-hidden');
      else if (y < lastY - 6 || y < 240) nav.classList.remove('is-hidden');
    }
    lastY = y;

    // hero parallax
    if (heroInner && y < vh * 1.1 && !RM.matches) {
      const k = y / vh;
      heroInner.style.transform = `translate3d(0,${(y * .16).toFixed(1)}px,0)`;
      heroInner.style.opacity = (1 - k * 1.1).toFixed(3);
      if (heroVideo) heroVideo.style.setProperty('--hs', (1 + k * .08).toFixed(4));
    }
    if (heroVideo && !RM.matches) { if (y > vh * 1.2) pause(heroVideo); else if (heroVideo.paused) play(heroVideo); }

    svcEnter();
    timelineProgress();
    svcProgress();
    mobileUpdate();
    quoteProgress();
    rapidProgress();

    // floating CTA: after the first screen, hidden over the CTA panel and footer
    if (fab) {
      const fr = foot ? foot.getBoundingClientRect() : { top: Infinity };
      const cr = cta ? cta.getBoundingClientRect() : { top: Infinity, bottom: -Infinity };
      const overCta = cr.top < vh * .8 && cr.bottom > vh * .2;
      fab.classList.toggle('is-shown', y > vh * .9 && fr.top > vh && !overCta);
    }
  }
  addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });

  let rz = 0;
  addEventListener('resize', () => {
    clearTimeout(rz);
    rz = setTimeout(() => {
      vw = innerWidth; vh = innerHeight;
      if (net) net.resize();
      extraNets.forEach(n => n.resize());
      if (warp) warp.resize();
      buildMarquees();
      sizeIll();
      lastCut = ''; svcEnter();
      if (router) router.build();
      drawWire(false);
      if (!MQ_DESK_NAV.matches) moveGlider(null);
      onScroll();
    }, 120);
  });
  MQ_PIN.addEventListener ? MQ_PIN.addEventListener('change', svcMode) : MQ_PIN.addListener(svcMode);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => { sizeIll(); if (router) router.build(); drawWire(false); });
  addEventListener('load', () => { if (router) router.build(); drawWire(false); lastCut = ''; svcEnter(); });

  svcMode();
  onScroll();
})();

