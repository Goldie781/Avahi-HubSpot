
document.documentElement.classList.add('js');
  /* Hide any remote image that fails to load so layouts never show broken icons */
  document.addEventListener('error', function (e) {
    var t = e.target;
    if (t && t.tagName === 'IMG') {
      if (t.dataset.alt && !t.dataset.altTried) { t.dataset.altTried = '1'; t.src = t.dataset.alt; return; }
      t.classList.add('is-broken'); var f = t.closest('[data-fallback]'); if (f) f.classList.add('use-fallback'); }
  }, true);

