/* Floating "Book a Call" button steps aside while the booking section is on screen,
   so it never covers the calendar on phones. Kept separate from lp.js so the minified layer stays stable. */
(function () {
  'use strict';
  var fab = document.getElementById('fab');
  var cal = document.querySelector('.lp-cal');
  var section = cal && (cal.closest('section') || cal);
  if (!fab || !section || !('IntersectionObserver' in window)) return;
  new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { fab.classList.toggle('is-away', e.isIntersecting); });
  }, { threshold: 0.05 }).observe(section);
})();
