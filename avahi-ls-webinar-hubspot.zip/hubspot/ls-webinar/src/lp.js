/* Avahi webinar (VSL) landing page: video player, HubSpot meetings embed, conversion tracking.
   Every setting comes from the page's modules (data attributes), so editors never touch this file.
   - Video: .lp-video[data-video-url]  (direct MP4/WebM incl. HubSpot File Manager, YouTube, Vimeo, HubSpot video, any embed URL)
   - Booking: .lp-cal[data-linkedin-conversion] (optional LinkedIn conversion id) + #lp-meetings[data-meeting-url] */
(function () {
  'use strict';
  var dl = window.dataLayer = window.dataLayer || [];
  var PAGE = (document.body && document.body.getAttribute('data-lp-page')) || 'ls-report-authoring';
  function track(action, extra) {
    var e = { event: 'lp_webinar', lp_action: action, lp_page: PAGE };
    if (extra) for (var k in extra) e[k] = extra[k];
    dl.push(e);
  }
  function esc(s) { return String(s || '').replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  /* ---------- clicks on every tracked CTA ---------- */
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('[data-track]');
    if (a) track('cta_click', { lp_cta: a.getAttribute('data-track') });
  });

  /* ---------- page header: close the mobile sheet after a link is chosen ---------- */
  var navEl = document.getElementById('nav');
  if (navEl) {
    navEl.querySelectorAll('.lpnav__sheet a').forEach(function (a) {
      a.addEventListener('click', function () {
        navEl.classList.remove('menu-open');
        var b = navEl.querySelector('.nav__burger');
        if (b) { b.setAttribute('aria-expanded', 'false'); b.setAttribute('aria-label', 'Open menu'); }
      });
    });
  }

  /* ---------- video ---------- */
  var box = document.querySelector('[data-video]');
  var calCard = document.querySelector('.lp-cal');
  if (box) {
    var url = (box.getAttribute('data-video-url') || '').trim();
    if (url.indexOf('{{') === 0) url = '';
    var vTitle = box.getAttribute('data-video-title') || 'Webinar recording';
    var posterSrc = box.getAttribute('data-poster') || '';
    var stage = box.querySelector('.lp-video__stage');
    var poster = box.querySelector('.lp-video__poster');
    var endCard = box.querySelector('.lp-video__end');
    var marks = { 25: 0, 50: 0, 75: 0, 90: 0 };
    var ended = false;

    function message(title, text, link) {
      stage.innerHTML = '<div class="lp-video__msg"><b>' + esc(title) + '</b><span>' + esc(text) + '</span>' +
        (link ? '<a class="lp-video__msglink" href="' + esc(link) + '" target="_blank" rel="noopener">' + esc(box.getAttribute('data-error-link') || 'Open the video in a new tab') + '</a>' : '') + '</div>';
      box.classList.add('is-playing');
    }
    function progress(pct) {
      [25, 50, 75, 90].forEach(function (m) {
        if (pct >= m && !marks[m]) { marks[m] = 1; track('video_progress', { lp_video_percent: m }); }
      });
    }
    function onEnded() {
      if (ended) return;
      ended = true;
      track('video_complete');
      if (endCard) endCard.hidden = false;
      if (calCard) calCard.classList.add('is-pulse');
    }
    function kind(u) {
      if (/\.(mp4|webm|m4v|mov|ogv)(\?|#|$)/i.test(u)) return 'file';
      if (/youtu\.?be/i.test(u)) return 'youtube';
      if (/vimeo\.com/i.test(u)) return 'vimeo';
      return 'embed';
    }
    function ytId(u) { var m = u.match(/(?:v=|youtu\.be\/|embed\/|shorts\/|live\/)([\w-]{11})/); return m ? m[1] : ''; }
    function vimeoId(u) { var m = u.match(/vimeo\.com\/(?:video\/)?(\d+)/); return m ? m[1] : ''; }
    function frame(src) {
      var f = document.createElement('iframe');
      f.src = src;
      f.title = vTitle;
      f.allow = 'autoplay; fullscreen; picture-in-picture; encrypted-media';
      f.allowFullscreen = true;
      f.setAttribute('loading', 'eager');
      stage.appendChild(f);
      return f;
    }
    function safeUrl(u) {
      // spaces and brackets in File Manager names must be encoded for <video src>
      try { return encodeURI(decodeURI(u)); } catch (_) { return u; }
    }
    function start() {
      if (!url) {
        message(box.getAttribute('data-empty-title') || 'Video coming soon', box.getAttribute('data-empty-text') || 'The session recording will appear here.');
        console.warn('[lp] Add the video URL in the hero module (Video > Video URL).');
        return;
      }
      if (!/^(https?:)?\/\//i.test(url)) {
        message(box.getAttribute('data-error-title') || 'This video could not be loaded', box.getAttribute('data-error-text') || 'Check the video URL in the page editor.');
        return;
      }
      track('video_play', { lp_video_url: url });
      box.classList.add('is-playing');
      stage.innerHTML = '';
      var k = kind(url);
      if (k === 'file') {
        var v = document.createElement('video');
        v.src = safeUrl(url); v.controls = true; v.autoplay = true; v.playsInline = true; v.preload = 'auto';
        v.setAttribute('playsinline', ''); v.setAttribute('title', vTitle);
        if (posterSrc) v.poster = posterSrc;
        v.addEventListener('timeupdate', function () { if (v.duration) progress(v.currentTime / v.duration * 100); });
        v.addEventListener('ended', onEnded);
        v.addEventListener('error', function () {
          track('video_error', { lp_video_url: url });
          message(box.getAttribute('data-error-title') || 'This video could not be loaded', box.getAttribute('data-error-text') || 'Please try again, or open it directly.', safeUrl(url));
        });
        stage.appendChild(v);
        var p = v.play(); if (p && p.catch) p.catch(function () {});
      } else if (k === 'youtube') {
        var id = ytId(url);
        if (!id) return message(box.getAttribute('data-error-title') || 'This video could not be loaded', box.getAttribute('data-error-text') || 'Check the video URL.', url);
        var yf = frame('https://www.youtube-nocookie.com/embed/' + id + '?autoplay=1&rel=0&modestbranding=1&playsinline=1&enablejsapi=1&origin=' + encodeURIComponent(location.origin));
        yf.addEventListener('load', function () { yf.contentWindow.postMessage(JSON.stringify({ event: 'listening', id: 'lp', channel: 'widget' }), '*'); });
        addEventListener('message', function (e) {
          if (!/youtube/.test(e.origin)) return;
          var d; try { d = JSON.parse(e.data); } catch (_) { return; }
          var info = d && d.info;
          if (d.event === 'onStateChange' && info === 0) onEnded();
          if (info && info.playerState === 0) onEnded();
          if (info && info.currentTime && info.duration) progress(info.currentTime / info.duration * 100);
        });
      } else if (k === 'vimeo') {
        var vid = vimeoId(url);
        if (!vid) return message(box.getAttribute('data-error-title') || 'This video could not be loaded', box.getAttribute('data-error-text') || 'Check the video URL.', url);
        var vf = frame('https://player.vimeo.com/video/' + vid + '?autoplay=1&title=0&byline=0&portrait=0&dnt=1');
        vf.addEventListener('load', function () {
          ['ended', 'timeupdate'].forEach(function (ev) { vf.contentWindow.postMessage(JSON.stringify({ method: 'addEventListener', value: ev }), '*'); });
        });
        addEventListener('message', function (e) {
          if (!/vimeo/.test(e.origin)) return;
          var d; try { d = typeof e.data === 'string' ? JSON.parse(e.data) : e.data; } catch (_) { return; }
          if (d.event === 'ended') onEnded();
          if (d.event === 'timeupdate' && d.data) progress(d.data.percent * 100);
        });
      } else {
        // HubSpot video share links, Wistia, Loom and other players that accept an embed URL
        frame(url + (url.indexOf('?') > -1 ? '&' : '?') + 'autoplay=1');
      }
    }
    poster.addEventListener('click', start);
    var replay = box.querySelector('.lp-video__replay');
    if (replay) replay.addEventListener('click', function () {
      endCard.hidden = true; ended = false;
      var v = stage.querySelector('video');
      if (v) { v.currentTime = 0; v.play(); } else { stage.innerHTML = ''; start(); }
    });
    /* a hash link to the video starts it when the visitor clicks "Rewatch" */
    var vid0 = (box.closest('[id]') || {}).id || 'watch';
    document.querySelectorAll('a[href="#' + vid0 + '"]').forEach(function (a) {
      a.addEventListener('click', function () { if (!box.classList.contains('is-playing')) setTimeout(start, 650); });
    });
  }

  /* ---------- HubSpot meetings embed (lazy, with UTM pass-through) ---------- */
  var holder = document.getElementById('lp-meetings');
  if (holder && calCard) {
    var liId = calCard.getAttribute('data-linkedin-conversion') || '';
    var base = holder.getAttribute('data-meeting-url');
    var qs = new URLSearchParams(location.search);
    var pass = new URLSearchParams({ embed: 'true' });
    qs.forEach(function (v, k) { if (/^(utm_|hsa_)/i.test(k) || /^(email|firstname|lastname|company)$/i.test(k)) pass.set(k, v); });
    holder.setAttribute('data-src', base + (base.indexOf('?') > -1 ? '&' : '?') + pass.toString());
    var fbLinks = calCard.querySelectorAll('.lp-cal__fallback a');
    fbLinks.forEach(function (a) { var p = new URLSearchParams(pass); p.delete('embed'); var s = p.toString(); a.href = base + (s ? (base.indexOf('?') > -1 ? '&' : '?') + s : ''); });

    var loaded = false;
    function fallback() {
      if (calCard.classList.contains('is-ready') || calCard.classList.contains('is-done')) return;
      calCard.classList.add('is-fallback');
      calCard.querySelector('.lp-cal__fallback').hidden = false;
      track('calendar_fallback');
    }
    function load() {
      if (loaded) return; loaded = true;
      if (!base) return fallback();
      var s = document.createElement('script');
      s.src = 'https://static.hsappstatic.net/MeetingsEmbed/ex/MeetingsEmbedCode.js';
      s.async = true;
      s.onerror = fallback;
      document.body.appendChild(s);
      var t0 = Date.now();
      (function watch() {
        var f = holder.querySelector('iframe');
        if (f) {
          f.addEventListener('load', function () { calCard.classList.add('is-ready'); track('calendar_view'); });
          setTimeout(function () { if (!calCard.classList.contains('is-ready')) calCard.classList.add('is-ready'); }, 4000);
          return;
        }
        if (Date.now() - t0 > 9000) return fallback();
        setTimeout(watch, 300);
      })();
    }
    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (ents) {
        if (ents.some(function (en) { return en.isIntersecting; })) { load(); io.disconnect(); }
      }, { rootMargin: '1400px 0px' });
      io.observe(calCard);
    } else load();
    /* load early for anyone who clicks a booking CTA */
    var bookId = (calCard.closest('section[id]') || {}).id || 'book';
    document.querySelectorAll('a[href="#' + bookId + '"]').forEach(function (a) { a.addEventListener('click', load); });

    addEventListener('message', function (e) {
      if (!/hubspot/.test(e.origin || '')) return;
      var d = e.data;
      if (typeof d === 'string') { try { d = JSON.parse(d); } catch (_) { return; } }
      if (d && d.meetingBookSucceeded) {
        calCard.classList.add('is-done');
        calCard.querySelector('.lp-cal__done').hidden = false;
        track('meeting_booked');
        if (liId && window.lintrk) window.lintrk('track', { conversion_id: Number(liId) });
      }
    });
  }

})();
