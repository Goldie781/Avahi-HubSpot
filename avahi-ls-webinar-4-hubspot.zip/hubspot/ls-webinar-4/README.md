# Life Sciences Webinar 4 — IND and MAA Section Authoring (Regulatory Sections, Authored From Your Source Data)

CMC Intelligence Series, Session 04. Reference HTML: `avahi-life-sciences-regulatory-authoring-webinar-vsl.html`
(supplied 2026-11-20; same template/CSS as Sessions 02 and 03 — only copy, icons and the two illustrations differ).
Design reference: Webinar 3 (`/life-sciences-webinar-3-paper-batch-records`, content id 228093785624).

## HubSpot page

| Item | Value |
|---|---|
| Page | "Avahi \| Life Sciences Webinar 4 – IND and MAA Section Authoring", content id **228100299894** (DRAFT, cloned from Webinar 3 on 2026-11-20) |
| URL (after publish) | https://www2.avahi.ai/life-sciences-webinar-4-regulatory-authoring |
| Template | `avahi-global/templates/avahi-landing-page.html` — global header + footer partials (not copied, not changed) |
| Title / OG title | IND and MAA Section Authoring Webinar \| Avahi (from the reference `<title>`) |
| Meta / OG description | Watch AI author IND and MAA sections from your source data, in the format agencies expect, with every statement traced to its source and your experts approving. Book a call with Avahi. (from the reference) |
| Canonical | automatic (page URL); indexable (no robots tag) |
| Featured / OG image | **Not set — thumbnail not supplied.** The Webinar 3 image copied by the clone was removed. |
| Meetings | `https://meetings.hubspot.com/baljit-singh2/life-sciences?embed=true&uuid=6babea09-8ec4-468d-9579-a6c83c6e8911` |
| Video | **Not connected** (DLD-252 pending). Poster = the reference's illustrated scene (source documents → drafted section). Without a video a click scrolls to the booking section. |

All module values: `page-values.json`. Page settings: `page-settings.json`.

## Modules (same as Webinars 2/3)

`avahi_lsv_layer` (locked CSS/JS), `avahi_lsv_hero`, `avahi_lsv_results`, `avahi_lsv_booking`, `avahi_lsv_timeline`,
`avahi_lsv_compare`, `avahi_lsv_dark_panel`, `avahi_lsv_presenters`, `avahi_lsv_series`, `avahi_awards_rail`,
`avahi_lsv_cta` (+ floating "Talk to an AI Expert"), `avahi_faq`.

Page choices: hero overlay text **on** (tag + title, as the reference; there is no thumbnail), play button **Centre**,
phone shape **4:3** (design), hero illustration **Source documents to drafted section**, dark panel scene
**Source documents to approved section**. Series: 01, 02 and 03 link to their live pages; 04 is current.

## Module additions (2026-11-20, backwards compatible)

Applied with `tools/module-additions.js` in a logged-in app.hubspot.com tab (CMS Source Code API PUT, read back and
compared). Nothing removed or renamed; defaults unchanged.

* `avahi_lsv_results`, `avahi_lsv_timeline`: icon choices `structure`, `link`, `bars` (`snippets/icon-branches.hubl.html`).
* `avahi_lsv_hero`: new field Video → **Illustration (shown when no poster image is set)** (`video.poster_scene`:
  `review` default = the Session 02 scene, `author` = `snippets/hero-author-scene.svg.html`). Only used when the poster is empty.
  `fat` class from the reference renamed `thk` (Font Awesome gotcha).
* `avahi_lsv_dark_panel`: scene choice `author` (`snippets/dark-panel-author-scene.svg.html`); the scoped `lp-pulse`
  CSS now prints for `trace` or `author`.
* Rollback copies: Design Manager `custom/content-mcp/_backup-2026-11-20-w4/<module>.module/` (hidden from new content).
* Webinar 2 and 3 live pages re-checked after the change: same H1, poster, icons, scenes.

## QA (draft preview, 2026-11-20)

* 1536, 1280, 1024, 768, 390, 360 px: no horizontal overflow, nothing left unrevealed, 0 broken images, calendar fits
  (312 px at 360), video card 4:3 on phones.
* 1 H1 ("Shorten the Path From Source Data to Submission"), 9 H2; global header (1) + footer (1).
* New icons draw in results (4), cards (3), timeline (4); hero and dark-panel scenes render; `lp-pulse` animates.
* Meetings iframe loads; FAQ (6) opens/closes; `#book`, `#watch` exist; series links 01/02/03 return 200.
* Click on the player without a video scrolls to `#book` and pushes `lp_webinar` `video_missing`; no console errors.
* Title, single description, canonical, og:title/description/url, twitter card present; no og:image (no thumbnail yet).

## To do / dependencies

1. **Thumbnail** (not supplied): upload to File Manager `/avahi-ls-webinar-4/`, then
   * Page settings → Featured image = thumbnail (+ alt text), and add `og:image:alt` / `twitter:image:alt` to head HTML;
   * optionally hero → Video → Poster image = thumbnail (overlay text off, phone shape 16:9, as on Webinar 3).
2. **Video (DLD-252)**: when approved, upload the MP4 → hero → Video → Video source "Uploaded video file" → pick it.
3. Publish (Schedule API or the editor). Optional: link the Session 04 card on Webinars 2 and 3 to this page once live.
