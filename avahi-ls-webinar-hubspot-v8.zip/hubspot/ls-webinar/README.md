# Avahi LS Webinar (VSL) — HubSpot build

Source for the **Life Sciences Technical Report Authoring Webinar** landing page
(reference design: `/avahi-life-sciences-report-authoring-webinar-vsl.html`).

## What lives in HubSpot (portal 8985787)

| Design Manager path (`/custom/content-mcp/…`) | Role |
|---|---|
| `pages/avahi-ls-webinar.html` (template id 225461544473) | Page template: header, DnD "Page sections", global footer |
| `modules/avahi_ls_webinar_header` | Page-specific header: logo, series tag, nav links (repeater), CTA, mobile menu |
| `modules/avahi_ls_vsl_hero` | Hero + video (URL, poster, title, caption, aspect ratio, CTA, presenters strip) |
| `modules/avahi_ls_feature_cards` | "What you will see" cards |
| `modules/avahi_ls_booking` | Book-a-call section with HubSpot Meetings embed + fallback |
| `modules/avahi_ls_process_timeline` | "How it works" timeline |
| `modules/avahi_ls_compare` | Manual vs agent comparison |
| `modules/avahi_ls_dark_panel` | "Built for regulated work" dark panel |
| `modules/avahi_ls_presenters` | Presenters + series list |
| `modules/avahi_ls_cta_panel` | Closing CTA |
| `modules/avahi_ls_webinar_styles`, `…_styles_b` | Locked design layer (CSS, split in two parts) |
| `modules/avahi_ls_webinar_scripts` | Locked behaviour layer (video player, calendar, animations, tracking) |
| reused: `avahi_awards_rail`, `avahi_faq`, `avahi_global_footer` | Existing shared modules, unchanged |

Everything in this folder's `modules/` and `templates/` is generated — edit `build.py` / `src/`, not the output.

## Rebuild

```bash
python3 build.py                      # modules/, templates/, preview/page.json
NODE_PATH=<dir>/node_modules node purge.mjs   # needs purgecss, csso, terser -> shared/styles.css, shared/scripts.js
python3 build.py                      # re-run so the style/script modules pick up the new shared/ files
python3 preview.py                    # preview/index.html (Jinja2 render of the template)
python3 test/shoot.py 1440,1280,1024,768,390,375   # geometry diff vs the reference HTML
python3 test/interact.py              # menu, anchors, FAQ, video start, tracking, JS errors
```

Then paste each changed `module.html` / `fields.json` into the matching Design Manager module
(or update through the HubSpot connector). Changing a module updates every page that uses it.

## Video

The hero module's **Video URL** field accepts a HubSpot File Manager MP4 (or any .mp4/.webm), a YouTube or
Vimeo link, or any other embeddable URL. Nothing plays until the visitor clicks (no autoplay with sound).
Empty URL shows a "coming soon" card; a failed load shows an error card with a direct link.
Aspect ratio is a field, so the frame is reserved before the video loads (no layout shift).

## Notes

- Images are hot-linked from avahi.ai media; swap any of them from File Manager in the page editor.
  Copies of the reference artwork are in `/assets/ls-webinar/`.
- Scripts are not loaded inside the HubSpot editor, so sections render statically there.
- www2.avahi.ai loads Font Awesome site-wide, which turns any element with class `fab`, `fas`, `far`… into an icon.
  Never use those class names here (the floating button is `.lp-fab` for this reason).
- The CSS layer is split at the `.card-grid{` rule into two modules; the small FAB script (`src/lp-fab.js`) is
  minified separately and appended, so changes stay local and the main bundle is byte-stable.
- Presenter logos in the hero have a "Show the uploaded logo in white" toggle (on by default for the dark hero).
- `test/shots/` (screenshots) is git-ignored.
- HubSpot ignored the FAQ `questions` passed as template params, so the webinar FAQ is set on the page itself
  (page module `main_content-module-10`). When cloning, check the FAQ content.
- In the page editor the header is positioned over the hero (editor-only style in the header module) so the editor
  matches the live page; scripts and animations stay off there.
- Hero > Video > "Autoplay muted when the page loads": the video starts muted once it is on screen, with a
  "Click for sound" button (label editable) that unmutes and restarts from the beginning. Skipped for visitors with
  reduced motion or data saver on; if the browser refuses autoplay, the play button shows instead. The button's
  styles live in the hero module (purge.mjs ignores module `<style>` blocks so the shared CSS layer stays unchanged).
  Tracking: `video_autoplay`, `video_unmute` (via button or controls), progress events carry `lp_video_muted`.
