/* Design-parity probe. Runs inside a page (reference HTML or the live HubSpot page) and returns a
   comparable snapshot: section heights, key element boxes (relative to their section), typography,
   visible text per section, links and images. Used by test/parity.py (reference) and pasted into the
   browser for the live page. */
async function avhProbe() {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const H = () => document.documentElement.scrollHeight;
  for (let y = 0; y < H(); y += 400) { scrollTo(0, y); await sleep(35); }
  scrollTo(0, 0); await sleep(2400);
  const st = document.createElement('style');
  st.textContent = '*,*::before,*::after{animation-play-state:paused!important;transition:none!important}.nav{transform:none!important}';
  document.head.appendChild(st);
  await sleep(50);
  const fnv = s => { let h = 0x811c9dc5; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193) >>> 0; } return h.toString(16).padStart(8, '0'); };
  const norm = s => (s || '').replace(/\s+/g, ' ').trim();
  const secs = [...document.querySelectorAll('main section, footer.foot')];
  const box = e => { const r = e.getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top + scrollY), Math.round(r.width), Math.round(r.height)]; };
  const SEL = ['.nav__bar', '.nav__logo', '.nav__tag', '.lp-navwatch', '.lp-navcta', '.nav__burger',
    '.lp-vsl__pre', '.hero__title', '.hero__lede', '.lp-video', '.lp-vsl__cta .btn', '.lp-vsl__micro', '.lp-vsl__hosts',
    '.sec__head', '.h2', '.lede', '.eyebrow', '.card', '.lp-book__copy', '.lp-book__note', '.lp-cal', '.lp-cal__head', '.checklist li',
    '.timeline__step', '.timeline__rail', '.compare__col', '.compare__list li', '.rapid__frame', '.rapid__copy', '.lp-host', '.lp-series__list li',
    '.awards__title', '.awards__rail', '.cta__panel', '.cta__title', '.cta__text', '.cta__actions .btn', '.faq__aside', '.qa',
    '.foot__top', '.foot__grid', '.foot__trust', '.foot__badges img', '.foot__bottom', '.lp-fab'];
  const els = {};
  for (const s of SEL) {
    els[s] = [...document.querySelectorAll(s)].map(e => {
      const b = box(e), sec = e.closest('section, footer.foot');
      const si = sec ? secs.indexOf(sec) : -1, stp = sec ? box(sec)[1] : 0;
      return [si, b[0], b[1] - stp, b[2], b[3]];
    });
  }
  const PROPS = ['fontFamily', 'fontSize', 'fontWeight', 'lineHeight', 'letterSpacing', 'color', 'backgroundColor', 'textTransform', 'borderTopWidth', 'borderTopColor', 'borderRadius', 'paddingLeft'];
  const STY = ['body', '.nav__tag', '.lp-navwatch', '.lp-navcta', '.lp-vsl__pre', '.hero__title', '.hero__title .grad-text', '.hero__lede', '.lp-vsl__micro',
    '.lp-vsl__host b', '.eyebrow', '.h2', '.lede', '.card__title', '.card__text', '.lp-book__label', '.checklist li', '.lp-book__note', '.lp-cal__title',
    '.timeline__when', '.timeline__title', '.timeline__text', '.compare__label', '.compare__col--before li', '.compare__col--after li', '.lp-host .card__title',
    '.lp-series__num', '.lp-series__name', '.lp-series__tag', '.awards__title', '.cta__title', '.cta__text', '.cta__actions .btn', '.qa__btn', '.qa__panel p',
    '.foot__statement', '.foot h3', '.foot__grid ul a', '.foot__bottom', '.lp-fab'];
  const sty = {};
  for (const s of STY) { const e = document.querySelector(s); if (!e) { sty[s] = null; continue; } const c = getComputedStyle(e); sty[s] = PROPS.map(p => String(c[p]).split(',')[0].replace(/"/g, '')).join('|'); }
  const sections = secs.map(s => {
    const b = box(s), t = norm(s.innerText);
    return { cls: (s.className || '').toString().split(' ').filter(c => !/^(in|is-|has-)/.test(c)).slice(0, 3).join('.'), id: s.id || '', top: b[1], h: b[3], w: b[2], text: fnv(t), len: t.length };
  });
  const texts = secs.map(s => norm(s.innerText));
  const links = [...document.querySelectorAll('header#nav a, main a, footer a')].filter(a => a.offsetParent || a.closest('.lpnav__sheet'))
    .map(a => (a.getAttribute('href') || '') + ' | ' + norm(a.innerText).slice(0, 40));
  const imgs = [...document.querySelectorAll('main img, footer img, header img')].map(i => norm(i.alt) + ' | ' + (i.naturalWidth > 0 ? 'ok' : 'broken'));
  return { w: innerWidth, h: H(), overflow: document.documentElement.scrollWidth - innerWidth, sections, els, sty, texts, links, imgs };
}
