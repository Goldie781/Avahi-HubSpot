#!/usr/bin/env python3
"""Snapshot the reference HTML with test/probe.js at several widths (real Manrope served from @fontsource).
Writes test/parity-ref.json. Usage: python3 test/parity.py 1440,1280,1024,768,390,375 <fontsource dir>"""
import os, sys, json, asyncio, glob
from playwright.async_api import async_playwright

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT = os.path.dirname(os.path.dirname(HERE))
REF = 'file://' + os.path.join(ROOT, 'avahi-life-sciences-report-authoring-webinar-vsl.html')
WIDTHS = [int(w) for w in (sys.argv[1] if len(sys.argv) > 1 else '1440,390').split(',')]
FONTS = sys.argv[2] if len(sys.argv) > 2 else ''
PROBE = open(os.path.join(HERE, 'test', 'probe.js')).read()

def font_css():
    if os.environ.get('GOOGLE_LIKE'):   # same face split + unicode-range order as fonts.googleapis.com
        import re
        out = []
        for w in (200, 300, 400, 500, 600, 700, 800):
            c = open(os.path.join(os.path.dirname(FONTS), f'{w}.css')).read()
            c = re.sub(r"url\(\./files/([^)]+?\.woff2)\) format\('woff2'\)(, url\([^)]+\) format\('woff'\))?", r"url(https://fonts.local/\1) format('woff2')", c)
            out.append(c)
        return '\n'.join(out)
    css = []
    for f in sorted(glob.glob(os.path.join(FONTS, 'manrope-latin-*-normal.woff2'))):
        w = f.rsplit('-', 2)[1]
        css.append(f"@font-face{{font-family:'Manrope';font-style:normal;font-weight:{w};font-display:block;src:url(https://fonts.local/{os.path.basename(f)}) format('woff2')}}")
    return '\n'.join(css)

async def main():
    out = {}
    async with async_playwright() as p:
        b = await p.chromium.launch()
        for w in WIDTHS:
            ctx = await b.new_context(viewport={"width": w, "height": 900}, device_scale_factor=1)
            page = await ctx.new_page()
            async def route(r):
                u = r.request.url
                if 'fonts.googleapis.com' in u:
                    await r.fulfill(status=200, content_type='text/css', body=font_css())
                elif u.startswith('https://fonts.local/'):
                    await r.fulfill(status=200, content_type='font/woff2', body=open(os.path.join(FONTS, u.rsplit('/', 1)[1]), 'rb').read())
                elif u.startswith('file://') or u.startswith('data:'):
                    await r.continue_()
                else:
                    await r.abort()
            await page.route('**/*', route)
            await page.goto(REF, wait_until='load')
            await page.evaluate('document.fonts.ready')
            out[w] = await page.evaluate(PROBE + '\navhProbe()')
            fam = await page.evaluate("document.fonts.check('700 20px Manrope')")
            print(w, 'height', out[w]['h'], 'sections', len(out[w]['sections']), 'manrope', fam)
            await ctx.close()
        await b.close()
    json.dump(out, open(os.path.join(HERE, 'test', 'parity-ref-gf.json' if os.environ.get('GOOGLE_LIKE') else 'parity-ref.json'), 'w'), indent=0)

asyncio.run(main())
