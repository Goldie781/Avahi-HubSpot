#!/usr/bin/env python3
"""Muted-autoplay checks on a local preview with the hero's "Autoplay muted" switch on.
Serves preview/ on 127.0.0.1:8765. Usage: python3 test/autoplay.py <local test.mp4 with audio>"""
import os, sys, json, asyncio, shutil
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import preview
from playwright.async_api import async_playwright
HERE = preview.HERE
mp4 = sys.argv[1]
shutil.copy(mp4, os.path.join(HERE, 'preview', 'test.mp4'))
video = preview.defaults(json.load(open(os.path.join(HERE, 'modules', 'avahi_ls_vsl_hero', 'fields.json'))))['video']
video.update(autoplay_muted=True, video_url='http://127.0.0.1:8765/test.mp4')
preview.build({'avahi_ls_vsl_hero': {'video': video}}, out='autoplay.html')
off = dict(video, autoplay_muted=False); preview.build({'avahi_ls_vsl_hero': {'video': off}}, out='autoplay-off.html')
ok = lambda c, m: print(('PASS ' if c else 'FAIL ') + m)
import http.server, threading, functools
srv = http.server.ThreadingHTTPServer(('127.0.0.1', 8765), functools.partial(http.server.SimpleHTTPRequestHandler, directory=os.path.join(HERE, 'preview')))
srv.RequestHandlerClass.log_message = lambda *a: None
threading.Thread(target=srv.serve_forever, daemon=True).start()
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--autoplay-policy=user-gesture-required'])
        for w in (1440, 390):
            pg = await (await b.new_context(viewport={'width': w, 'height': 900})).new_page()
            errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
            await pg.goto('http://127.0.0.1:8765/autoplay.html'); await pg.wait_for_timeout(2500)
            s = await pg.evaluate("(()=>{const v=document.querySelector('.lp-video__stage video');const u=document.querySelector('.lp-video__unmute');return {v:!!v,muted:v&&v.muted,paused:v&&v.paused,t:v&&v.currentTime,btn:u&&!u.hidden&&u.getBoundingClientRect().width>0,cls:document.querySelector('.lp-video').className,dl:(window.dataLayer||[]).map(e=>e.lp_action)}})()")
            ok(s['v'] and s['muted'] and not s['paused'] and s['t'] > 0.5, f'{w}: autoplays muted on load {s}')
            ok(s['btn'], f'{w}: "Click for sound" button visible')
            ok('video_autoplay' in s['dl'] and 'video_play' not in s['dl'], f'{w}: tracked as video_autoplay {s["dl"]}')
            await pg.click('.lp-video__unmute'); await pg.wait_for_timeout(600)
            s = await pg.evaluate("(()=>{const v=document.querySelector('.lp-video__stage video');const u=document.querySelector('.lp-video__unmute');return {muted:v.muted,paused:v.paused,t:v.currentTime,btnHidden:u.hidden,cls:document.querySelector('.lp-video').className,dl:(window.dataLayer||[]).map(e=>e.lp_action)}})()")
            ok(not s['muted'] and not s['paused'] and s['t'] < 1.5 and s['btnHidden'] and 'is-muted' not in s['cls'], f'{w}: sound button unmutes and restarts {s}')
            ok('video_unmute' in s['dl'], f'{w}: video_unmute tracked')
            ok(not errs, f'{w}: no JS errors {errs[:2]}')
        # native controls unmute (no restart)
        pg = await (await b.new_context(viewport={'width': 1440, 'height': 900})).new_page()
        await pg.goto('http://127.0.0.1:8765/autoplay.html'); await pg.wait_for_timeout(3000)
        t0 = await pg.evaluate("document.querySelector('.lp-video__stage video').currentTime")
        await pg.evaluate("document.querySelector('.lp-video__stage video').muted=false"); await pg.wait_for_timeout(400)
        s = await pg.evaluate("(()=>{const v=document.querySelector('.lp-video__stage video');return {t:v.currentTime,btn:document.querySelector('.lp-video__unmute').hidden}})()")
        ok(s['btn'] and s['t'] >= t0, f'unmute via player controls hides the button, keeps position (t0={t0:.1f}, t={s["t"]:.1f})')
        # reduced motion: no autoplay
        pg = await (await b.new_context(viewport={'width': 1440, 'height': 900}, reduced_motion='reduce')).new_page()
        await pg.goto('http://127.0.0.1:8765/autoplay.html'); await pg.wait_for_timeout(2000)
        ok(not await pg.evaluate("!!document.querySelector('.lp-video__stage video')"), 'reduced motion: no autoplay, play button shown')
        # autoplay blocked entirely: falls back to the play button
        b2 = await p.chromium.launch(args=['--autoplay-policy=document-user-activation-required'])
        pg = await (await b2.new_context(viewport={'width': 1440, 'height': 900})).new_page()
        await pg.add_init_script("HTMLMediaElement.prototype.play=function(){return Promise.reject(new DOMException('blocked','NotAllowedError'))}")
        await pg.goto('http://127.0.0.1:8765/autoplay.html'); await pg.wait_for_timeout(2000)
        s = await pg.evaluate("({v:!!document.querySelector('.lp-video__stage video'),cls:document.querySelector('.lp-video').className,btn:document.querySelector('.lp-video__unmute').hidden})")
        ok(not s['v'] and 'is-playing' not in s['cls'] and s['btn'], f'autoplay refused: back to the play button {s}')
        await b2.close()
        # switch off: nothing plays until click; click plays with sound
        pg = await (await b.new_context(viewport={'width': 1440, 'height': 900})).new_page()
        await pg.goto('http://127.0.0.1:8765/autoplay-off.html'); await pg.wait_for_timeout(2000)
        ok(not await pg.evaluate("!!document.querySelector('.lp-video__stage video')") and not await pg.evaluate("!!document.querySelector('.lp-video__unmute')"), 'switch off: no autoplay, no sound button')
        await pg.click('.lp-video__poster'); await pg.wait_for_timeout(1200)
        s = await pg.evaluate("(()=>{const v=document.querySelector('.lp-video__stage video');return {muted:v.muted,paused:v.paused}})()")
        ok(not s['muted'] and not s['paused'], f'switch off: click plays with sound {s}')
        await b.close()
asyncio.run(main())
